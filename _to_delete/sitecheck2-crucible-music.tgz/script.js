var PLAYER_STAMP = Date.now().toString(36); // see addEmbedParam
// Use relative path so pages in subfolders can resolve the background image
const originalBackground = "images/1.jpg";
// Once Pip (the chatbot, bit.js) has been set free, he runs the place: the site's own look is his.
const PIP_BACKGROUND = "#3b1d7a";
function pipIsFree() { try { return !!JSON.parse(localStorage.getItem("bit-memory") || "{}").freed; } catch (e) { return false; } }
window.pipIsFree = pipIsFree;
window.PIP_BACKGROUND = PIP_BACKGROUND;

// Helper: set UI surface CSS variables based on the active background value.
function updateUISurfaceForBackground(bgValue) {
    // Default: when the background is an image (url(...)) we use a translucent white overlay
    const isImage = typeof bgValue === 'string' && bgValue.trim().toLowerCase().startsWith('url(');
    const root = document.documentElement;
    let foreground = '#000000';
    if (isImage) {
        root.style.setProperty('--surface-bg', '#ffffff');
        root.style.setProperty('--surface-bg-trans', 'rgba(255,255,255,0.92)');
        foreground = '#000000';
        root.style.setProperty('--surface-foreground', foreground);
        // apply to all-jokes elements if present
        // (the jokes panel has its own cream background, so its text colour is left alone)
        return;
    }

    // If bgValue looks like a color (hex or rgb), compute a suitable surface color.
    // We'll convert short hex to full hex and then compute luminance to pick foreground.
    try {
        let col = bgValue ? bgValue.trim() : '';
        // handle rgb(...) by leaving it as-is and using CSS mix if available
        if (col.startsWith('#')) {
            // normalize 3-digit hex (#abc) to 6-digit
            if (col.length === 4) {
                col = '#' + col[1] + col[1] + col[2] + col[2] + col[3] + col[3];
            }
            // parse hex to rgb
            const r = parseInt(col.substr(1,2), 16);
            const g = parseInt(col.substr(3,2), 16);
            const b = parseInt(col.substr(5,2), 16);
            // compute relative luminance (approx)
            const lum = (0.2126*r + 0.7152*g + 0.0722*b) / 255;
            // choose surface color: if background is dark, use light surface and vice versa
            if (lum < 0.45) {
                // dark bg -> lighter surface: lighten the bg color towards white
                const sr = Math.min(255, Math.round(r + (255 - r) * 0.85));
                const sg = Math.min(255, Math.round(g + (255 - g) * 0.85));
                const sb = Math.min(255, Math.round(b + (255 - b) * 0.85));
                const surf = `rgb(${sr},${sg},${sb})`;
                root.style.setProperty('--surface-bg', surf);
                root.style.setProperty('--surface-bg-trans', `rgba(${sr},${sg},${sb},0.9)`);
                // dark background -> use light (white) foreground for contrast
                foreground = '#ffffff';
                root.style.setProperty('--surface-foreground', foreground);
                // (the jokes panel has its own cream background, so its text colour stays as it is)
            } else {
                // light bg -> darker surface: darken slightly
                const sr = Math.max(0, Math.round(r * 0.12));
                const sg = Math.max(0, Math.round(g * 0.12));
                const sb = Math.max(0, Math.round(b * 0.12));
                const surf = `rgb(${sr},${sg},${sb})`;
                root.style.setProperty('--surface-bg', surf);
                root.style.setProperty('--surface-bg-trans', `rgba(${sr},${sg},${sb},0.12)`);
                // light background -> use dark (black) foreground for contrast
                foreground = '#000000';
                root.style.setProperty('--surface-foreground', foreground);
                // (the jokes panel has its own cream background, so its text colour stays as it is)
            }
            return;
        }
        // fallback: if arbitrary string, use translucent white
        root.style.setProperty('--surface-bg', '#ffffff');
        root.style.setProperty('--surface-bg-trans', 'rgba(255,255,255,0.92)');
        foreground = '#000000';
        root.style.setProperty('--surface-foreground', foreground);
        // (the jokes panel has its own cream background, so its text colour is left alone)
    } catch (e) {
        // If anything fails, keep defaults
        root.style.setProperty('--surface-bg', '#ffffff');
        root.style.setProperty('--surface-bg-trans', 'rgba(255,255,255,0.92)');
        foreground = '#000000';
        root.style.setProperty('--surface-foreground', foreground);
        // (the jokes panel has its own cream background, so its text colour is left alone)
    }
}

function changeBackgroundColor() {
    const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);

    // Set the random color as the background and remove the image
    setBackgroundColor(randomColor);
    // Update the CSS backing layer via a variable so it always fills the viewport
    document.documentElement.style.setProperty('--page-bg', randomColor);
    updateUISurfaceForBackground(randomColor);

    // Save the new background settings to localStorage
    localStorage.setItem("backgroundColor", randomColor);
    localStorage.setItem("backgroundImage", "none");
}

function revertToOriginalBackground() {
    // Reset to the original background image
    // restore the original image on both html and body
    // use full shorthand so the image covers and doesn't repeat
    const img = pipIsFree() ? PIP_BACKGROUND : `url('${originalBackground}') center center / cover no-repeat`;
    // set the CSS backing layer to the image shorthand and clear inline backgrounds
    document.documentElement.style.setProperty('--page-bg', img);
    // When background is an image use translucent white surfaces
    updateUISurfaceForBackground(img);
    document.body.style.background = 'none';
    if (document.documentElement) document.documentElement.style.background = 'none';

    // Save the original background settings to localStorage
    localStorage.setItem("backgroundColor", "");
    localStorage.setItem("backgroundImage", `url('${originalBackground}')`);
}

function applySavedBackground() {
    // Retrieve saved background settings from localStorage
    const savedColor = localStorage.getItem("backgroundColor");
    const savedImage = localStorage.getItem("backgroundImage");

    // If there's a saved color, apply it via the CSS variable used by the backing layer
    if (savedColor) {
        document.documentElement.style.setProperty('--page-bg', savedColor);
        updateUISurfaceForBackground(savedColor);
        return;
    }

    // If there's a saved image and it references the site image, normalize and set the backing layer
    if (savedImage && savedImage.includes("images/1.jpg")) {
        const img = pipIsFree() ? PIP_BACKGROUND : `url('${originalBackground}') center center / cover no-repeat`;
        document.documentElement.style.setProperty('--page-bg', img);
        updateUISurfaceForBackground(img);
        return;
    }

    // If there's an arbitrary saved image, set it on the backing layer
    if (savedImage) {
        document.documentElement.style.setProperty('--page-bg', savedImage);
        updateUISurfaceForBackground(savedImage);
        return;
    }

    // Fallback: set the default image on the backing layer (or Pip's colour, once he's free)
    const img = pipIsFree() ? PIP_BACKGROUND : `url('${originalBackground}') center center / cover no-repeat`;
    document.documentElement.style.setProperty('--page-bg', img);
    updateUISurfaceForBackground(img);
}

function setBackgroundColor(color) {
    // Set both html and body inline styles (full shorthand) so they take precedence over stylesheet rules
    // Update the CSS backing variable so the pseudo-element shows the color/image correctly
    document.documentElement.style.setProperty('--page-bg', color);
    updateUISurfaceForBackground(color);
    
    // Save the selected color to localStorage
    localStorage.setItem("backgroundColor", color);
    localStorage.setItem("backgroundImage", "none");
}

// Apply the saved background when the page loads
applySavedBackground();


// ---------------- Arcade hub script additions ----------------

// Utility to fetch local JSON with project metadata
async function loadProjects() {
    try {
        // fetch relative to the current page so the JSON loads correctly
        // whether the page is at the site root or in a subfolder
        const res = await fetch('data/projects.json', { cache: 'no-cache' });
        if (!res.ok) throw new Error('Failed to load projects');
        return await res.json();
    } catch (err) {
        console.warn('Could not load projects.json', err);
        return [];
    }
}

// Render cabinet grid from data
async function renderCabinets() {
    const grid = document.getElementById('cabinetGrid');
    if (!grid) return;
    const projects = await loadProjects();
    grid.innerHTML = '';

    // Arrange projects so each row is: featured, featured, non-featured (when available)
    const featured = projects.filter(p => !!p.featured);
    const nonFeatured = projects.filter(p => !p.featured);

    const sequence = [];
    let fIdx = 0, nfIdx = 0;
    // Build rows: take up to 2 featured, then one non-featured
    while (fIdx < featured.length) {
        // push first featured
        sequence.push(featured[fIdx++]);
        // push second featured if available
        if (fIdx < featured.length) sequence.push(featured[fIdx++]);
        // then push one non-featured if available
        if (nfIdx < nonFeatured.length) sequence.push(nonFeatured[nfIdx++]);
    }
    // If there are remaining non-featured items, append them after the featured rows
    while (nfIdx < nonFeatured.length) {
        sequence.push(nonFeatured[nfIdx++]);
    }

    // Render in the computed sequence
    sequence.forEach(p => {
        const el = document.createElement('article');
        el.className = 'cabinet';
        if (p.featured) el.classList.add('featured');
        el.innerHTML = `
            <div class="screen">
                ${p.thumbnail ? `<img class="thumb" src="${p.thumbnail}" alt="${p.title} thumbnail">` : `<div class="placeholder"></div>`}
            </div>
            <div class="label">${p.title}</div>
            <div class="sub">${p.tags ? p.tags.join(', ') : ''}</div>
            <div class="controls">
                <a class="play" href="${p.path}" data-path="${p.path}" target="_blank" rel="noopener">Play</a>
            </div>
        `;
        grid.appendChild(el);
    });

    // Make Play embed the game in-page on normal left-click, but allow modifier clicks to open in new tab
    grid.querySelectorAll('.play').forEach(anchor => {
        anchor.addEventListener('click', (e) => {
            // modifiers or middle-click -> allow default behavior (open in new tab)
            if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey) return;
            e.preventDefault();
            playFromAnchor(anchor);
        });
    });
}

// Open the project an anchor points at (its data-path or href) in the in-page player.
// Used by the cabinet grid above and by site.js on the redesigned pages.
async function playFromAnchor(anchor) {
    // prefer an embed-specific path if the project defines one
    const datasetPath = anchor.getAttribute('data-path') || anchor.getAttribute('href');
    let path = datasetPath;
    let match = null;
    try {
        // find the corresponding project entry in the loaded data if available
        const projects = await loadProjects();
        match = projects.find(p => p.path === datasetPath || p.embed === datasetPath || p.title === anchor.closest('.cabinet')?.querySelector('.label')?.textContent);
        if (match && match.embed) path = match.embed;
    } catch (err) {
        // ignore and use datasetPath
    }
    // A project marked "page" (the Studio) is a place of its own: it opens as a normal page, not inside the player.
    if (match && match.page) { window.location.href = match.path; return; }
    // open in the in-page player
    const player = document.getElementById('playerArea');
    const frame = document.getElementById('playerFrameMain');
    const title = document.getElementById('playerTitle');
    const openNewTab = document.getElementById('openNewTab');
    if (player && frame) {
        document.body.classList.add('is-playing');
        // Snake plays in a smaller window at the top of the page, with the site around it
        document.body.classList.toggle('terminal-player', match?.playerLayout === 'terminal');
        document.body.classList.toggle('snake-small', /\/snake\//i.test(String(path)));
        // stop the 3D background while a game runs, so the two don't fight over the graphics card
        try { if (window.__threeScene && window.__threeScene.pause) window.__threeScene.pause(); } catch (e) {}
        player.style.display = '';
        player.setAttribute('aria-hidden', 'false');
        setPlayerFit(fitForProject(match, path));
        requestAnimationFrame(() => {
            fitPlayer();
            scrollToPlayer(player);
        });

        // set iframe src to embed path
        try {
            let embedPath = path;
            // Heuristic: if the path points to a nested src/index.html, prefer the parent folder root
            // e.g. /dungeon-crawler-game/src/index.html -> /dungeon-crawler-game/
            try {
                const lower = String(path).toLowerCase();
                if (lower.includes('/src/index.html') || /\/src\/index\.html$/i.test(path)) {
                    embedPath = path.replace(/\/src\/index\.html$/i, '/');
                    embedPath = embedPath.replace(/\/index\.html$/i, '/');
                }
                // If the project references the Game of Life source, prefer the playable gol.html inside its folder
                try {
                    if ((match && (match.title || '').toLowerCase().includes('game of life')) || String(path).toLowerCase().includes('game_of_life')) {
                        // prefer the internal gol.html which loads the game's script
                        embedPath = '/simulations/Game_of_Life/gol.html';
                    }
                    if (match && match.source && String(match.source).toLowerCase().includes('game_of_life.js')) {
                        embedPath = '/simulations/Game_of_Life/gol.html';
                    }
                } catch (e) {}
                // also handle patterns like /some/path/index.html where the file might be a raw HTML viewer
                // prefer the directory if that file exists as an entry point
            } catch (e) {}
            if (embedPath !== path) console.info('Adjusted embed path from', path, 'to', embedPath);
            loadGameFrame(frame, addEmbedParam(embedPath));
        } catch (e) {
            loadGameFrame(frame, addEmbedParam(path));
        }

        // focus iframe so keyboard works immediately (added)
        try {
            frame.tabIndex = -1;
            frame.style.outline = 'none';
            // focus as soon as it loads
            const __focusOnLoad = () => {
                requestAnimationFrame(() => {
                    focusIframeAndCanvas(frame);
                    fitPlayer();
                    scrollToPlayer(player);
                });
                frame.removeEventListener('load', __focusOnLoad);
            };
            frame.addEventListener('load', __focusOnLoad);
            // also try immediately (user gesture)
            requestAnimationFrame(() => focusIframeAndCanvas(frame));
        } catch (err) { /* best-effort, ignore */ }

        // Show the game's name in the player bar
        if (title) title.textContent = (match && match.title) || anchor.closest('.cabinet')?.querySelector('.label')?.textContent || 'Now playing';
        if (openNewTab) openNewTab.href = path;

        // Update the hero header to reflect the currently playing game
        try {
            const playingTitle = (match && match.title) || anchor.closest('.cabinet')?.querySelector('.label')?.textContent || 'Now playing';
            const playingSubtitle = (match && match.subtitle) || '';
            if (window && typeof window.setHeroForGame === 'function') window.setHeroForGame(playingTitle, playingSubtitle);
        } catch (e) {}

        // Keyboard controls for games that list them in projects.json
        showPlayerControls(match && match.controls);

        // set player subtitle from metadata if available
        const subtitleEl = document.getElementById('playerSubtitle');
        if (subtitleEl) {
            if (match && match.subtitle) {
                subtitleEl.textContent = match.subtitle;
            } else {
                subtitleEl.textContent = ''; // clear until we probe the iframe
            }
        }

        // set player description from metadata if available
        const descEl = document.getElementById('playerDescription');
        if (descEl) {
            if (match && (match.description || match.longDescription)) {
                descEl.textContent = match.description || match.longDescription;
            } else {
                descEl.textContent = '';
            }
        }

        // Try to adjust aspect by probing the embedded page's canvas once it loads
        frame.addEventListener('load', function adjustAspect() {
            try {
                // If the parent provided an explicit playSize, skip probing the iframe content
                // — the playSize should be authoritative and probing can resize the aspect box unexpectedly.
                if (match && match.playSize) {
                    frame.removeEventListener('load', adjustAspect);
                    return;
                }
                const iframeDoc = frame.contentDocument || frame.contentWindow.document;
                // probe for subtitle-like elements inside the embedded page if we don't have metadata
                try {
                    const subtitleEl = document.getElementById('playerSubtitle');
                    if (subtitleEl && (!match || !match.subtitle)) {
                        const found = iframeDoc.querySelector('.sub_title, .player-subtitle, .sub, #subtitle');
                        if (found && found.textContent) subtitleEl.textContent = found.textContent.trim();
                    }
                    // try to probe for a description inside the iframe if we don't have one in metadata
                    const descEl = document.getElementById('playerDescription');
                    if (descEl && (!match || !(match.description || match.longDescription))) {
                        const foundDesc = iframeDoc.querySelector('.description, .desc, .player-description, #description');
                        if (foundDesc && foundDesc.textContent) descEl.textContent = foundDesc.textContent.trim();
                    }
                } catch (e) {
                    // ignore subtitle probing errors
                }
                const canvas = iframeDoc.querySelector('canvas') || iframeDoc.getElementById('gravity-dash-canvas')?.querySelector('canvas');
                if (canvas && playerFit.probe) {
                    const w = canvas.width || canvas.clientWidth || canvas.offsetWidth;
                    const h = canvas.height || canvas.clientHeight || canvas.offsetHeight;
                    if (w && h) setPlayerFit({ mode: 'ratio', ratio: w / h, probe: false });
                }
            } catch (e) {
                // cross-origin or other access denied — silently ignore
            }
            frame.removeEventListener('load', adjustAspect);
        });
        // Listen for aspect messages from the embedded iframe (safer than probing in cross-origin cases)
        // Ensure we remove any previous listener first
        if (window.__gameAspectListener) {
            window.removeEventListener('message', window.__gameAspectListener);
            window.__gameAspectListener = null;
        }
        const onGameAspect = function(e) {
            // Only accept messages coming from the current iframe's contentWindow
            try {
                if (e.source !== frame.contentWindow) return;
            } catch (err) {
                return; // can't access source — ignore
            }
            const data = e.data || {};
            if (data && data.type === 'game-aspect') {
                const subtitleEl = document.getElementById('playerSubtitle');
                if (subtitleEl && data.subtitle) subtitleEl.textContent = data.subtitle;
                const descEl = document.getElementById('playerDescription');
                if (descEl && data.description) descEl.textContent = data.description;

                // The game reports its size: fixed pixels (scaled to fit) or an aspect ratio
                if (data.width && data.height) setPlayerFit({ mode: 'native', w: +data.width, h: +data.height });
                else if (data.widthRatio && data.heightRatio) setPlayerFit({ mode: 'ratio', ratio: data.widthRatio / data.heightRatio });
                else if (parseAspect(data.aspect)) setPlayerFit({ mode: 'ratio', ratio: parseAspect(data.aspect) });
            }
        };
        window.addEventListener('message', onGameAspect);
        window.__gameAspectListener = onGameAspect;
    }
}
window.playFromAnchor = playFromAnchor;

// The controls strip under the player's title. Open or closed is remembered.
function showPlayerControls(controls) {
    const list = document.getElementById('playerControls');
    const btn = document.getElementById('toggleControls');
    if (!list || !btn) return;
    const has = Array.isArray(controls) && controls.length > 0;
    btn.hidden = !has;
    if (!has) { list.hidden = true; list.innerHTML = ''; return; }
    const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    list.innerHTML = controls.map(([key, what]) => `<li><kbd>${esc(key)}</kbd>${esc(what)}</li>`).join('');
    // closed by default; it opens as a small card from the Controls button
    let open = false;
    try { open = localStorage.getItem('player-controls') === 'shown'; } catch (e) {}
    list.hidden = !open;
    btn.setAttribute('aria-expanded', String(open));
    // the first few times, the Controls button glows briefly so people notice it
    try {
        const seen = +(localStorage.getItem('controls-nudged') || 0);
        if (!open && seen < 3) { btn.classList.remove('nudge'); void btn.offsetWidth; btn.classList.add('nudge'); localStorage.setItem('controls-nudged', String(seen + 1)); }
    } catch (e) {}
    try { if (typeof fitPlayer === 'function') fitPlayer(); } catch (e) {}
    if (!btn.__wired) {
        btn.__wired = true;
        btn.addEventListener('click', () => {
            const nowOpen = list.hidden;
            list.hidden = !nowOpen;
            btn.setAttribute('aria-expanded', String(nowOpen));
            try { localStorage.setItem('player-controls', nowOpen ? 'shown' : 'hidden'); } catch (e) {}
            try { if (typeof fitPlayer === 'function') fitPlayer(); } catch (e) {}
            // give the keyboard back to the game
            const frame = document.getElementById('playerFrameMain');
            try { if (frame && typeof focusIframeAndCanvas === 'function') focusIframeAndCanvas(frame); } catch (e) {}
            requestAnimationFrame(() => {
                fitPlayer();
                const pa = document.getElementById('playerArea'); if (pa) scrollToPlayer(pa);
            });
        });
    }
}

// Add ?embed=1 to a URL safely (handles relative paths)
// The in-page player adds a "_" stamp (new each time the site is opened) to the game's address, so the
// browser fetches the current version of the game's page instead of a stale saved copy.
// (Saved copies of iframe pages can hang around for days on a simple local server.)
function loadGameFrame(frame, url) { frame.src = url; }

function addEmbedParam(path) {
    try {
        const url = new URL(path, window.location.origin);
        url.searchParams.set('embed', '1');
        url.searchParams.set('_', PLAYER_STAMP);
        return url.href;
    } catch (e) {
        // fallback: append naive
        if (path.includes('?')) return path + '&embed=1&_=' + PLAYER_STAMP;
        return path + '?embed=1&_=' + PLAYER_STAMP;
    }
}

// Modal handling
function openProjectModal(path) {
    try {
        const modal = document.getElementById('projectModal');
        const frame = document.getElementById('projectFrame');
        console.log('Opening project modal:', path);
        // ensure modal becomes visible for browsers that don't react to aria attribute alone
        modal.style.display = 'flex';
        modal.setAttribute('aria-hidden', 'false');
        frame.src = path;
        // move focus to close button for accessibility
        const closeBtn = document.getElementById('modalClose');
        if (closeBtn) closeBtn.focus();
    } catch (err) {
        console.error('Failed to open project modal', err);
    }
}

function closeProjectModal() {
    const modal = document.getElementById('projectModal');
    const frame = document.getElementById('projectFrame');
    modal.setAttribute('aria-hidden', 'true');
    modal.style.display = 'none';
    frame.src = 'about:blank';
}

document.addEventListener('click', (e) => {
    if (e.target && e.target.id === 'modalClose') closeProjectModal();
    if (e.target && e.target.id === 'projectModal') closeProjectModal();
});

// close modal with Escape key and backdrop clicks
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') closeProjectModal();
});

// tooltips are styled to always appear below the element via CSS

// backdrop click — if clicked outside modal-inner close it
document.addEventListener('click', (e) => {
    const modal = document.getElementById('projectModal');
    if (!modal || modal.getAttribute('aria-hidden') === 'true') return;
    const inner = document.querySelector('.modal-inner');
    if (inner && !inner.contains(e.target) && e.target !== inner) {
        closeProjectModal();
    }
});

// Lazy load three-scene when user toggles 3D or when device supports WebGL
let threeLoaded = false;
// explicit runtime state for whether 3D is currently enabled
let threeEnabled = false;
// Helper to set the toggle button label
function set3DToggleLabel(enabled) {
    const btn = document.getElementById('toggle-3d');
    if (!btn) return;
    btn.textContent = enabled ? '3D on' : '3D off';
}
async function enableDecorative3D(enable) {
    const canvas = document.getElementById('three-canvas');
    if (enable) {
        // If we already have a running instance, just reveal and resume it instead of recreating
        const existingCanvas = document.getElementById('three-canvas');
        if (existingCanvas && window.__threeScene && typeof window.__threeScene.resume === 'function') {
            try {
                existingCanvas.style.display = 'block';
                existingCanvas.style.visibility = 'visible';
                existingCanvas.style.opacity = '1';
                existingCanvas.style.zIndex = '-500';
                existingCanvas.style.background = 'transparent';
                existingCanvas.style.pointerEvents = 'none';
            } catch (e) {}
            try { window.__threeScene.resume(); } catch (e) {}
            threeLoaded = true;
            set3DToggleLabel(true);
            return;
        }

        // Otherwise create a canvas only if it doesn't already exist and initialize
        let newCanvas = existingCanvas;
        if (!newCanvas) {
            newCanvas = document.createElement('canvas');
            newCanvas.id = 'three-canvas';
            newCanvas.className = 'three-canvas';
            try { document.body.appendChild(newCanvas); } catch (e) { document.documentElement.appendChild(newCanvas); }
        }
        // visually hide until ready but keep in layout
        try {
            newCanvas.style.display = 'block';
            newCanvas.style.visibility = 'hidden';
            newCanvas.style.opacity = '0';
        } catch (e) {}
        // disable toggle button while initializing to avoid duplicate inits
        const toggleBtn = document.getElementById('toggle-3d');
        if (toggleBtn) toggleBtn.disabled = true;
    // dynamic import of three-scene script; import is cached but calling initThree ensures re-init after stop()
        try {
            // try to mirror the current page background on the canvas element so the user doesn't see a white flash
            try {
                const pageBg = window.getComputedStyle(document.documentElement).getPropertyValue('--page-bg') || '';
                const bg = (pageBg || '').trim();
                if (bg && bg.toLowerCase().startsWith('url(')) {
                    // image -> keep canvas transparent so image shows through
                    newCanvas.style.background = 'transparent';
                } else if (bg) {
                    // color value (like #aabbcc or rgb(...)) -> apply it to canvas
                    newCanvas.style.background = bg.replace(/"|'/g, '');
                } else {
                    newCanvas.style.background = 'transparent';
                }
            } catch (e) {}

            // primary import attempt
            let mod;
            try {
                mod = await import('./three-scene.js');
            } catch (impErr) {
                console.warn('Initial import of three-scene failed, attempting cache-busted import', impErr);
                // try again with a cache-busting querystring
                try {
                    mod = await import(`./three-scene.js?cb=${Date.now()}`);
                } catch (impErr2) {
                    throw impErr2;
                }
            }

            if (mod && typeof mod.initThree === 'function') {
                await mod.initThree();
            } else {
                throw new Error('three-scene module did not export initThree');
            }

            threeLoaded = true;
            // reveal canvas now that rendering should be happening (ensure pointer events off)
            try {
                newCanvas.style.display = 'block';
                newCanvas.style.visibility = 'visible';
                newCanvas.style.opacity = '1';
                newCanvas.style.zIndex = '-500';
                newCanvas.style.background = 'transparent';
                newCanvas.style.pointerEvents = 'none';
            } catch (e) {}
            set3DToggleLabel(true);
        } catch (err) {
            console.error('3D background failed to initialize', err);
            // remove the newly-inserted canvas if present
            try { const nc = document.getElementById('three-canvas'); if (nc && !threeLoaded && nc.parentNode) nc.parentNode.removeChild(nc); } catch (e) {}
            const btn = document.getElementById('toggle-3d');
            if (btn) { btn.textContent = '3D off (error)'; btn.disabled = false; }
            set3DToggleLabel(false);
            return;
        } finally {
            // re-enable the toggle if it wasn't left disabled
            try { const btn = document.getElementById('toggle-3d'); if (btn) btn.disabled = false; } catch (e) {}
        }
    } else {
        // try to pause animation if three-scene exposed a pause function; prefer pause to preserve GL context
        if (window.__threeScene) {
            if (typeof window.__threeScene.pause === 'function') {
                window.__threeScene.pause();
            } else if (typeof window.__threeScene.stop === 'function') {
                // fallback to a full stop if pause isn't available
                window.__threeScene.stop();
            }
        }
        // keep the canvas in DOM to preserve the GL context; just hide it visually
        try {
            const nc = document.getElementById('three-canvas');
            if (nc) {
                nc.style.opacity = '0';
                nc.style.visibility = 'hidden';
                nc.style.pointerEvents = 'none';
            }
        } catch (e) {}
        set3DToggleLabel(false);
    }
}

// Attach toggle
document.addEventListener('DOMContentLoaded', () => {
    renderCabinets();

    // capture default hero texts so we can restore them when the player closes
    try {
        window.__defaultHeroTitle = document.querySelector('.hero-title')?.textContent || 'Games';
        window.__defaultHeroSub = document.querySelector('.sub_title')?.textContent || 'Welcome :)';
    } catch (e) {
        window.__defaultHeroTitle = 'Games';
        window.__defaultHeroSub = 'Welcome :)';
    }

    // expose global helpers so handlers created outside this block can call them
    window.setHeroForGame = function(title, subtitle) {
        try {
            const heroTitleEl = document.querySelector('.hero-title');
            const heroSubEl = document.querySelector('.sub_title');
            if (heroTitleEl) heroTitleEl.textContent = title || window.__defaultHeroTitle;
            if (heroSubEl) heroSubEl.textContent = subtitle || '';
        } catch (e) {}
    };

    window.resetHero = function() {
        try {
            const heroTitleEl = document.querySelector('.hero-title');
            const heroSubEl = document.querySelector('.sub_title');
            if (heroTitleEl) heroTitleEl.textContent = window.__defaultHeroTitle;
            if (heroSubEl) heroSubEl.textContent = window.__defaultHeroSub;
        } catch (e) {}
    };

    const toggle = document.getElementById('toggle-3d');
    if (toggle) {
        toggle.addEventListener('click', async (ev) => {
            ev.preventDefault();
            // ignore clicks when disabled (but ensure we aren't stuck disabled)
            if (toggle.disabled) {
                console.info('Toggle button is disabled; enabling for retry');
                toggle.disabled = false;
            }
            const canvas = document.getElementById('three-canvas');
            // determine desired state using explicit runtime flag
            const enable = !threeEnabled;
            console.info('3D toggle clicked — desired enable=', enable);
            try {
                // disable while running
                toggle.disabled = true;
                await enableDecorative3D(enable);
                // update runtime state and label
                threeEnabled = !!enable;
                set3DToggleLabel(threeEnabled);
            } catch (err) {
                console.error('enableDecorative3D threw', err);
                // make sure UI isn't left disabled
                toggle.disabled = false;
            } finally {
                // ensure button re-enabled for further attempts
                try { toggle.disabled = false; } catch (e) {}
            }
        });
    }

        // Auto-enable 3D if supported and user hasn't requested reduced motion
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced && toggle) toggle.style.display = 'none';
        function hasWebGL() {
            try {
                const canvas = document.createElement('canvas');
                return !!(window.WebGLRenderingContext && (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')));
            } catch (e) { return false }
        }
        // site.js stores the visitor's choice of floaties; 'none' means they turned the 3D background off
        let floatiesOff = false;
        try { floatiesOff = (JSON.parse(localStorage.getItem('floaties') || '{}').shape === 'none'); } catch (e) {}
        if (!prefersReduced && !floatiesOff && hasWebGL()) {
            // Slight delay to allow paint and avoid blocking
            setTimeout(async () => {
                try {
                    await enableDecorative3D(true);
                    threeEnabled = true;
                    set3DToggleLabel(true);
                } catch (e) {
                    threeEnabled = false;
                    set3DToggleLabel(false);
                }
            }, 300);
        }

    // initialize the toggle label from the explicit flag
    try {
        set3DToggleLabel(!!threeEnabled);
    } catch (e) { /* ignore */ }

    // modal close button
    const closeBtn = document.getElementById('modalClose');
    if (closeBtn) closeBtn.addEventListener('click', closeProjectModal);

    // Player close button
    const closePlayer = document.getElementById('closePlayer');
    if (closePlayer) closePlayer.addEventListener('click', () => {
        const player = document.getElementById('playerArea');
        const frame = document.getElementById('playerFrameMain');
        if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
        if (player) { player.style.display = 'none'; player.setAttribute('aria-hidden', 'true'); player.classList.remove('fullscreen'); }
        if (frame) { frame.__loadToken = (frame.__loadToken || 0) + 1; frame.src = 'about:blank'; }
        showPlayerControls(null);
        document.body.classList.remove('is-playing', 'snake-small', 'terminal-player');
        try {
            const bg = document.getElementById('three-canvas');
            if (bg && bg.style.visibility !== 'hidden' && window.__threeScene && window.__threeScene.resume) window.__threeScene.resume();
        } catch (e) {}
        setFsLabel(false);
        // restore hero header when player closes
        try { if (window && typeof window.resetHero === 'function') window.resetHero(); } catch (e) {}
    });

    // Right-side color controls
    const pageColorPicker = document.getElementById('pageColorPicker');
    const randomBgBtn = document.getElementById('randomBgBtn');
    const revertBgBtn = document.getElementById('revertBgBtn');
    // initialize picker from saved background color
    try {
        const saved = localStorage.getItem('backgroundColor');
        if (saved) {
            if (pageColorPicker) pageColorPicker.value = saved;
            setBackgroundColor(saved);
        }
    } catch (e) { }
    const pageColorDisplay = document.getElementById('pageColorDisplay');
    if (pageColorPicker) {
        pageColorPicker.addEventListener('input', (e) => {
            setBackgroundColor(e.target.value);
            if (pageColorDisplay) pageColorDisplay.style.background = e.target.value;
        });
        // sync display on load
        if (pageColorDisplay) pageColorDisplay.style.background = pageColorPicker.value;
    }
    if (randomBgBtn) randomBgBtn.addEventListener('click', changeBackgroundColor);
    if (revertBgBtn) revertBgBtn.addEventListener('click', revertToOriginalBackground);

    // controls are inline in the header now (pageColorPicker, randomBgBtn, revertBgBtn, toggle-3d, programs)

    // Fullscreen toggle for the player area
    const toggleFs = document.getElementById('toggleFullscreen');
    if (toggleFs) {
        toggleFs.addEventListener('click', async () => {
            const player = document.getElementById('playerArea');
            const frame = document.getElementById('playerFrameMain');
            if (!player) return;
            // If already fullscreen via the element class, exit
            if (document.fullscreenElement || player.classList.contains('fullscreen')) {
                try {
                    if (document.fullscreenElement) await document.exitFullscreen();
                    player.classList.remove('fullscreen');
                    setFsLabel(false);
                } catch (e) { console.warn('Exit fullscreen failed', e) }
                return;
            }
            // Try to request fullscreen on the iframe first (better for keyboard input)
            try {
                if (frame && frame.requestFullscreen) {
                    await frame.requestFullscreen({ navigationUI: 'hide' });
                } else if (player.requestFullscreen) {
                    await player.requestFullscreen({ navigationUI: 'hide' });
                }
                player.classList.add('fullscreen');
                setFsLabel(true);
            } catch (err) {
                // fallback: add class that simulates fullscreen
                console.warn('Fullscreen request failed, falling back to CSS fullscreen', err);
                player.classList.add('fullscreen');
                setFsLabel(true);
            }
        });
    }

    // exit fullscreen with ESC key or handle fullscreenchange to update UI
    document.addEventListener('fullscreenchange', () => {
        const player = document.getElementById('playerArea');
        const toggleFs = document.getElementById('toggleFullscreen');
        if (!document.fullscreenElement) {
            if (player) player.classList.remove('fullscreen');
            if (toggleFs) setFsLabel(false);
        } else {
            setFsLabel(true);
        }
    });

    // Open in new tab link — ensure it opens the current player src if clicked
    const openNewTabLink = document.getElementById('openNewTab');
    if (openNewTabLink) {
        openNewTabLink.addEventListener('click', (e) => {
            // default anchor behavior opens it in a new tab because of target=_blank
        });
    }

    // Header: Change background site button (replaces the old Jokes button)
    const changeBgSiteBtn = document.getElementById('changeBgSiteBtn');
    if (changeBgSiteBtn) {
        changeBgSiteBtn.addEventListener('click', (e) => {
            e.preventDefault();
            // open the dedicated change background page in a new tab
            window.open('/change_color.html', '_blank', 'noopener');
        });
    }
});

// helper: focus an iframe and its inner canvas (best-effort)
function focusIframeAndCanvas(frame) {
  try {
    frame.tabIndex = -1;
    frame.style.outline = 'none';

    frame.focus({ preventScroll: true });

    const doc = frame.contentDocument;
    if (doc) {
      const innerCanvas = doc.querySelector('canvas');
      if (innerCanvas) {
        innerCanvas.tabIndex = -1;
        innerCanvas.style.outline = 'none';
        try { innerCanvas.focus({ preventScroll: true }); } catch (_) {}
      }
    }

    try { frame.contentWindow.postMessage({ type: 'focus' }, '*'); } catch (_) {}
  } catch (err) {
    console.debug('focusIframeAndCanvas failed', err);
  }
}



// ---- Player sizing ---------------------------------------------------------
// The in-page player uses as much of the screen as it can. Each game is one of:
//   fill   – the iframe takes all available space (games that resize themselves)
//   ratio  – the largest box with the game's aspect ratio that fits
//   native – the game page has a fixed pixel size; it is rendered at that size
//            and CSS-scaled to fit (up to 2x), so it shrinks on phones instead of cropping
const playerFit = { mode: 'ratio', ratio: 16 / 9, w: 0, h: 0, probe: false };

function parseAspect(a) {
    const p = String(a || '').split(':').map(Number);
    return p.length === 2 && p[0] > 0 && p[1] > 0 ? p[0] / p[1] : 0;
}

function fitForProject(match, path) {
    if (match && match.aspect === 'fill') return { mode: 'fill', probe: false };
    // games that resize themselves can take the whole player on a phone held upright
    if (match && match.mobileFill && window.innerWidth <= 700 && window.innerHeight > window.innerWidth) return { mode: 'fill', probe: false };
    const ps = match && match.playSize;
    if (ps && ps.width && ps.height) return { mode: 'native', w: +ps.width, h: +ps.height, probe: false };
    const key = String((match && (match.path || match.source || match.title)) || path || '').toLowerCase();
    if (key.includes('flappy')) return { mode: 'native', w: 384, h: 512, probe: false };
    const r = parseAspect(match && match.aspect);
    return { mode: 'ratio', ratio: r || 16 / 9, probe: !r };
}

// bring the player into view; a small game (Snake) sits under the header, so just go to the top
function scrollToPlayer(player) {
    if (document.body.classList.contains('snake-small')) window.scrollTo({ top: 0, behavior: 'instant' });
    else player.scrollIntoView({ behavior: 'instant', block: 'start' });
}

function setPlayerFit(fit) {
    Object.assign(playerFit, fit);
    fitPlayer();
}

function fitPlayer() {
    const player = document.getElementById('playerArea');
    const stage = document.getElementById('playerStage');
    const box = document.getElementById('playerAspectBox');
    const frame = document.getElementById('playerFrameMain');
    if (!player || !stage || !box || !frame || player.style.display === 'none') return;

    // Let flex layout account for the actual header, controls, borders and gaps.
    // Reserve the same 10px inset used by scroll-margin-top on desktop.
    const fixed = getComputedStyle(player).position === 'fixed';
    const vh = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    player.style.height = fixed ? '' : Math.max(1, Math.floor(vh - 20)) + 'px';
    stage.style.height = '';
    stage.style.flex = '1 1 0px';
    const W = stage.clientWidth;
    const H = stage.clientHeight;
    let bw = W;
    let bh = H;
    frame.style.width = '';
    frame.style.height = '';
    frame.style.transform = '';
    if (playerFit.mode === 'native' && playerFit.w && playerFit.h) {
        const s = Math.min(W / playerFit.w, H / playerFit.h, 2);
        bw = playerFit.w * s;
        bh = playerFit.h * s;
        frame.style.width = playerFit.w + 'px';
        frame.style.height = playerFit.h + 'px';
        frame.style.transform = 'scale(' + s + ')';
    } else if (playerFit.mode === 'ratio') {
        bw = Math.min(W, H * playerFit.ratio);
        bh = bw / playerFit.ratio;
    }
    box.style.width = Math.floor(bw) + 'px';
    box.style.height = Math.floor(bh) + 'px';
}

function setFsLabel(on) {
    const btn = document.getElementById('toggleFullscreen');
    if (!btn) return;
    const lbl = btn.querySelector('.lbl');
    if (lbl) lbl.textContent = on ? 'Exit fullscreen' : 'Fullscreen';
    btn.title = on ? 'Exit fullscreen' : 'Fullscreen';
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
}

(function watchPlayerSize() {
    let raf = 0;
    const refit = () => {
        cancelAnimationFrame(raf);
        raf = requestAnimationFrame(fitPlayer);
    };
    window.addEventListener('resize', refit);
    window.addEventListener('orientationchange', refit);
    document.addEventListener('fullscreenchange', refit);
    if (window.visualViewport) window.visualViewport.addEventListener('resize', refit);
    if (window.ResizeObserver) {
        document.addEventListener('DOMContentLoaded', () => {
            const header = document.querySelector('#playerArea .player-header');
            const player = document.getElementById('playerArea');
            const ro = new ResizeObserver(refit);
            if (header) ro.observe(header);
            if (player) ro.observe(player);
        });
    }
    // CSS fullscreen fallback toggles a class rather than firing fullscreenchange
    document.addEventListener('click', e => {
        if (e.target.closest && e.target.closest('#toggleFullscreen')) setTimeout(refit, 50);
    });
})();


// The Music button next to Controls: games that use /music/game-music.js announce themselves with postMessage.
(function wireMusicButton() {
    const btn = document.getElementById('toggleMusic');
    const menu = document.getElementById('musicMenu');
    const frame = document.getElementById('playerFrameMain');
    if (!btn || !menu || !frame) return;
    let state = null;
    const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
    const render = () => {
        btn.hidden = !state;
        if (!state) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); return; }
        btn.classList.toggle('off', !state.on);
        btn.title = state.on ? 'Music is on' : 'Music is off';
        menu.innerHTML = `<div class="mm-song"><small>Now playing</small><b>${esc(state.title)}</b></div>
            <button class="btn small mm-toggle" type="button">${state.on ? 'Turn music off' : 'Turn music on'}</button>
            <a class="btn small mm-studio" href="/music/?game=${encodeURIComponent(state.slot)}" target="_blank" rel="noopener">Change the music &#8599;</a>`;
        menu.querySelector('.mm-toggle').onclick = () => {
            frame.contentWindow && frame.contentWindow.postMessage({ type: 'olid-music:toggle' }, location.origin);
            try { if (typeof focusIframeAndCanvas === 'function') focusIframeAndCanvas(frame); } catch (e) {}
        };
    };
    window.addEventListener('message', (e) => {
        if (e.source !== frame.contentWindow || e.origin !== location.origin || !e.data || e.data.type !== 'olid-music') return;
        state = { slot: String(e.data.slot), title: String(e.data.title || ''), on: !!e.data.on };
        render();
    });
    // a new game (or closing the player) clears it until that game announces its music
    new MutationObserver(() => { state = null; render(); }).observe(frame, { attributes: true, attributeFilter: ['src'] });
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        menu.hidden = !menu.hidden;
        btn.setAttribute('aria-expanded', String(!menu.hidden));
    });
    document.addEventListener('click', (e) => {
        if (!menu.hidden && !e.target.closest('.music-wrap')) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); }
    });
})();
