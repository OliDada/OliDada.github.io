// The scan marker (◎ over what you can scan, filling as the scan runs) and the card
// that shows what you found. Plain DOM; game.js decides what is scanned and when.
//
//   const ui = createScanUI({ touch });
//   ui.marker({ x, y, label } | null, progress)   every frame
//   ui.card({ eyebrow, title, lede, facts, tags, footer: { text, ready } })
//   ui.flash()                                     a scan completed
//   ui.hideCard()
const el = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };

export function createScanUI({ touch = false } = {}) {
    const marker = el("div", "scan-marker");
    marker.setAttribute("aria-hidden", "true");
    const ring = el("i", "scan-ring"), label = el("span", "scan-label"), key = el("kbd", null, touch ? "TAP SCAN" : "E");
    marker.append(ring, label, key);
    const card = el("aside", "scan-card");
    card.setAttribute("role", "status");
    card.hidden = true;
    document.getElementById("hud").append(marker, card);
    let hideTimer = 0, shown = { x: null, y: null, label: null, p: null };

    return {
        marker(target, progress = null) {
            if (!target) {
                if (shown.label !== null) { marker.classList.remove("visible"); shown.label = null; }
                return;
            }
            if (shown.label !== target.label) { label.textContent = target.label; shown.label = target.label; }
            marker.classList.add("visible");
            marker.style.transform = `translate(${target.x.toFixed(1)}px, ${target.y.toFixed(1)}px)`;
            const p = progress == null ? null : Math.round(progress * 100);
            if (p !== shown.p) {
                shown.p = p;
                marker.classList.toggle("scanning", p != null);
                ring.style.setProperty("--p", `${p ?? 0}%`);
                key.textContent = p != null ? "SCANNING" : touch ? "TAP SCAN" : "E";
            }
        },
        flash() {
            marker.classList.remove("done");
            void marker.offsetWidth; // restart the animation
            marker.classList.add("done");
        },
        card({ eyebrow, title, lede, facts = [], tags = [], footer }) {
            const close = el("button", "scan-close", "×");
            close.setAttribute("aria-label", "Close");
            close.onclick = () => this.hideCard();
            const head = el("div", "scan-eyebrow", eyebrow);
            const h = el("h3", null, title);
            const tagRow = el("div", "scan-tags");
            for (const t of tags) tagRow.append(el("span", t.tone ? `tone-${t.tone}` : "", t.text));
            const p = el("p", "scan-lede", lede);
            const dl = el("dl");
            for (const [k, v] of facts) dl.append(el("dt", null, k), el("dd", null, v));
            const foot = footer ? el("div", `scan-foot${footer.ready ? " ready" : ""}`, footer.text) : null;
            card.replaceChildren(close, head, h, ...(tags.length ? [tagRow] : []), p, dl, ...(foot ? [foot] : []));
            card.hidden = false;
            card.classList.remove("in");
            void card.offsetWidth;
            card.classList.add("in");
            clearTimeout(hideTimer);
            hideTimer = setTimeout(() => this.hideCard(), 14000);
        },
        hideCard() {
            clearTimeout(hideTimer);
            card.classList.remove("in");
            hideTimer = setTimeout(() => (card.hidden = true), 250);
        },
        get cardOpen() { return !card.hidden; },
    };
}
