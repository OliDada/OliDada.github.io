import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from './vendor/three.module.js';
import { findScanTarget, cardFor } from './scanning.js';
import { buildGeology } from './geology-mesh.js';
import { generateSystem } from './system.mjs';
import { terrainFor } from './terrain.mjs';
import { faunaFor } from './fauna.mjs';
import { floraFor } from './flora.mjs';

const world = (pred) => { for (let s = 1; s < 400; s++) { const b = generateSystem(s).bodies.find((x) => !x.giant && pred(x)); if (b) return b; } };
const none = { fauna: [], flora: [], formation: [] };

test('the nearest unrecorded formation in reach is the scan target', () => {
  const body = world((b) => b.physics), terrain = terrainFor(body), signal = new THREE.Vector3(...terrain.site);
  const geology = buildGeology(THREE, { body, terrain, radius: body.radius, signalNormal: signal, landingNormal: signal });
  const p = geology.placed.find((x) => x.scales.some((s) => s > 0));
  const i = [...p.scales].findIndex((s) => s > 0);
  const at = new THREE.Vector3(p.positions[i * 3], p.positions[i * 3 + 1], p.positions[i * 3 + 2]);
  const here = at.clone().addScaledVector(new THREE.Vector3(1, 0, 0).cross(at).normalize(), 3); // 3 m away
  const eye = here.clone().addScaledVector(here.clone().normalize(), 1.7), forward = at.clone().sub(eye).normalize();
  const site = { geology, fauna: null, flora: null };
  const t = findScanTarget({ site, here, eye, forward, known: none });
  assert.ok(t, 'something to scan');
  assert.equal(t.kind, 'formation');
  assert.ok(t.point.distanceTo(here) <= t.reach);
  const again = findScanTarget({ site, here, eye, forward, known: { ...none, formation: [t.id] }, keep: t });
  assert.ok(!again || again.id !== t.id, 'recorded things are not offered again');
  const far = here.clone().normalize().negate().multiplyScalar(body.radius); // the other side of the world
  const away = findScanTarget({ site, here: far, eye: far, forward, known: none });
  assert.ok(!away || away.point.distanceTo(far) <= away.reach);
});

test('cards are clean: a title, a one-sentence lede and labelled facts', () => {
  const body = world((b) => faunaFor(b).species.length > 2 && floraFor(b).species.length);
  const fauna = faunaFor(body), flora = floraFor(body), site = { fauna: { species: fauna.species } };
  const cards = [
    ...fauna.species.map((ref) => cardFor({ kind: 'fauna', ref }, site, body)),
    ...flora.species.map((ref) => cardFor({ kind: 'flora', ref }, site, body)),
  ];
  for (const c of cards) {
    assert.ok(c.title && c.lede, c.title);
    assert.ok(c.lede.split(/[.!?]\s/).length === 1, `one sentence: ${c.lede}`);
    for (const [k, v] of c.facts) assert.ok(k && v && !/undefined|null|NaN/.test(String(v)), `${c.title}: ${k} = ${v}`);
  }
  const animal = cards[0];
  assert.ok(animal.facts.some(([k]) => k === 'Diet') && animal.facts.some(([k]) => k === 'Active'));
});
