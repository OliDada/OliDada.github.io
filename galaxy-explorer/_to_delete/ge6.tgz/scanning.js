// Scanning on foot: what is close enough to scan, and the card that describes it.
// game.js asks findScanTarget() a few times a second, shows the ◎ marker on the
// result (scan-ui.js), and on E runs a short scan, then records the entry and shows
// cardFor(). Works on the landing site built by surface.js.
import * as THREE from "./vendor/three.module.js";

const v = new THREE.Vector3();
const cap = (s) => (s ? s[0].toUpperCase() + s.slice(1) : s);
const firstSentence = (s = "") => (s.match(/^.*?[.!?](?=\s|$)/)?.[0] ?? s);
const names = (list) => (list.length < 3 ? list.join(" and ") : `${list.slice(0, -1).join(", ")} and ${list.at(-1)}`);

// How far away each kind can be scanned from, in metres.
const reachOf = {
    fauna: (sp) => 12 + sp.size * 6,
    flora: (s) => 6 + s.height * 0.6,
    formation: (foot, scale) => foot * scale + 6,
};

// The best thing to scan near `here`: unrecorded, in reach, preferring what you face.
// known: { fauna: [ids], flora: [ids], formation: [ids] } recorded on this world.
// keep: the current target, kept unless something clearly better turns up.
export function findScanTarget({ site, here, eye, forward, known, keep }) {
    const options = [];
    const score = (point, reach) => {
        const d = point.distanceTo(here);
        if (d > reach) return Infinity;
        const facing = v.copy(point).sub(eye).normalize().dot(forward);
        return (d / reach) * (facing > 0.55 ? 1 : facing > 0 ? 2 : 4);
    };
    const lift = (p, h) => p.clone().addScaledVector(p.clone().normalize(), h);
    const { fauna, flora, geology } = site;
    if (fauna?.species.length)
        for (const sp of fauna.species) {
            if (known.fauna.includes(sp.id)) continue;
            const reach = reachOf.fauna(sp);
            for (const p of fauna.positionsOf(sp)) {
                const point = lift(p, sp.altitude[1] > 0 ? 0 : sp.size * 0.7 + 0.3);
                const s = score(point, reach);
                if (s < Infinity) options.push({ kind: "fauna", id: sp.id, ref: sp, point, reach, s });
            }
        }
    if (geology?.placed.length)
        for (const p of geology.placed) {
            if (known.formation.includes(p.formation.id)) continue;
            for (let i = 0; i < p.scales.length; i++) {
                if (!p.scales[i]) continue;
                const base = new THREE.Vector3(p.positions[i * 3], p.positions[i * 3 + 1], p.positions[i * 3 + 2]);
                const point = lift(base, 1.2 + p.scales[i] * 1.5), reach = reachOf.formation(p.foot, p.scales[i]);
                const s = score(point, reach);
                if (s < Infinity) options.push({ kind: "formation", id: p.formation.id, ref: p.formation, point, reach, s });
            }
        }
    if (flora?.placed.length)
        for (const { species, positions } of flora.placed) {
            if (known.flora.includes(species.id)) continue;
            const reach = reachOf.flora(species);
            for (let i = 0; i < positions.length; i += 3) {
                const base = new THREE.Vector3(positions[i], positions[i + 1], positions[i + 2]);
                if (base.distanceTo(here) > reach) continue;
                const point = lift(base, Math.max(0.6, species.height * 0.6));
                const s = score(point, reach);
                if (s < Infinity) options.push({ kind: "flora", id: species.id, ref: species, point, reach, s });
            }
        }
    if (!options.length) return null;
    const best = options.reduce((a, b) => (b.s < a.s ? b : a));
    // Keep the current target (and follow it if it moved) unless the new one is clearly better.
    if (keep) {
        const same = options.filter((o) => o.kind === keep.kind && o.id === keep.id);
        if (same.length) {
            const near = same.reduce((a, b) => (b.point.distanceTo(keep.point) < a.point.distanceTo(keep.point) ? b : a));
            if (near.s <= best.s * 1.6) return near;
        }
    }
    return best;
}

// Where a moving animal is now (the nearest of its kind to where it was).
export function followTarget(site, t) {
    if (t.kind !== "fauna") return t.point;
    const list = site.fauna?.positionsOf(t.ref) || [];
    if (!list.length) return t.point;
    const p = list.reduce((a, b) => (b.distanceTo(t.point) < a.distanceTo(t.point) ? b : a));
    return p.clone().addScaledVector(p.clone().normalize(), t.ref.altitude[1] > 0 ? 0 : t.ref.size * 0.7 + 0.3);
}

export const KIND_WORDS = { fauna: "animal", flora: "plant", formation: "formation", settlement: "settlement" };

const PLAN_WORDS = {
    quadruped: "Four-legged", hexapod: "Six-legged", biped: "Two-legged", serpent: "Legless, coiling", flyer: "Winged flier",
    floater: "Gas-filled drifter", arachnid: "Eight-legged", slug: "Soft-bodied, gliding", radial: "Radial, no front or back", roller: "Rolls instead of walking",
};
const ACTIVE_WORDS = { diurnal: "By day", nocturnal: "By night", crepuscular: "At dawn and dusk", any: "At any hour" };
const TEMPER_WORDS = { skittish: "Wary: bolts if you come close", curious: "Bold: comes to size you up", indifferent: "Calm: ignores you" };
const FORM_WORDS = {
    tree: "Tree", conifer: "Spire", palm: "Frond", shrub: "Bush", grass: "Grass", succulent: "Water-hoarding pillar", fungus: "Stalked cap",
    stalk: "Pod-stalk", mat: "Microbial mat", mound: "Microbial mound", crystal: "Crystal shard", glasstree: "Glasswood", chimney: "Mineral chimney",
    plume: "Feathery plume", bulb: "Waxy bulb", sheet: "Translucent sail", filament: "Beaded thread", crust: "Tar-dark crust",
};
const chemistry = (c) => (c && c !== "carbon" && c !== "water" ? `${cap(c)}-based, not water` : null);

// The card shown after a scan: { kind, title, lede, facts: [[label, value]], tags: [{ text, tone }] }.
export function cardFor(t, site, body) {
    if (t.kind === "fauna") {
        const sp = t.ref, eco = sp.ecology || {}, all = site.fauna?.species || [];
        const nameOf = (id) => all.find((x) => x.id === id)?.name;
        const prey = (eco.prey || []).map(nameOf).filter(Boolean), hunters = (eco.predators || []).map(nameOf).filter(Boolean);
        return {
            kind: "fauna", title: sp.name, lede: firstSentence(sp.description),
            facts: [
                ["Diet", sp.traits.diet === "filter" ? "Filter-feeder" : cap(sp.traits.diet)],
                ["Body", PLAN_WORDS[sp.plan] || cap(sp.plan)],
                ["Active", ACTIVE_WORDS[eco.activity] || null],
                ["Lives", sp.group > 1 ? `In groups of up to ${sp.group}` : "Alone"],
                ["Temper", eco.stalksYou ? "Stalks explorers on foot" : TEMPER_WORDS[sp.behavior] || null],
                ["Mind", cap(sp.mind)],
                ["Hunts", prey.length ? names(prey) : null],
                ["Hunted by", hunters.length ? names(hunters) : null],
                ["Chemistry", chemistry(sp.chemistry)],
            ].filter(([, x]) => x),
            tags: [eco.stalksYou && { text: "Dangerous", tone: "warn" }, sp.glow > 0.3 && { text: "Glows" }, sp.civilization && { text: "Intelligent", tone: "gold" }].filter(Boolean),
        };
    }
    if (t.kind === "flora") {
        const s = t.ref, h = s.habitat || {};
        return {
            kind: "flora", title: s.name, lede: firstSentence(s.description),
            facts: [
                ["Form", FORM_WORDS[s.form] || cap(s.form)],
                ["Height", `${s.height < 2 ? s.height.toFixed(1) : Math.round(s.height)} m`],
                ["Grows", h.shore ? "Along shorelines" : h.highland ? "On high ground" : h.moist > 0.65 ? "In wet lowlands" : h.moist < 0.38 ? "In dry ground" : "Across temperate ground"],
                ["Chemistry", chemistry(body.physics?.biochemistry)],
            ].filter(([, x]) => x),
            tags: [s.glow > 0.45 && { text: "Glows" }].filter(Boolean),
        };
    }
    if (t.kind === "formation") {
        const f = t.ref;
        return {
            kind: "formation", title: f.name, lede: f.description,
            facts: [["Made of", f.cold ? "Ice" : "Rock"], ["Found", f.near === "shore" ? "On coasts" : f.near === "high" ? "On high ground" : "Anywhere on this world"]],
            tags: [f.rare && { text: "Rare", tone: "gold" }].filter(Boolean),
        };
    }
    // settlement: t.ref is the civilization drawn at the site (structures-mesh.js)
    const c = t.ref;
    return {
        kind: "settlement", title: c.species?.name ? `${c.species.name} builders` : "Settlement", lede: c.description,
        facts: [["Builders", cap(c.tier)], ["Culture", c.culture ? cap(c.culture) : null]].filter(([, x]) => x),
        tags: [{ text: "Intelligent life", tone: "gold" }],
    };
}
