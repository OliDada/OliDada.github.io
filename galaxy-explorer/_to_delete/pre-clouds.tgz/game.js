import * as THREE from "./vendor/three.module.js";
import {
    damp,
    smoothstep,
    smootherstep,
    verticalTarget,
} from "./flight-math.mjs";
import { generateSystem, terrainHeight, cruisePoint } from "./system.mjs";
import { terrainFor } from "./terrain.mjs";
import { buildSurface, disposeSurface } from "./surface.js";
import { createKestrel, updateShipEffects } from "./kestrel.js";
import { createSystemView, buildSystemViewGradually } from "./system-view.js";
import { createTerrainStreamer } from "./planet-lod.js";
import {
    ARRIVE_LY,
    toGalaxy,
    toScene,
    systemEdge,
    starGameRadius,
    createSky,
    createNearStar,
    createDriveStreaks,
    createWorldDots,
} from "./deep-space.js";
import { setupInput } from "./input.js";
import { updateHUD, updateWaypoint } from "./hud.js";
import { createEngineSound } from "./audio.js";
import { orbitClock, systemPositions } from "./orbits.mjs";
import { starById, homeStar } from "./galaxy.mjs";
import {
    loadGalaxyState,
    saveGalaxyState,
    playJump,
    playArrival,
} from "./galaxy-ui.js";
import { createStarMap } from "./starmap.js";
import { createCodex, backfill, coreEntry, floraEntry, faunaEntry, formationEntry, settlementEntry, fieldNoteEntry, worldEntry, signalEntry, behaviourEntry, phenomenonEntry } from "./codex.mjs";
import { coreSample } from "./geology.mjs";
import { UPGRADES, completedWorlds, progress, advanced, recordedOn, jumpRange as rangeFor, suitDamageScale, suitRecoveryScale, heatScale, observeTime, behaviourAlerts, hasFieldGlasses, ZOOM_REACH, radioHearing, decodesSignals, landsBesideLava, exposureScale, exposureOf } from "./upgrades.mjs";
import { BEHAVIOURS, behavioursOf, behaviourNow } from "./ecology.mjs";
import { forecast, eclipseAt } from "./phenomena.mjs";
import { createSkyEvents } from "./sky-events.js";
import { createUpgradeScreen } from "./upgrades-ui.js";
import { findScanTarget, followTarget, cardFor, wordFor, titleFor, verbFor } from "./scanning.js";
import { createScanUI } from "./scan-ui.js";
import { civilizationOf, colonistOf } from "./civilizations.mjs";

// Surface flight uses coordinates relative to the current world; space travel is continuous.
const $ = (id) => document.getElementById(id);
const coarsePointer = matchMedia("(pointer: coarse)").matches; // phones and tablets
const clamp = THREE.MathUtils.clamp;
const Y = new THREE.Vector3(0, 1, 0);
// Which star are we at? ?star= (galaxy chart), ?seed= (off-chart system), else the saved position or home.
const params = new URLSearchParams(location.search);
const galaxyState = loadGalaxyState();
let currentStar = starById(params.get("star"));
let offChart = !currentStar && params.get("seed") !== null;
if (!currentStar) currentStar = starById(galaxyState.current) || homeStar();
if (!offChart) {
    galaxyState.current = currentStar.id;
    galaxyState.visited.add(currentStar.id);
    saveGalaxyState(galaxyState);
    if (params.get("star") !== currentStar.id)
        try {
            history.replaceState(null, "", `?star=${currentStar.id}`);
        } catch {} // some hosts (sandboxed frames) don't allow query strings
}
let system = generateSystem(offChart ? params.get("seed") : currentStar.seed);
// The galaxy star whose system is loaded. An off-chart test system (?seed=)
// sits at your last charted star, but is not that star's real system.
let loadedId = offChart ? null : currentStar.id;
// &world=planet-1 starts above a specific world (handy for sharing a planet).
// Giants have no surface, so they are never the world you are at.
let activeBody =
    system.bodies.find((b) => b.id === params.get("world") && !b.giant) ||
    system.bodies.find((b) => b.id === system.startId);
let RADIUS = activeBody.radius;
// The codex: everything documented in every system, and the upgrades it unlocks
// (codex.mjs, upgrades.mjs, upgrades-ui.js; plan in PROGRESSION.md).
const codex = createCodex();
if (!codex.backfilled) backfill(codex);
codex.add(worldEntry(system, activeBody));
const upgradeScreen = createUpgradeScreen({
    codex,
    onOpen: () => { keys.clear(); if (starMap?.isOpen) starMap.close(); },
    onUnlock: (id) => applyUpgrade(id),
    touch: coarsePointer,
});
// Records a codex entry and works out what it moved forward:
// { added, ready (an upgrade that just became ready), moved, progressText, text }.
// text is a sentence to append to a toast ("" if nothing to say).
function recordInfo(entry) {
    const before = progress(codex.entries, codex.unlocked);
    if (!codex.add(entry)) return { added: false, text: "" };
    const moved = advanced(before, progress(codex.entries, codex.unlocked));
    upgradeScreen.refresh();
    updateTally(true);
    const ready = moved.find((m) => m.ready);
    const m = moved.find((x) => x.id === codex.tracked) || moved.find((x) => x.have < x.count) || moved[0];
    const s = m && m.have >= m.count && m.spread.find((x) => x.have < x.need);
    const progressText = m ? (s ? `${s.have} of ${s.need} ${s.label}` : `${m.label} · ${m.have}/${m.count}`) : "";
    const text = ready ? ` Upgrade ready: ${ready.name}. Open Upgrades (U).` : m ? ` Counts toward ${m.name} (${s ? progressText : `${m.have} / ${m.count}`}).` : "";
    return { added: true, ready, moved: m, progressText, text };
}
const record = (entry) => recordInfo(entry).text;
function applyUpgrade(id) {
    const u = UPGRADES[id];
    if (id.startsWith("jumpDrive")) starMap?.setRange?.(rangeFor(codex.unlocked));
    updateTally(true);
    toast(u.status === "planned" ? `${u.name} unlocked. Its effect is not built yet (see PROGRESSION.md).` : `${u.name} installed. ${u.effect}`, 6);
}
const vec = (x = 0, y = 0, z = 0) => new THREE.Vector3(x, y, z);
// Where every body is right now (orbits.mjs). Coordinates in the scene are
// relative to the world you are at (worldOrigin).
let orbitTime = orbitClock(),
    positions = systemPositions(system, orbitTime);
const positionOf = (body) => vec(...positions.get(body.id));
let worldOrigin = positionOf(activeBody);
let signalNormal = vec(...terrainFor(activeBody).site); // dry, level ground near the signal
let landingNormal = vec(...terrainFor(activeBody).landing); // the landing pad: dry, level ground beside the site (terrain.mjs)
const heightAt = (n) => terrainHeight(activeBody, n);
const surfaceRadius = (n) => RADIUS + heightAt(n);
const surfacePoint = (n, offset = 0) =>
    n.clone().multiplyScalar(surfaceRadius(n) + offset);
const tangent = (forward, up) =>
    forward.clone().addScaledVector(up, -forward.dot(up)).normalize();
let renderer;
try {
    renderer = new THREE.WebGLRenderer({
        canvas: $("world"),
                antialias: true,
        powerPreference: "high-performance",
        // Keeps depth precise across huge distances, so distant seas and coastlines don't flicker.
        logarithmicDepthBuffer: true,
    });
} catch (error) {
    $("error").hidden = false;
    $("errorMessage").textContent =
        "This browser could not create a WebGL renderer. Try a browser with hardware acceleration enabled.";
    throw error;
}
renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;
const scene = new THREE.Scene();
scene.background = new THREE.Color("#07101d");
const camera = new THREE.PerspectiveCamera(
    58,
    innerWidth / innerHeight,
    0.08,
    90000,
);
const hemi = new THREE.HemisphereLight(0xb6dfdf, 0x4c3844, 2.0);
scene.add(hemi);
// Sunlight takes the star's colour: red dwarfs cast warm, dim-looking light.
const sun = new THREE.DirectionalLight(
    new THREE.Color(system.star.color).lerp(new THREE.Color(0xffffff), 0.45),
    3.1,
);
sun.position.set(-600, 550, 350);
scene.add(sun);
const fill = new THREE.DirectionalLight(0x749bd5, 0.65);
fill.position.set(200, -100, -300);
scene.add(fill);

// The landing site around the current world's signal (surface.js), built on arrival.
// The last few sites are kept, so hopping between a moon and its planet (or coming
// back) doesn't rebuild them, and a cruise builds its destination's site on the way.
let site = null;
const siteCache = new Map(); // body id -> site, oldest first
// The surface of the world you are flying toward (rocks, plants, formations,
// settlements, its glowing rim), shown from a few kilometres out so it grows
// into view as you approach instead of appearing all at once when you reach orbit.
let approachSite = null,
    approachBody = null,
    siteBody = null; // the world `site` belongs to
function makeSite(body) {
    const R = body.radius, t = terrainFor(body), signal = vec(...t.site);
    return buildSurface({
        body,
        radius: R,
        signalNormal: signal,
        landingNormal: vec(...t.landing),
        surfacePoint: (n, offset = 0) => n.clone().multiplyScalar(R + t.surface(n) + offset),
        coarse: coarsePointer,
        colonist: colonistOf(system, body),
    });
}
function clearSites() {
    if (site) scene.remove(site.group);
    for (const s of siteCache.values()) disposeSurface(s.group);
    siteCache.clear();
    site = siteBody = null;
    approachSite = approachBody = null;
}
// A world's surface, built once and kept for the last few worlds.
function siteFor(body) {
    const s = siteCache.get(body.id) ?? makeSite(body);
    siteCache.delete(body.id);
    siteCache.set(body.id, s); // now the newest
    for (const [id, old] of siteCache) {
        if (siteCache.size <= 3) break;
        if (old === s || old === site || old === approachSite) continue;
        disposeSurface(old.group);
        siteCache.delete(id);
    }
    return s;
}
function buildSite() {
    const old = site, oldBody = siteBody;
    const next = siteFor(activeBody);
    if (approachSite === next) approachSite = approachBody = null; // it was already in view
    if (old && old !== next) {
        // The world you just left stays in view, as the nearby one (if it is
        // still close, updateApproachSite keeps it; otherwise it is removed).
        if (approachSite) scene.remove(approachSite.group);
        approachSite = old;
        approachBody = oldBody;
        old.halo.farFrom.value = oldBody.radius + 3500;
        old.halo.farTo.value = oldBody.radius + 5800;
    }
    site = next;
    siteBody = activeBody;
    site.group.position.set(0, 0, 0);
    site.halo.farFrom.value = 1e9;
    site.halo.farTo.value = 1e9 + 1;
    site.group.visible = true;
    scene.add(site.group);
    if (!activeBody.giant) codex.add(worldEntry(system, activeBody, siteTotals()));
}
// Every world and the star of the system you are in (system-view.js). Terrain
// tiles for every system are built by one shared pool of background threads.
const streamer = createTerrainStreamer();
let systemView = createSystemView(scene, system, streamer, { coarse: coarsePointer });
let edge = systemEdge(system); // beyond this (metres from the star) is interstellar space
// The real stars of the galaxy, seen from where you are (deep-space.js).
const sky = createSky(scene, renderer);
const nearStar = createNearStar(scene);
const streaks = createDriveStreaks(scene, 340);
// Dust and ice motes rushing past near worlds: they move at your real speed, so
// going faster is something you see, not just a number.
const spaceDust = createDriveStreaks(scene, 80, { R: 80, L: 300, min: 10, color: 0xe4f2ec });
const worldDots = createWorldDots(scene);
const starPoint = (star) => [star.x, star.y, star.z];
sky.update(starPoint(currentStar), camera, currentStar.id);
// Moves every body to where it is now. Near a world you travel with it, so
// nothing changes locally; in free space and on cruise the ship holds its
// course through the system while the world you left moves on.
function advanceOrbits() {
    orbitTime = orbitClock();
    positions = systemPositions(system, orbitTime);
    const origin = positionOf(activeBody),
        shift = origin.clone().sub(worldOrigin);
    if (mode === "space" || mode === "transit") {
        shipPosition.sub(shift);
        camera.position.sub(shift);
    }
    if (holding && mode === "space") {
        const now = positionOf(holding.body), moved = now.clone().sub(holding.last);
        shipPosition.add(moved);
        camera.position.add(moved);
        holding.last.copy(now);
    } else holding = null;
    worldOrigin.copy(origin);
    positionSystem();
}
function positionSystem() {
    systemView.place(positions, worldOrigin);
    if (mode !== "deep") sun.position.copy(systemView.starMesh.position);
}


const kestrel = createKestrel();
const { ship, shipShadow, dust } = kestrel;
scene.add(ship, shipShadow, dust);

let verticalSpeed = 0,
    flightPitch = 0,
    bankAngle = 0,
    turnVelocity = 0,
    maneuver = null;
// Mouse / drag steering in flight: movement is queued here and eased into the
// ship's heading over the next frames, so mice and trackpads both turn smoothly.
let steerYaw = 0,
    steerPitch = 0,
    aimPitch = 0, // nose angle held in atmospheric flight, set with the mouse
    strafeSpeed = 0, // sideways thrust near worlds (A/D in space)
    lastMouseSteer = -1e9,
    lastFreeLook = -1e9,
    invertPitch = false;
// Speed feel and orbit transitions (camera).
let spaceBlend = 0, // 0 = flying near a world's surface, 1 = in space; eases between the two
    rushLevel = 0, // 0..1, how fast you are going for the camera
    reveal = 0, // camera pull-back as you break orbit
    exitGlide = 0, // the climb carrying on for a moment after breaking orbit
    exitClimb = 0,
    lastLocal = null,
    lastBodyId = null,
    orbitEntry = 0, // 1 right after dropping into orbit from space, fading to 0 over ~3 s
    camBack = null, // the camera's (smoothed) direction behind and ahead of the ship
    camAhead = null;
const flowVel = new THREE.Vector3(); // ship velocity relative to the world it is near
try { invertPitch = localStorage.getItem("elsewhere.invertPitch") === "1"; } catch {}
{
    const box = document.getElementById("invertPitch");
    if (box) {
        box.checked = invertPitch;
        box.addEventListener("change", () => {
            invertPitch = box.checked;
            try { localStorage.setItem("elsewhere.invertPitch", invertPitch ? "1" : "0"); } catch {}
        });
    }
}

let started = false,
    mode = "flight",
    speed = 0,
    autoApproach = false,
    stage = 0,
    discovered = false,
    completed = false;
buildSite();
positionSystem();
// Survey records are saved per system.
let saveKey,
    records = new Set(),
    visited = new Set(),
    catalogue = {}, // plant species catalogued per world: { bodyId: [speciesId] }
    bestiary = {}, // animal species observed per world: { bodyId: [speciesId] }
    traces = {}, // worlds where you have seen what an intelligent species built: { bodyId: tier name }
    strata = {}; // rock and ice formations recorded per world: { bodyId: [formationId] }
function loadSurvey(arrivedAt) {
    saveKey = `elsewhere-system-${system.seed}`;
    let saved = {};
    try {
        saved = JSON.parse(localStorage.getItem(saveKey) || "{}");
    } catch {}
    const known = (id) => system.bodies.some((b) => b.id === id);
    records = new Set((saved.records || []).filter(known));
    visited = new Set([...(arrivedAt ? [arrivedAt.id] : []), ...(saved.visited || []).filter(known)]);
    catalogue = saved.flora || {};
    bestiary = saved.fauna || {};
    traces = saved.traces || {};
    strata = saved.geology || {};
}
loadSurvey(activeBody);
discovered = records.has(activeBody.id);
let selectedBody = null, // the world you chose as your destination, if any
    travel = null;
const spaceUp = Y.clone();
function saveSurvey() {
    try {
        localStorage.setItem(
            saveKey,
            JSON.stringify({
                records: [...records],
                visited: [...visited],
                flora: catalogue,
                fauna: bestiary,
                traces,
                geology: strata,
            }),
        );
    } catch {}
}
function setDiscoveryText(body) {
    $("discoveryEyebrow").textContent =
        `FIELD NOTE / ${body.name.toUpperCase()}`;
    $("discoveryTitle").textContent = body.title;
    $("discoveryText").textContent = body.note;
    $("discoveryQuote").textContent = body.message;
}

$("logBtn").hidden = !discovered;
$("logBtn").onclick = () => {
    keys.clear();
    setDiscoveryText(activeBody);
    $("discovery").showModal();
};
let shipPosition = landingNormal.clone().multiplyScalar(RADIUS + 150),
    shipForward = tangent(
        signalNormal.clone().sub(landingNormal),
        landingNormal,
    );
let playerNormal = landingNormal.clone(),
    playerForward = vec(0, 0, -1),
    lookPitch = 0;
let orbitYaw = 0,
    orbitPitch = 0.18;
let toastTime = 0,
    animationTime = 0,
    previousTime = performance.now(),
    bob = 0;
const keys = new Set();
const clockBasis = new THREE.Matrix4();
function orientShip(dt = 1) {
    const up = shipPosition.clone().normalize();
    shipForward = tangent(shipForward, up);
    const right = shipForward.clone().cross(up).normalize();
    clockBasis.makeBasis(right, up, shipForward.clone().negate());
    const attitude = new THREE.Quaternion().setFromRotationMatrix(clockBasis);
    attitude.multiply(
        new THREE.Quaternion().setFromAxisAngle(
            vec(1, 0, 0),
            flightPitch + clamp(verticalSpeed * 0.004, -0.1, 0.1),
        ),
    );
    attitude.multiply(
        new THREE.Quaternion().setFromAxisAngle(vec(0, 0, 1), bankAngle),
    );
    // Just after entering orbit the ship rolls gently to the world's horizon
    // instead of snapping to it.
    ship.quaternion.slerp(attitude, 1 - Math.exp(-dt * (9 - 8.2 * smoothstep(orbitEntry))));
    ship.position.copy(shipPosition);
    shipShadow.position.copy(surfacePoint(up, 0.13));
    shipShadow.quaternion.setFromUnitVectors(vec(0, 0, 1), up);
    shipShadow.material.opacity = clamp(
        0.3 - (shipPosition.length() - surfaceRadius(up)) * 0.007,
        0,
        0.25,
    );
}
function altitude() {
    const n = shipPosition.clone().normalize();
    return shipPosition.length() - surfaceRadius(n) - 1.7;
}
function distanceToSignal() {
    return (
        Math.acos(
            clamp(
                (mode === "walk"
                    ? playerNormal
                    : shipPosition.clone().normalize()
                ).dot(signalNormal),
                -1,
                1,
            ),
        ) * RADIUS
    );
}
function toast(message, seconds = 4) {
    $("toast").textContent = message;
    $("toast").classList.add("visible");
    toastTime = seconds;
}
function setStage(next) {
    stage = next;
    const entries = [
        ["Follow the signal", "Something is transmitting from the surface."],
        [
            "Investigate the surface",
            "Leave the ship and follow the signal on foot.",
        ],
        ["Return to Kestrel", "Signal recorded. Your ship is waiting nearby."],
        [
            "A beginning, not an ending",
            `Signal recorded. Open the star map (M) for another world, or zoom out on it (G) to jump to another star.`,
        ],
    ];
    // The objective panel now shows the next upgrade (upgrades-ui.js); the signal
    // still guides you through the waypoint and the action button.
    void entries;
}
function modalOpen() {
    return $("help").open || $("discovery").open || $("starMap").open || upgradeScreen.isOpen;
}
function start() {
    if (started) return;
    started = true;
    $("hud").inert = false;
    $("intro").inert = true;
    $("intro").classList.add("hidden");
    document.body.classList.add("playing");
    toast(
        "Welcome to " +
            system.name +
            ". Press M to choose a world, or explore " +
            activeBody.name +
            ".",
    );
}
function approach() {
    if (mode !== "flight") return;
    autoApproach = !autoApproach;
    toast(
        autoApproach
            ? "Approach assist engaged. Manual controls cancel it."
            : "Approach assist disengaged.",
    );
}
function act() {
    if (!started || modalOpen()) return;
    if (mode === "deep") {
        if (course) toggleAutopilot();
        else openGalaxy();
        return;
    }
    if (mode === "space") {
        cruiseOrAutopilot();
        return;
    }
    if (mode === "transit") {
        cancelCruise();
        return;
    }
    if (mode === "flight") {
        if (altitude() > 32) {
            toast("Descend below 32 m with F, or use Find landing site.");
            return;
        }
        if (Math.abs(speed) > 18) {
            toast("Slow below 18 m/s. Release thrust or hold X to brake.");
            return;
        }
        // A conservative slope check rejects exceptionally steep generated ridges.
        const n = shipPosition.clone().normalize(),
            side = shipForward.clone().cross(n).normalize();
        const slope = Math.abs(
            heightAt(n.clone().addScaledVector(side, 0.018).normalize()) -
                heightAt(n.clone().addScaledVector(side, -0.018).normalize()),
        );
        if (slope > 3.5) {
            toast("Terrain too steep. Move toward flatter ground.");
            return;
        }
        const wet = terrainFor(activeBody).isLiquid(n);
        if (wet && !floatsHere()) {
            toast(
                terrainFor(activeBody).liquid === "lava"
                    ? "That is molten rock. Find solid ground to land."
                    : codex.unlocked.has("petrel")
                      ? "The Petrel floats only on water; this sea is something else. Find solid ground."
                      : "Kestrel cannot land on water. Find solid ground.",
            );
            return;
        }
        afloat = wet;
        // The world's own landing pad is always allowed: only picking your own spot by lava needs Heat plating.
        if (!wet && !landsBesideLava(codex.unlocked) && n.angleTo(landingNormal) * RADIUS > 40 && nearLava(n)) {
            toast("Too close to lava: the hull would overheat. Move away from it, or install Heat plating to land here.", 5);
            return;
        }
        autoApproach = false;
        keys.clear();
        maneuver = {
            time: 0,
            duration: 3.8,
            start: shipPosition.clone(),
            normal: n.clone(),
            height: shipPosition.length() - surfaceRadius(n) - 1.7,
        };
        mode = "landing";
        toast("Landing sequence. Gear down; settling onto the surface.");
    } else if (mode === "landed") {
        keys.clear();
        speed = 0;
        verticalSpeed = 0;
        maneuver = {
            time: 0,
            duration: 3.6,
            start: shipPosition.clone(),
            normal: shipPosition.clone().normalize(),
        };
        mode = "takeoff";
        toast("Lift engines charging. Clearing the surface.");
    } else if (mode === "walk") {
        const shipDistance =
            surfacePoint(playerNormal).distanceTo(shipPosition);
        if (distanceToSignal() < 9 && !discovered) {
            discover();
        } else if (scanTarget?.known) {
            showScanCard(scanTarget, null);
        } else if (scanTarget) {
            // Something new: holding E scans it (updateScan).
        } else if (shipDistance < 9) {
            mode = "landed";
            speed = 0;
            verticalSpeed = 0;
            toast("Back aboard Kestrel. Press L to lift off.");
        } else if (distanceToSignal() < 9) {
            discover();
        }
    }
}
// Petrel: sets down and floats on seas of liquid water (not methane, ammonia or sulfur).
let afloat = false;
const floatsHere = () => {
    const t = terrainFor(activeBody);
    return codex.unlocked.has("petrel") && t.liquid === "water" && (t.solvent ?? "water") === "water";
};
// Lava within ~25 m of a point on the ground (Heat plating lets the Kestrel land there anyway).
function nearLava(n) {
    const t = terrainFor(activeBody);
    if (t.liquid !== "lava") return false;
    const a = tangent(Math.abs(n.y) < 0.9 ? vec(0, 1, 0) : vec(1, 0, 0), n), b = n.clone().cross(a);
    for (const d of [8, 16, 25])
        for (let i = 0; i < 12; i++) {
            const k = (i / 12) * Math.PI * 2;
            const p = n.clone().addScaledVector(a, (Math.cos(k) * d) / RADIUS).addScaledVector(b, (Math.sin(k) * d) / RADIUS).normalize();
            if (t.isLiquid(p)) return true;
        }
    return false;
}
function interact() {
    if (!started || modalOpen()) return;
    if (mode === "landed" && afloat) {
        toast("You are afloat: the water is too deep to walk. Take off and land on shore to go on foot.", 4);
        return;
    }
    if (mode === "landed") {
        const up = shipPosition.clone().normalize(),
            right = shipForward.clone().cross(up).normalize();
        playerNormal = shipPosition
            .clone()
            .addScaledVector(right, 5.5)
            .addScaledVector(shipForward, 2)
            .normalize();
        playerForward = tangent(
            signalNormal.clone().sub(playerNormal),
            playerNormal,
        );
        if (playerForward.lengthSq() < 0.1)
            playerForward = tangent(shipForward, playerNormal);
        lookPitch = 0;
        mode = "walk";
        if (stage === 0) setStage(1);
        jumpHeight = 0;
        jumpVelocity = 0;
    } else if (mode === "walk") act();
}
function discover() {
    discovered = true;
    records.add(activeBody.id);
    saveSurvey();
    const noteText = record(fieldNoteEntry(system, activeBody));
    if (noteText) toast(noteText.trim(), 8);
    setDiscoveryText(activeBody);
    $("logBtn").hidden = false;
    setStage(2);
    keys.clear();
    $("discovery").showModal();
}
$("startBtn").onclick = start;
$("approachBtn").onclick = approach;
$("actionBtn").onclick = () => (mode === "landed" ? interact() : act());
$("helpBtn").onclick = () => {
    keys.clear();
    $("help").showModal();
};
$("closeHelp").onclick = () => $("help").close();
$("closeDiscovery").onclick = () => $("discovery").close();
$("resetBtn").onclick = () => {
    try {
        localStorage.removeItem(saveKey);
    } catch {}
    location.reload();
};
const canvas = $("world");
const input = setupInput({
    keys,
    canvas,
    started: () => started,
    mode: () => mode,
    modalOpen,
    on: {
        map: () => (starMap.isOpen ? starMap.close() : openMap()),
        galaxy: () => (starMap.isOpen ? starMap.close() : openGalaxy()),
        cruise: () => cruiseOrAutopilot(),
        clear: () => clearTarget(),
        help: () => {
            if ($("help").open) $("help").close();
            else {
                keys.clear();
                $("help").showModal();
            }
        },
        act,
        interact,
        look(dx, dy, k) {
            if (mode === "walk") {
                const fine = camera.fov / 70; // zoomed in (field glasses), the view turns more finely
                playerForward.applyAxisAngle(playerNormal, -dx * 0.004 * k * fine);
                lookPitch = clamp(lookPitch - dy * 0.003 * k * fine, -1.15, 1.1);
            } else if (mouseSteers()) {
                steerYaw -= dx * 0.0032 * k;
                steerPitch -= dy * 0.0032 * k * (invertPitch ? -1 : 1);
                lastMouseSteer = performance.now();
            } else {
                orbitYaw -= dx * 0.005 * k;
                orbitPitch = clamp(orbitPitch + dy * 0.004 * k, -0.25, 1.15);
                lastFreeLook = performance.now();
                steerYaw = steerPitch = 0;
            }
        },
        manualControl: () => (autoApproach = false),
        toast,
        pick: (x, y) => pickAt(x, y),
        cycle: () => cycleTarget(),
        upgrades: () => { if (!$("help").open && !$("discovery").open) upgradeScreen.toggle(); },
    },
});
document.addEventListener("visibilitychange", () => (previousTime = performance.now()));


const engine = createEngineSound({
    button: $("soundBtn"),
    label: $("soundLabel"),
    onError: () => toast("Audio is unavailable in this browser."),
});


function refreshWorldLabels() {
    $("worldName").textContent = activeBody.name.toUpperCase();
    $("worldType").textContent =
        activeBody.type + " · " + system.name + " system";
    $("seedInput").value = system.seed;
    $("introDescription").textContent =
        `${system.bodies.length} worlds orbit ${system.star.name}, a ${system.star.physics.spectralClass} star. Start above ${activeBody.name}, or open your map and chart a different course.`;
    $("systemCoordinates").textContent = offChart
        ? `${system.name.toUpperCase()} SYSTEM / OFF-CHART SEED ${system.seed}`
        : `${system.name.toUpperCase()} SYSTEM / ${(Math.hypot(currentStar.x, currentStar.y) / 1000).toFixed(1)}K LY FROM THE CORE`;
}
let lastSwitch = -10; // animationTime of the last change of world (see the neighbour check in flight)
function switchWorld(body, globalPosition) {
    // The ship keeps its momentum and heading across the change of world, so arriving
    // (or crossing from a moon to its planet) is seamless rather than a dead stop.
    const oldUp = mode === "flight" ? shipPosition.clone().normalize() : spaceUp.clone();
    const velocity = shipForward.clone().multiplyScalar(speed * (mode === "flight" ? Math.cos(flightPitch) : 1)).addScaledVector(oldUp, verticalSpeed);
    lastSwitch = animationTime;
    const oldOrigin = worldOrigin.clone();
    activeBody = body;
    RADIUS = body.radius;
    worldOrigin = positionOf(body);
    signalNormal = vec(...terrainFor(body).site);
    landingNormal = vec(...terrainFor(body).landing);
    buildSite();
    positionSystem();
    shipPosition.copy(globalPosition).sub(worldOrigin);
    camera.position.add(oldOrigin).sub(worldOrigin);
    const arrivalNormal =
        shipPosition.lengthSq() > 0.01
            ? shipPosition.clone().normalize()
            : signalNormal.clone();
    const safeRadius = surfaceRadius(arrivalNormal) + 4;
    if (shipPosition.length() < safeRadius)
        shipPosition.copy(arrivalNormal.multiplyScalar(safeRadius));
    const n = shipPosition.clone().normalize();
    const along = velocity.clone().addScaledVector(n, -velocity.dot(n));
    // From space, keep the way the nose points (heading and pitch), so the ship
    // doesn't swing round as it meets the world.
    const fromSpace = mode === "space";
    const nose = shipForward.clone(),
        noseAlong = nose.clone().addScaledVector(n, -nose.dot(n));
    if (fromSpace && noseAlong.length() > 0.15) shipForward = noseAlong.clone().normalize();
    else if (along.length() > 2) shipForward = along.clone().normalize();
    else {
        shipForward = tangent(shipForward.clone(), n);
        if (shipForward.lengthSq() < 0.01) shipForward = tangent(signalNormal.clone().sub(n), n);
        if (shipForward.lengthSq() < 0.01) shipForward = tangent(vec(0, 0, -1), n);
    }
    // Arriving from space keeps most of your momentum and the angle you came in
    // at; flight drag then eases you down to flying speed and the nose levels out.
    speed = fromSpace ? clamp(along.dot(shipForward), -100, 320) : Math.min(along.length(), 320);
    verticalSpeed = clamp(velocity.dot(n), -120, 120);
    flightPitch = fromSpace
        ? clamp(Math.asin(clamp(nose.dot(n), -1, 1)), -1.35, 1.35)
        : clamp(Math.atan2(velocity.dot(n), Math.max(along.length(), 1)), -0.65, 0.65);
    aimPitch = clamp(flightPitch, -0.65, 0.65);
    if (fromSpace) orbitEntry = 1;
    lastMouseSteer = Math.min(lastMouseSteer, performance.now() - 1000); // levels out soon
    exitGlide = 0;
    turnVelocity = 0;
    autoApproach = false;
    mode = "flight";
    kestrel.gear = 0;
    discovered = records.has(body.id);
    if (target?.id === body.id) target = null; // arrived
    if (selectedBody?.id === body.id) selectedBody = null;
    completed = discovered;
    setStage(discovered ? 3 : 0);
    $("logBtn").hidden = !discovered;
    visited.add(body.id);
    const worldNote = record(worldEntry(system, body));
    saveSurvey();
    refreshWorldLabels();
    orientShip(0); // place the ship; its attitude turns to the new "up" smoothly over the next frames
    toast(
        `Arrived at ${body.name}. Fly down, or use Find landing site.${worldNote}`,
    );
}
function orientSpace(dt) {
    // Keep "up" at right angles to the nose by carrying the previous up along with
    // it. Rebuilding it from a fixed axis flipped the ship whenever the nose pointed
    // straight up or down (short cruises between a moon and its planet).
    spaceUp.addScaledVector(shipForward, -spaceUp.dot(shipForward));
    if (spaceUp.lengthSq() < 1e-6) spaceUp.copy(vec(0, 1, 0).applyQuaternion(ship.quaternion)).addScaledVector(shipForward, -vec(0, 1, 0).applyQuaternion(ship.quaternion).dot(shipForward));
    if (spaceUp.lengthSq() < 1e-6) spaceUp.copy(Math.abs(shipForward.y) < 0.9 ? Y : vec(1, 0, 0)).addScaledVector(shipForward, -(Math.abs(shipForward.y) < 0.9 ? shipForward.y : shipForward.x));
    spaceUp.normalize();
    const right = shipForward.clone().cross(spaceUp).normalize();
    clockBasis.makeBasis(right, spaceUp, shipForward.clone().negate());
    const attitude = new THREE.Quaternion().setFromRotationMatrix(clockBasis);
    attitude.multiply(
        new THREE.Quaternion().setFromAxisAngle(vec(0, 0, 1), bankAngle),
    );
    ship.quaternion.slerp(attitude, 1 - Math.exp(-dt * 6));
    ship.position.copy(shipPosition);
    shipShadow.visible = false;
}
const GIANT_CLEARANCE = 250; // closest approach to a giant's cloud tops
function updateSpace(dt) {
    // A selected world, or else your course star: hold the nose on it whenever
    // you are not steering.
    const aim = target ? positionOf(target).sub(worldOrigin).sub(shipPosition).normalize() : course ? towardStar(course) : null;
    if (aim && !steering()) turnToward(aim, dt);
    const autoThrust = autopilot && course && !target && !keys.has("KeyW") && !keys.has("KeyS") && !keys.has("KeyX");
    if (holding && ["KeyW", "KeyS", "KeyR", "KeyF", "KeyX"].some((k) => keys.has(k))) holding = null; // flying off
    // Near worlds A/D slide the ship sideways (handy for lining up a scan or an
    // approach); the mouse or the arrow keys turn it.
    const yaw = arrowTurn();
    const strafe = (keys.has("KeyD") ? 1 : 0) - (keys.has("KeyA") ? 1 : 0);
    const m = takeMouseSteer(dt);
    shipForward.applyAxisAngle(spaceUp, yaw * dt * 0.85 + m.yaw);
    const right = shipForward.clone().cross(spaceUp).normalize();
    const pitch =
        (keys.has("ArrowUp") ? 1 : 0) - (keys.has("ArrowDown") ? 1 : 0);
    shipForward.applyAxisAngle(right, pitch * dt * 0.7 + m.pitch).normalize();
    spaceUp.applyAxisAngle(right, pitch * dt * 0.7 + m.pitch).normalize();
    const boost = keys.has("ShiftLeft") || keys.has("ShiftRight"),
        brake = keys.has("KeyX");
    speed = damp(
        speed,
        brake
            ? 0
            : autoThrust
              ? shipForward.dot(aim) > 0.97 ? 900 : 60
              : ((keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0)) *
                  (boost ? 900 : 220),
        brake ? 4 : 1.4,
        dt,
    );
    // Just after breaking orbit the climb carries on and fades, unless you steer
    // it yourself (F, or the brake).
    exitGlide = Math.max(0, exitGlide - dt / 3);
    const lift = ((keys.has("KeyR") ? 1 : 0) - (keys.has("KeyF") ? 1 : 0)) * (boost ? 100 : 35);
    verticalSpeed = damp(
        verticalSpeed,
        brake ? 0 : lift < 0 ? lift : Math.max(lift, exitClimb * smoothstep(exitGlide)),
        exitGlide > 0 ? 1.2 : 3,
        dt,
    );
    strafeSpeed = damp(strafeSpeed, brake ? 0 : strafe * (boost ? 100 : 35), 3, dt);
    bankAngle = damp(bankAngle, clamp(yaw * 0.25 + m.rate * 0.12 - strafe * 0.15, -0.45, 0.45), 4, dt);
    shipPosition
        .addScaledVector(shipForward, speed * dt)
        .addScaledVector(spaceUp, verticalSpeed * dt)
        .addScaledVector(right, strafeSpeed * dt);
    const global = shipPosition.clone().add(worldOrigin);
    // The star's exclusion zone and giants' cloud tops are hard limits. The ship
    // slides along them (no bounce), and slows if it keeps pushing inward.
    const holdOff = (centre, limit, message) => {
        const out = global.clone().sub(centre);
        if (out.length() >= limit) return;
        out.normalize();
        global.copy(centre).addScaledVector(out, limit);
        shipPosition.copy(global).sub(worldOrigin);
        const inward = -shipForward.dot(out);
        if (inward > 0) speed = damp(speed, 0, 6 * inward, dt);
        if (verticalSpeed * spaceUp.dot(out) < 0) verticalSpeed = damp(verticalSpeed, 0, 6, dt);
        if (strafeSpeed * right.dot(out) < 0) strafeSpeed = damp(strafeSpeed, 0, 6, dt);
        if (toastTime <= 0) toast(message);
    };
    holdOff(vec(), system.star.radius + 140, `Stellar exclusion zone. Turn away from ${system.star.name}.`);
    // Close to a star the hull heats up: the view glows and warnings start well
    // before the hard limit above.
    heat = clamp(1 - (global.length() - system.star.radius - 140) / (system.star.radius * 4), 0, 1) * heatScale(codex.unlocked);
    if (heat > 0.35 && toastTime <= 0)
        toast(heat > 0.75 ? `Hull temperature critical. Turn away from ${system.star.name}!` : `Hull temperature rising near ${system.star.name}.`, 2);
    for (const body of system.bodies)
        if (body.giant)
            holdOff(
                positionOf(body),
                body.radius + GIANT_CLEARANCE,
                `${body.name} has no surface: the clouds only thicken into crushing pressure. Its moons are safe to land on.`,
            );
    // Past the outermost orbits lies interstellar space.
    if (global.length() > edge * 0.85 && global.length() < edge && toastTime <= 0)
        toast(`Leaving the ${system.name} system. The star drive engages beyond the outer orbits.`);
    if (global.length() > edge) {
        enterDeep(global);
        return;
    }
    const nearby = system.bodies
        .filter((body) => !body.giant)
        .map((body) => ({
            body,
            clearance: global.distanceTo(positionOf(body)) - body.radius,
        }))
        .sort((a, b) => a.clearance - b.clearance);
    // Heading in toward a world the ship sheds speed as its sky gets close, so
    // reaching orbit is a glide rather than a sudden stop.
    if (nearby.length && nearby[0].clearance < 2200) {
        const toward = positionOf(nearby[0].body).sub(global).normalize();
        if (shipForward.dot(toward) * speed > 0) {
            const cap = 220 + 680 * smoothstep((nearby[0].clearance - 520) / 1600);
            if (Math.abs(speed) > cap) speed = damp(speed, Math.sign(speed) * cap, 3, dt);
        }
    }
    // Orbit begins at 520 m (it ends again above 600 m), high enough for the
    // change of view to happen gradually.
    if (nearby.length && nearby[0].clearance >= 520) nearby.length = 0;
    if (nearby.length) {
        switchWorld(nearby[0].body, global);
        return;
    }
    orientSpace(dt);
}
function beginCruise() {
    if (!started) return;
    if (!selectedBody)
        return void toast("Choose a destination first: press Tab, tap a world, or pick one on the system map (M).");
    if (mode !== "flight" && mode !== "space") {
        toast("Return to your ship and take off before engaging cruise.");
        return;
    }
    const start = shipPosition.clone().add(worldOrigin),
        n = shipPosition.clone().normalize();
    const departure =
        mode === "space"
            ? start.clone()
            : worldOrigin.clone().addScaledVector(n, RADIUS + 650);
    const end = cruiseEnd(selectedBody);
    travel = {
        body: selectedBody,
        start: start.toArray(),
        departure: departure.toArray(),
        end: end.toArray(),
        time: 0,
        duration: 12,
    };
    autoApproach = false;
    keys.clear();
    mode = "transit";
    spaceUp.copy(n);
    starMap.close();
    $("transit").hidden = false;
    $("transitTitle").textContent =
        `BOUND FOR ${selectedBody.name.toUpperCase()}`;
    toast("Cruise engaged. Press T to disengage and fly manually.");
}
function cancelCruise() {
    if (mode !== "transit") return;
    mode = "space";
    travel = null;
    speed = Math.min(speed, 150);
    verticalSpeed = 0;
    $("transit").hidden = true;
    keys.clear();
    toast("Cruise disengaged. Manual spaceflight.");
}
// Where a cruise ends: above the signal, or for giants well above the cloud
// tops, where the whole planet fills the view. Follows the body along its orbit.
function cruiseEnd(body) {
    return positionOf(body).addScaledVector(
        vec(...body.signal),
        body.radius + (body.giant ? body.radius * 0.9 + 500 : 190),
    );
}
function updateCruise(dt) {
    travel.time += dt;
    travel.end = cruiseEnd(travel.body).toArray(); // the destination keeps moving
    const t = clamp(travel.time / travel.duration, 0, 1);
    const next = vec(
        ...cruisePoint(travel.start, travel.departure, travel.end, t),
    ).sub(worldOrigin);
    const delta = next.clone().sub(shipPosition);
    speed = delta.length() / Math.max(dt, 0.001);
    verticalSpeed = 0;
    if (delta.lengthSq() > 0.00001)
        shipForward.lerp(delta.normalize(), 1 - Math.exp(-dt * 3)).normalize();
    shipPosition.copy(next);
    bankAngle = damp(bankAngle, 0, 3, dt);
    // Ease "up" toward the system's up, but only as far as the nose allows (never toward the nose itself).
    const level = Y.clone().addScaledVector(shipForward, -Y.dot(shipForward));
    if (level.lengthSq() > 0.04) spaceUp.lerp(level.normalize(), dt * 0.4 * Math.sqrt(level.lengthSq())).normalize();
    orientSpace(dt);
    // Build the destination's landing site halfway, not in the frame you arrive.
    if (!travel.prepared && t > 0.5) {
        travel.prepared = true;
        if (!travel.body.giant && !siteCache.has(travel.body.id)) siteCache.set(travel.body.id, makeSite(travel.body));
    }
    $("transitProgress").style.width = `${t * 100}%`;
    $("transitPercent").textContent = `${Math.round(t * 100)}%`;
    if (t >= 1) {
        const destination = travel.body,
            global = next.clone().add(worldOrigin);
        travel = null;
        $("transit").hidden = true;
        if (destination.giant) arriveAtGiant(destination);
        else switchWorld(destination, global);
    }
}

// --- Interstellar flight ---------------------------------------------------
// Beyond a system's edge the ship flies between the galaxy's real stars. Its
// position is kept in light years (galactic); the scene stays centred on it.
// The star drive's speed scales with the distance to the nearest star, so
// crossing light years takes a minute or two and arrivals are gentle. Nearing
// a star builds its system in the background; at its edge you fly straight in.
let galactic = null, // ship position (ly) while in deep space
    course = null, // destination star chosen on the galaxy map
    autopilot = false,
    throttle = 0,
    incoming = null; // { star, system, view, ready } being built ahead of arrival
const DRIVE_TIME = 5; // seconds to cover the distance to the nearest star, at full throttle
const PREPARE_LY = 0.4; // start building a system this far out, so its worlds show early
const edgeCache = new Map();
function edgeOf(star) {
    if (star.id === loadedId) return edge;
    let e = edgeCache.get(star.id);
    if (!e) {
        e = systemEdge(generateSystem(star.seed));
        if (edgeCache.size > 200) edgeCache.clear();
        edgeCache.set(star.id, e);
    }
    return e;
}
function enterDeep(global) {
    const out = toGalaxy(global.clone().normalize());
    galactic = starPoint(currentStar).map((v, i) => v + out[i] * ARRIVE_LY * 1.05);
    const shift = shipPosition.clone();
    shipPosition.set(0, 0, 0);
    camera.position.sub(shift);
    mode = "deep";
    throttle = autopilot && course ? 1 : 0.35;
    autopilot = autopilot && !!course;
    systemView.visible = false;
    if (site) site.group.visible = false;
    sky.update(galactic, camera);
    toast(
        course
            ? `Star drive engaged. Press T for autopilot to ${starName(course)}.`
            : "Star drive engaged. Fly toward any star, or set a course on the galaxy map (G).",
        6,
    );
}
const starName = (star) => (star.id === loadedId ? system.name : nameCache(star));
const names = new Map();
function nameCache(star) {
    let n = names.get(star.id);
    if (!n) names.set(star.id, (n = generateSystem(star.seed).name));
    return n;
}
// A course replaces any world you had in focus: the ship now points at the star.
function setCourse(star) {
    if (!star) return clearTarget();
    course = star;
    target = pendingBody = selectedBody = null;
    starMap.close();
    if (mode === "deep") {
        autopilot = true;
        toast(`Course set for ${starName(star)}. Autopilot engaged; steer to take over.`);
    } else
        toast(
            mode === "space"
                ? `Course set for ${starName(star)}. Press T for autopilot: it flies you out of the system and on to the star.`
                : `Course set for ${starName(star)}. Climb above 600 m, then press T for autopilot.`,
            6,
        );
}
function toggleAutopilot() {
    if (!course) return void toast("Set a course on the galaxy map (G) first.");
    autopilot = !autopilot;
    toast(autopilot ? `Autopilot to ${starName(course)}.` : "Autopilot off. Manual flight.");
}
// T and the main button: with a star as your course (and no world in focus),
// they work the autopilot; otherwise they cruise to the selected world.
function cruiseOrAutopilot() {
    if (mode === "deep" || (mode === "space" && course && !target)) toggleAutopilot();
    else if (mode === "transit") cancelCruise();
    else if (mode === "flight" && course && !target) toast("Climb above 600 m to leave orbit, then press T for autopilot.");
    else if (mode === "space" && !selectedBody) cycleTarget();
    else beginCruise();
}
// Where you are in the galaxy (ly): your ship in deep space, else your star.
const viewer = () => (mode === "deep" ? galactic : starPoint(currentStar));
const towardStar = (star) => toScene(starPoint(star).map((v, i) => v - viewer()[i])).normalize();
function startIncoming(star) {
    if (incoming?.view) incoming.view.dispose();
    const job = (incoming = { star, system: generateSystem(star.seed), view: null, ready: false });
    buildSystemViewGradually(scene, job.system, streamer, { coarse: coarsePointer }).then((view) => {
        if (incoming === job) {
            job.view = view;
            job.ready = true;
        } else view.dispose();
    });
}
// The mouse (or a drag on touch) steers while flying, unless Q / the Look button
// is held for looking around, or an automatic approach is flying the ship.
const mouseSteers = () => (mode === "flight" || mode === "space" || mode === "deep") && !keys.has("KeyQ") && !autoApproach;
// This frame's share of the queued mouse steering, in radians.
function takeMouseSteer(dt) {
    const f = 1 - Math.exp(-dt * 12);
    const m = { yaw: steerYaw * f, pitch: steerPitch * f, rate: 0 };
    steerYaw -= m.yaw;
    steerPitch -= m.pitch;
    m.rate = m.yaw / Math.max(dt, 1e-3); // turn rate, for banking
    return m;
}
const arrowTurn = () => (keys.has("ArrowLeft") ? 1 : 0) - (keys.has("ArrowRight") ? 1 : 0);
// Any steering input: keys, joystick, mouse. (Near worlds A/D slide sideways, so
// they don't count there.)
const steering = () =>
    (mode !== "space" && (keys.has("KeyA") || keys.has("KeyD"))) ||
    keys.has("ArrowUp") || keys.has("ArrowDown") || keys.has("ArrowLeft") || keys.has("ArrowRight") ||
    performance.now() - lastMouseSteer < 500;
// Smoothly turns the ship's nose toward a direction, keeping it upright.
function turnToward(want, dt) {
    shipForward.lerp(want, 1 - Math.exp(-dt * 1.4)).normalize();
    spaceUp.addScaledVector(shipForward, -spaceUp.dot(shipForward)).normalize();
}
// Where the course points: the chosen world of the system ahead once it can be
// seen, otherwise its star.
function courseAim() {
    if (pendingBody && ahead && ahead.star.id === course.id) {
        const p = ahead.positions.get(pendingBody.id);
        return ahead.starScene.clone().add(vec(...p)).sub(shipPosition).normalize();
    }
    return toScene(starPoint(course).map((v, i) => v - galactic[i])).normalize();
}
// The system around the nearest star, seen from deep space: its worlds as dots
// around the star from 0.4 ly, and the real worlds once they are close enough
// to draw (the departing system as you leave, the next one as you arrive).
let ahead = null,
    shownView = null,
    pendingBody = null; // world chosen in the system ahead; becomes the target on arrival
const aheadSystems = new Map();
function systemOfStar(star) {
    if (star.id === loadedId) return system;
    if (incoming?.star.id === star.id) return incoming.system;
    let s = aheadSystems.get(star.id);
    if (!s) {
        if (aheadSystems.size > 20) aheadSystems.clear();
        aheadSystems.set(star.id, (s = generateSystem(star.seed)));
    }
    return s;
}
function showSystemAhead(entry, offset, d) {
    const star = entry.star;
    if (d > 0.4) {
        if (shownView) shownView.visible = false;
        shownView = ahead = null;
        worldDots.hide();
        return;
    }
    const sys = systemOfStar(star),
        metresPerLy = edgeOf(star) / ARRIVE_LY,
        starScene = toScene(offset).multiplyScalar(metresPerLy),
        positions = systemPositions(sys, orbitClock());
    ahead = { star, system: sys, starScene, positions, real: false };
    const view = star.id === loadedId ? systemView : incoming?.ready && incoming.star.id === star.id ? incoming.view : null;
    if (shownView && shownView !== view) shownView.visible = false;
    shownView = null;
    if (view) {
        // The real worlds, as a miniature when far off (see systemView.place).
        const reach = starScene.length(),
            scale = Math.min(1, 45000 / reach);
        view.visible = true;
        view.place(positions, starScene.clone().negate(), scale);
        view.update(camera.position, streamer);
        shownView = view;
        ahead.real = true;
        ahead.scale = scale;
        nearStar.hide();
    }
    // Dots mark worlds still too small to see (under ~2 pixels across), so the
    // system is visible from afar; each dot gives way to its world as it grows.
    const pixels = innerHeight / 2 / Math.tan((camera.fov * Math.PI) / 360);
    worldDots.show(
        camera,
        sys.bodies
            .map((b) => ({ b, at: starScene.clone().add(vec(...positions.get(b.id))) }))
            .filter((e) => !view || (e.b.radius / e.at.length()) * pixels < 2)
            .map((e) => ({ dir: e.at.normalize(), color: e.b.palette[2] })),
    );
}
function updateDeep(dt) {
    const steer = steering();
    // Between stars there is nothing to slide past, so A/D turn here.
    strafeSpeed = 0;
    const yaw = clamp((keys.has("KeyA") ? 1 : 0) - (keys.has("KeyD") ? 1 : 0) + arrowTurn(), -1, 1);
    const m = takeMouseSteer(dt);
    shipForward.applyAxisAngle(spaceUp, yaw * dt * 0.85 + m.yaw);
    const right = shipForward.clone().cross(spaceUp).normalize();
    const pitch = (keys.has("ArrowUp") ? 1 : 0) - (keys.has("ArrowDown") ? 1 : 0);
    shipForward.applyAxisAngle(right, pitch * dt * 0.7 + m.pitch).normalize();
    spaceUp.applyAxisAngle(right, pitch * dt * 0.7 + m.pitch).normalize();
    bankAngle = damp(bankAngle, clamp(yaw * 0.25 + m.rate * 0.12, -0.45, 0.45), 4, dt);
    // With a course set, the ship holds its heading toward it whenever you are
    // not steering; steering takes over until you let go.
    let want = null;
    if (course && !steer) {
        want = courseAim();
        turnToward(want, dt);
    }
    const manualThrottle = keys.has("KeyW") || keys.has("KeyS") || keys.has("KeyX");
    if (autopilot && want && !manualThrottle) throttle = damp(throttle, shipForward.dot(want) > 0.97 ? 1 : 0.15, 1.5, dt);
    else if (keys.has("KeyX")) throttle = damp(throttle, 0, 4, dt);
    else throttle = clamp(throttle + ((keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0)) * dt * 0.45, 0, 1);
    const boost = keys.has("ShiftLeft") || keys.has("ShiftRight");
    const nearest = sky.stars[0];
    const d = nearest ? nearest.distance : 1;
    const lyPerSecond = (throttle * Math.max(d, 0.0008)) / (boost ? DRIVE_TIME / 2.5 : DRIVE_TIME);
    const step = toGalaxy(shipForward);
    for (let i = 0; i < 3; i++) galactic[i] += step[i] * lyPerSecond * dt;
    speed = 120 + throttle * 600; // for engine glow
    verticalSpeed = 0;
    sky.update(galactic, camera);
    orientSpace(dt);
    streaks.update(camera, shipForward, throttle * (boost ? 1 : 0.7), dt);
    if (!nearest) return;
    // Light comes from the nearest star.
    const toStar = toScene(starPoint(nearest.star).map((v, i) => v - galactic[i])).normalize();
    sun.position.copy(toStar).multiplyScalar(1000);
    sun.color.set(nearest.physics.color).lerp(new THREE.Color(0xffffff), 0.45);
    sun.intensity = 3.1 * clamp(0.25 + 0.75 * (ARRIVE_LY * 30) / Math.max(d, ARRIVE_LY), 0.25, 1);
    // The star ahead grows into a sphere as you close in.
    const offset = starPoint(nearest.star).map((v, i) => v - galactic[i]);
    if (d < 0.3)
        nearStar.show(camera, offset, edgeOf(nearest.star) / ARRIVE_LY, starGameRadius(nearest.physics), nearest.physics.color);
    else nearStar.hide();
    showSystemAhead(nearest, offset, d);
    // Build the system ahead before you get there.
    if (d < PREPARE_LY && nearest.star.id !== loadedId && incoming?.star.id !== nearest.star.id)
        startIncoming(nearest.star);
    if (d < ARRIVE_LY) {
        // Enter when this star is your course, when you have no course, or when
        // you steer into it yourself. Otherwise the drive skims past its edge.
        const entering = shipForward.dot(toStar) > 0.2 && (!course || course.id === nearest.star.id || steer);
        const ready = nearest.star.id === loadedId || (incoming?.ready && incoming.star.id === nearest.star.id);
        if (entering && ready) return arriveInSystem(nearest.star, offset);
        const back = offset.map((v) => -v / d);
        galactic = starPoint(nearest.star).map((v, i) => v + back[i] * ARRIVE_LY);
        if (entering) {
            throttle = Math.min(throttle, 0.2);
            if (toastTime <= 0) toast(`Charting the ${starName(nearest.star)} system…`, 1.5);
        }
    }
}
// offset: star minus ship (ly). Enters the star's system at its edge, on the
// side you came from, still heading the way you were flying.
function arriveInSystem(star, offset) {
    const fresh = star.id !== loadedId;
    if (fresh) {
        systemView.dispose();
        systemView = incoming.view;
        system = incoming.system;
        incoming = null;
        currentStar = star;
        loadedId = star.id;
        offChart = false;
        edge = systemEdge(system);
        galaxyState.current = star.id;
        galaxyState.visited.add(star.id);
        saveGalaxyState(galaxyState);
        try {
            history.replaceState(null, "", `?star=${star.id}`);
        } catch {}
        clearSites();
        starMap.setHere(star, system);
        loadSurvey(null);
        if (course?.id === star.id) course = null;
    }
    nearStar.hide();
    streaks.hide();
    worldDots.hide();
    if (shownView && shownView !== incoming?.view) shownView.visible = false;
    shownView = ahead = null;
    autopilot = false;
    positions = systemPositions(system, orbitClock());
    const d = Math.hypot(...offset);
    const entry = toScene(offset.map((v) => -v / d)).multiplyScalar(edge * 0.97);
    // Coordinates are kept relative to the nearest solid world.
    if (fresh || !site) {
        activeBody = system.bodies
            .filter((b) => !b.giant)
            .sort((a, b) => positionOf(a).distanceTo(entry) - positionOf(b).distanceTo(entry))[0];
        RADIUS = activeBody.radius;
        signalNormal = vec(...terrainFor(activeBody).site);
        landingNormal = vec(...terrainFor(activeBody).landing);
        discovered = records.has(activeBody.id);
    }
    worldOrigin = positionOf(activeBody);
    shipPosition.copy(entry).sub(worldOrigin);
    camera.position.add(shipPosition);
    mode = "space";
    speed = 150;
    systemView.visible = true;
    if (site) site.group.visible = true;
    sun.intensity = 3.1;
    sun.color.set(system.star.color).lerp(new THREE.Color(0xffffff), 0.45);
    positionSystem();
    sky.update(starPoint(star), camera, star.id);
    selectedBody = null;
    target = null;
    if (pendingBody && system.bodies.some((b) => b.id === pendingBody.id)) {
        // The world you picked on the way in: aim for it.
        selectedBody = target = system.bodies.find((b) => b.id === pendingBody.id);
    }
    pendingBody = null;
    refreshWorldLabels();
    toast(
        fresh
            ? `Entering the ${system.name} system: ${system.bodies.length} worlds around a ${system.star.physics.spectralClass} star. Press M to choose one.`
            : `Back in the ${system.name} system.`,
        6,
    );
}
// What the HUD shows in deep space.
function deepInfo() {
    if (mode !== "deep") {
        if (!course || target) return null;
        const d = Math.hypot(...starPoint(course).map((v, i) => v - viewer()[i]));
        return { name: starName(course), isCourse: true, autopilot, distance: d, point: towardStar(course).multiplyScalar(5000).add(camera.position) };
    }
    const nearest = sky.stars[0];
    const aimed = course || nearest?.star;
    if (!aimed) return null;
    const offset = starPoint(aimed).map((v, i) => v - galactic[i]);
    const d = Math.hypot(...offset);
    const nd = nearest ? nearest.distance : 1;
    return {
        name: pendingBody && course ? `${pendingBody.name} · ${starName(course)}` : starName(aimed),
        isCourse: !!course,
        autopilot,
        distance: d,
        nearestName: nearest ? starName(nearest.star) : "",
        nearestDistance: nd,
        // Multiples of light speed.
        lightSpeeds: ((throttle * Math.max(nd, 0.0008)) / DRIVE_TIME) * 31557600,
        point: (course ? courseAim() : toScene(offset).normalize()).multiplyScalar(5000).add(camera.position),
    };
}
// After a jump: in open space a little way from a world, on its sunlit side,
// facing it. Fly in to reach its orbit.
function arriveNear(body) {
    mode = "space";
    const sunward = positionOf(body).negate().normalize();
    const side = sunward.clone().cross(Y).normalize();
    const dir = sunward.multiplyScalar(0.8).addScaledVector(side, 0.45).addScaledVector(Y, 0.3).normalize();
    shipPosition.copy(dir).multiplyScalar(body.radius * 3 + 1100);
    shipForward = shipPosition.clone().negate().normalize();
    spaceUp.copy(Y).addScaledVector(shipForward, -Y.dot(shipForward)).normalize();
    speed = verticalSpeed = 0;
    selectedBody = target = body;
    camera.position.copy(shipPosition).addScaledVector(shipForward, -30).addScaledVector(spaceUp, 12);
    camera.up.copy(spaceUp);
    camera.lookAt(shipPosition.clone().addScaledVector(shipForward, 32));
    orientSpace(1);
}
// Giants are visited from space: hold position facing the planet.
// The ship then moves with the giant along its orbit until you fly off, and turns
// to face it smoothly (it used to snap round, then drift away as the giant moved on).
let holding = null; // { body, last: global position of the body } while holding above a giant
function arriveAtGiant(body) {
    mode = "space";
    speed = 0;
    verticalSpeed = 0;
    selectedBody = target = body; // the nose turns to it gradually (updateSpace)
    holding = { body, last: positionOf(body) };
    keys.clear();
    visited.add(body.id);
    const worldNote = record(worldEntry(system, body));
    saveSurvey();
    const moons = system.bodies.filter((b) => b.parent === body.id);
    toast(
        `Holding above ${body.name}. No surface to land on${moons.length ? `: chart a course to ${moons.map((m) => m.name).join(" or ")}` : ""}.${worldNote}`,
        6,
    );
}
$("cancelTransit").onclick = cancelCruise;
$("seedForm").onsubmit = (e) => {
    e.preventDefault();
    const value = $("seedInput").value;
    if (!/^\d+$/.test(value) || Number(value) > 4294967295) return;
    location.search = `?seed=${value}`;
};
$("randomSystem").onclick = () => {
    const value = crypto.getRandomValues(new Uint32Array(1))[0];
    location.search = `?seed=${value}`;
};
function openMap() {
    if ($("help").open || $("discovery").open) return;
    keys.clear();
    starMap.open("system");
}
$("mapBtn").onclick = openMap;

function updateFlight(dt) {
    orbitEntry = Math.max(0, orbitEntry - dt / 3);
    const up = shipPosition.clone().normalize();
    if (autoApproach) {
        const angle = up.angleTo(landingNormal),
            currentRadius = shipPosition.length();
        const nextUp = up.clone();
        const turnStep = Math.min(angle, dt * Math.min(0.14, angle * 0.75));
        if (angle > 0.001) {
            const axis = up.clone().cross(landingNormal).normalize();
            nextUp.applyAxisAngle(axis, turnStep);
            shipForward = tangent(landingNormal.clone().sub(up), nextUp);
        }
        const targetRadius = surfaceRadius(nextUp) + (angle > 0.16 ? 65 : 14);
        const targetVertical = clamp(
            (targetRadius - currentRadius) * 0.8,
            -18,
            18,
        );
        verticalSpeed = damp(verticalSpeed, targetVertical, 2.2, dt);
        const radius = currentRadius + verticalSpeed * dt;
        shipPosition.copy(nextUp.multiplyScalar(radius));
        speed = angle > 0.001 ? (turnStep / dt) * radius : 0;
        flightPitch = damp(flightPitch, 0, 3, dt);
        bankAngle = damp(bankAngle, 0, 3, dt);
        if (angle < 0.012 && altitude() < 18) {
            autoApproach = false;
            speed = 0;
            toast("Approach complete. Press L to land.");
        }
    } else {
        strafeSpeed = 0;
        const turn = clamp((keys.has("KeyA") ? 1 : 0) - (keys.has("KeyD") ? 1 : 0) + arrowTurn(), -1, 1);
        turnVelocity = damp(turnVelocity, turn * 1.0, 4, dt);
        const m = takeMouseSteer(dt);
        shipForward.applyAxisAngle(up, turnVelocity * dt + m.yaw);
        bankAngle = damp(bankAngle, clamp(turnVelocity * 0.3 + m.rate * 0.15, -0.5, 0.5), 4, dt);
        const pitchInput =
            (keys.has("ArrowUp") ? 1 : 0) - (keys.has("ArrowDown") ? 1 : 0);
        // The mouse sets a nose angle that holds while you steer and eases back
        // to level once you leave it alone; the arrow keys pitch while held.
        aimPitch = clamp(aimPitch + m.pitch * 1.5, -0.65, 0.65);
        if (pitchInput) aimPitch = 0;
        else if (performance.now() - lastMouseSteer > 1500) aimPitch = damp(aimPitch, 0, 0.5, dt);
        flightPitch = damp(flightPitch, pitchInput ? pitchInput * 0.65 : aimPitch, 2.4 * (1 - 0.8 * smoothstep(orbitEntry)), dt);
        const boost = keys.has("ShiftLeft") || keys.has("ShiftRight");
        const braking = keys.has("KeyX");
        let targetSpeed =
            ((keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0)) *
            (boost ? 100 : 40);
        if (braking) targetSpeed = 0;
        speed = damp(speed, targetSpeed, braking ? 5 : 1.7, dt);
        const lift = (keys.has("KeyR") ? 1 : 0) - (keys.has("KeyF") ? 1 : 0);
        const desiredVertical = braking
            ? 0
            : verticalTarget(lift, flightPitch, speed, boost, altitude());
        verticalSpeed = damp(
            verticalSpeed,
            desiredVertical,
            braking ? 5 : lift ? 2.2 : 3.2,
            dt,
        );
        const radius = shipPosition.length() + verticalSpeed * dt;
        const n = shipPosition
            .clone()
            .addScaledVector(shipForward, speed * Math.cos(flightPitch) * dt)
            .normalize();
        const floor = surfaceRadius(n) + 3.2;
        const boundedRadius = Math.max(radius, floor);
        if (boundedRadius !== radius) verticalSpeed = 0;
        shipPosition.copy(n.multiplyScalar(boundedRadius));
    }
    orientShip(dt);
    const global = shipPosition.clone().add(worldOrigin);
    const neighbor = system.bodies
        .filter((body) => body.id !== activeBody.id && !body.giant)
        .map((body) => ({
            body,
            clearance: global.distanceTo(positionOf(body)) - body.radius,
        }))
        // Switch only when clearly closer to the other world, and not straight after a
        // switch: near a moon and its planet the two were otherwise swapped back and forth.
        .filter((item) => item.clearance < 240 && item.clearance < altitude() * 0.6 && animationTime - lastSwitch > 2)
        .sort((a, b) => a.clearance - b.clearance)[0];
    if (neighbor) {
        switchWorld(neighbor.body, global);
        return;
    }
    if (altitude() > 600) {
        mode = "space";
        shipForward = shipForward
            .clone()
            .multiplyScalar(Math.cos(flightPitch))
            .addScaledVector(up, Math.sin(flightPitch))
            .normalize();
        spaceUp.copy(up);
        autoApproach = false;
        // Breaking orbit: the climb carries on for a moment and the camera eases
        // back so you see the world fall away below.
        exitClimb = clamp(verticalSpeed, 45, 140);
        exitGlide = 1;
        reveal = 1;
        toast(`Leaving ${activeBody.name}'s orbit. Fly freely, or press M to chart a course.`);
    }
}
function updateManeuver(dt) {
    maneuver.time += dt;
    const t = clamp(maneuver.time / maneuver.duration, 0, 1);
    const before = shipPosition.clone();
    bankAngle = damp(bankAngle, 0, 5, dt);
    flightPitch = damp(flightPitch, 0, 5, dt);
    speed = damp(speed, 0, 5, dt);
    if (mode === "landing") {
        const ease = smootherstep(t);
        shipPosition
            .copy(maneuver.normal)
            .multiplyScalar(
                surfaceRadius(maneuver.normal) +
                    1.7 +
                    maneuver.height * (1 - ease),
            );
        verticalSpeed =
            shipPosition.clone().sub(before).dot(maneuver.normal) / dt;
        if (t >= 1) {
            mode = "landed";
            verticalSpeed = 0;
            speed = 0;
            maneuver = null;
            toast(afloat ? "Splashdown. The Petrel rides the swell. Take off and land on shore to go on foot." : "Touchdown. Engines idle. Press E to leave Kestrel.");
        }
    } else {
        // Charge, lift vertically, then gently hand control back above the terrain.
        const liftT = clamp((t - 0.16) / 0.84, 0, 1);
        const height = 22 * smootherstep(liftT);
        shipPosition
            .copy(maneuver.normal)
            .multiplyScalar(surfaceRadius(maneuver.normal) + 1.7 + height);
        verticalSpeed =
            shipPosition.clone().sub(before).dot(maneuver.normal) / dt;
        if (t >= 1) {
            mode = "flight";
            verticalSpeed = 0;
            speed = 0;
            maneuver = null;
            if (stage === 2) {
                completed = true;
                setStage(3);
                toast("Signal recorded. Press M to choose your next world.");
            } else toast("Clear of the surface. You have control.");
        }
    }
    orientShip(dt);
}

// The ship's velocity relative to the world it is near (for the camera and the
// dust rushing past), measured from how far it actually moved.
function updateFlow(dt) {
    const flying = started && mode !== "deep" && mode !== "walk" && mode !== "landed";
    if (!flying || lastBodyId !== activeBody.id || !lastLocal) {
        if (!flying) flowVel.set(0, 0, 0);
        lastLocal = flying ? shipPosition.clone() : null;
        lastBodyId = activeBody.id;
        spaceDust.hide();
        return;
    }
    // Under your own control, the ship's own motion (worlds drift along their
    // orbits, which shouldn't read as speed); on autopilot, how far it moved.
    let v;
    if (mode === "space") {
        const right = shipForward.clone().cross(spaceUp).normalize();
        v = shipForward.clone().multiplyScalar(speed).addScaledVector(spaceUp, verticalSpeed).addScaledVector(right, strafeSpeed);
    } else if (mode === "flight")
        v = shipForward.clone().multiplyScalar(speed * Math.cos(flightPitch)).addScaledVector(shipPosition.clone().normalize(), verticalSpeed);
    else v = shipPosition.clone().sub(lastLocal).divideScalar(Math.max(dt, 1e-3));
    lastLocal.copy(shipPosition);
    if (v.length() < 30000) flowVel.lerp(v, 1 - Math.exp(-dt * 8));
    const s = flowVel.length();
    const power = clamp((s - 30) / 1000, 0, 1);
    if (power > 0.02)
        spaceDust.update(camera, flowVel.clone().normalize(), power, dt, {
            speed: s,
            len: clamp(s * 0.022, 0.8, 18),
            opacity: (0.03 + 0.11 * power) * (0.45 + 0.55 * smoothstep(spaceBlend)),
        });
    else spaceDust.hide();
}
// Shows the surface of the nearest other world once you are within a few km of it
// (see approachSite), and keeps it where that world is.
function updateApproachSite() {
    let best = null,
        clearance = Infinity;
    if (started && (mode === "space" || mode === "flight" || mode === "transit")) {
        const cam = camera.position.clone().add(worldOrigin);
        for (const b of system.bodies) {
            if (b === activeBody || b.giant) continue;
            const c = cam.distanceTo(positionOf(b)) - b.radius;
            if (c < clearance) {
                clearance = c;
                best = b;
            }
        }
    }
    const want = best && clearance < (best === approachBody ? 7000 : 6000) ? best : null;
    if (want !== approachBody) {
        if (approachSite && approachSite !== site) scene.remove(approachSite.group);
        approachBody = want;
        approachSite = want ? siteFor(want) : null;
        if (approachSite) {
            approachSite.halo.farFrom.value = want.radius + 3500;
            approachSite.halo.farTo.value = want.radius + 5800;
            approachSite.group.visible = true;
            scene.add(approachSite.group);
        }
    }
    if (approachSite) approachSite.group.position.copy(positionOf(approachBody)).sub(worldOrigin);
}
function updateWalk(dt) {
    const turn =
        (keys.has("ArrowLeft") ? 1 : 0) - (keys.has("ArrowRight") ? 1 : 0);
    playerForward.applyAxisAngle(playerNormal, turn * dt * 1.6);
    lookPitch = clamp(
        lookPitch +
            ((keys.has("ArrowUp") ? 1 : 0) - (keys.has("ArrowDown") ? 1 : 0)) *
                dt,
        -1.15,
        1.1,
    );
    const right = playerForward.clone().cross(playerNormal).normalize();
    const direction = playerForward
        .clone()
        .multiplyScalar((keys.has("KeyW") ? 1 : 0) - (keys.has("KeyS") ? 1 : 0))
        .addScaledVector(
            right,
            (keys.has("KeyD") ? 1 : 0) - (keys.has("KeyA") ? 1 : 0),
        );
    const moving = direction.lengthSq() > 0.01;
        const walkingSpeed =
        keys.has("ShiftLeft") || keys.has("ShiftRight") ? 8 : 4.5;
    // Jumping: gravity follows the world's surface gravity, so moons give floaty leaps.
    const gravity = 9.8 * Math.max(0.15, activeBody.physics?.gravity ?? 1);
    if (keys.has("Space") && jumpHeight <= 0) jumpVelocity = 4.4;
    if (jumpHeight > 0 || jumpVelocity > 0) {
        jumpHeight += jumpVelocity * dt;
        jumpVelocity -= gravity * dt;
        if (jumpHeight <= 0) {
            jumpHeight = 0;
            jumpVelocity = 0;
        }
    }
    if (moving) {
        direction.normalize();
        // Steep uphill slows you down (to a third on the steepest ground); downhill doesn't.
        const step = walkingSpeed * dt;
        const ahead = surfacePoint(playerNormal).addScaledVector(direction, Math.max(step, 0.3)).normalize();
        const rise = (surfaceRadius(ahead) - surfaceRadius(playerNormal)) / Math.max(step, 0.3);
        const uphill = clamp(1 - Math.max(0, rise - 0.35) * 0.9, 0.33, 1);
        const next = resolveCollisions(
            surfacePoint(playerNormal)
                .addScaledVector(direction, step * uphill)
                .normalize(),
        );
        const wet = terrainFor(activeBody).isLiquid(next);
        if (wet && toastTime <= 0)
            toast(
                terrainFor(activeBody).liquid === "lava"
                    ? "Lava ahead. Too hot to go further."
                    : "The water is too deep to go further.",
            );
        if (!wet) playerNormal.copy(next);
    }
    playerForward = tangent(playerForward, playerNormal);
            bob += moving && jumpHeight <= 0 ? dt * walkingSpeed * 1.8 : 0;
    speed = moving ? walkingSpeed : 0;
    updateScan(dt);
}
let jumpHeight = 0,
    jumpVelocity = 0,
    eyeRadius = null; // smoothed eye distance from the world's centre while walking
// Ground radius averaged over a stride-sized footprint around a point (centre and four
// points 0.45 m away), so walking follows the lie of the land rather than every pebble.
function footHeight(n) {
    const a = tangent(Math.abs(n.y) < 0.9 ? Y.clone() : vec(1, 0, 0), n), b = n.clone().cross(a), e = 0.45 / RADIUS;
    let sum = surfaceRadius(n) * 2;
    for (const [da, db] of [[1, 0], [-1, 0], [0, 1], [0, -1]])
        sum += surfaceRadius(n.clone().addScaledVector(a, da * e).addScaledVector(b, db * e).normalize());
    return sum / 6;
}
const PLAYER_RADIUS = 0.35;
// Slide around obstacles: push the next step out of anything taller than your feet.
function resolveCollisions(next) {
    const p = next.clone().multiplyScalar(surfaceRadius(next));
    const list = site.nearbyObstacles(p);
    list.push({ p: shipPosition.clone(), r: 3.2, h: 4 }); // the parked ship
    for (let pass = 0; pass < 2; pass++) {
        const up = p.clone().normalize();
        for (const o of list) {
            if (jumpHeight > o.h) continue; // high enough to clear it
            const d = p.clone().sub(o.p);
            d.addScaledVector(up, -d.dot(up));
            const min = o.r + PLAYER_RADIUS,
                len = d.length();
            if (len < min && len > 1e-6) p.addScaledVector(d, (min - len) / len);
        }
    }
    return p.normalize();
}
// --- Scanning ----------------------------------------------------------------
// On foot, the recordable thing nearest the crosshair within reach gets a prompt
// (scanning.js, scan-ui.js). Hold E, or the Scan button, until the ring fills to scan
// something new; press E on something already recorded to see its card again.
const scanUI = createScanUI({ touch: coarsePointer });
const SCAN_TIME = 1.3, // seconds of holding
    RECORD_TIME = 1.6; // a sky event
const holdTime = (t) => (t.kind === "core" ? 2 : t.kind === "behaviour" ? observeTime(codex.unlocked) : t.kind === "phenomenon" ? RECORD_TIME : SCAN_TIME);
let zoom = 0; // field glasses, 0..1 (eases in and out)
const glassesView = $("glasses");
let scanTarget = null, // { kind, id, ref, point, reach, known }
    scanProgress = 0, // 0..1 while holding
    scanSearch = 0,
    scanNeedsRelease = false, // after a scan, let go before the next one starts
    touchScanHeld = false;
const scanHeld = () => keys.has("KeyE") || touchScanHeld;
$("actionBtn").addEventListener("pointerdown", () => {
    if (mode === "walk" && scanTarget && !scanTarget.known) touchScanHeld = true;
});
for (const ev of ["pointerup", "pointercancel", "pointerleave"]) $("actionBtn").addEventListener(ev, () => (touchScanHeld = false));
// Behaviours and sky events live only in the codex: ask it.
const inCodex = (kind) => ({ includes: (id) => codex.has({ kind, seed: String(system.seed), bodyId: activeBody.id, id }) });
const scannedHere = () => ({
    fauna: (bestiary[activeBody.id] ||= []),
    flora: (catalogue[activeBody.id] ||= []),
    formation: (strata[activeBody.id] ||= []),
    behaviour: inCodex("behaviour"),
    phenomenon: inCodex("phenomenon"),
    core: inCodex("core"),
});
// Behaviours already recorded for a species on this world.
const seenOf = (sp) => behavioursOf(sp).filter((b) => codex.has(behaviourEntry(system, activeBody, sp, b)));
function updateScan(dt) {
    const held = scanHeld();
    if (!held) scanNeedsRelease = false;
    const scanning = held && !scanNeedsRelease && scanTarget && !scanTarget.known;
    if (scanTarget) scanTarget.point = followTarget(site, scanTarget);
    if ((scanSearch += dt) >= 0.1) {
        scanSearch = 0;
        const holding = !!scanning && scanProgress > 0;
        const next = scanTarget?.kind === "phenomenon" && holding
            ? skyTarget(true)
            : findScanTarget({
                site,
                here: surfacePoint(playerNormal),
                eye: camera.position,
                forward: camera.getWorldDirection(vec()),
                // Field glasses: zoomed in, you can scan from farther and the aim narrows with the view.
                reachScale: 1 + (ZOOM_REACH - 1) * smoothstep(zoom),
                aimScale: camera.fov / 70,
                cores: codex.unlocked.has("deepCoreSampler"),
                known: scannedHere(),
                keep: scanTarget,
                holding,
            }) || skyTarget(false);
        if (scanProgress > 0 && (!next || next.kind !== scanTarget?.kind || next.id !== scanTarget?.id)) scanProgress = 0;
        scanTarget = next;
    }
    if (scanning && scanTarget && !scanTarget.known) {
        scanProgress += dt / holdTime(scanTarget);
        if (scanProgress >= 1) completeScan();
    } else scanProgress = Math.max(0, scanProgress - dt * 2.5);
}
function completeScan() {
    const t = scanTarget, list = scannedHere()[t.kind];
    scanProgress = 0;
    scanNeedsRelease = true;
    t.known = true;
    if (t.kind === "core") t.sample = coreSample(activeBody, t.ref);
    if (t.kind === "behaviour" || t.kind === "phenomenon" || t.kind === "core") {
        const entry = t.kind === "core" ? coreEntry(system, activeBody, t.ref, t.sample) : t.kind === "behaviour" ? behaviourEntry(system, activeBody, t.ref, t.behaviour) : phenomenonEntry(system, activeBody, t.id, { total: t.ref.total });
        if (codex.has(entry)) return;
        scanUI.flash();
        showScanCard(t, recordInfo(entry));
        return;
    }
    if (list.includes(t.id)) return;
    list.push(t.id);
    saveSurvey();
    scanUI.flash();
    const entry = t.kind === "fauna" ? faunaEntry(system, activeBody, t.ref) : t.kind === "flora" ? floraEntry(system, activeBody, t.ref) : formationEntry(system, activeBody, t.ref);
    showScanCard(t, recordInfo(entry));
}
// info: what recording it moved forward (recordInfo), or null to show a recorded thing again.
function showScanCard(t, info) {
    const where = `${wordFor(t).toUpperCase()} · ${activeBody.name.toUpperCase()}`;
    scanUI.card({
        ...cardFor(t, site, activeBody, t.kind === "fauna" || t.kind === "behaviour" ? seenOf(t.ref) : []),
        eyebrow: info ? `NEW ${where}` : `RECORDED ${where}`,
        footer: !info
            ? null
            : info.ready
              ? { text: `Upgrade ready: ${info.ready.name}. Press U to install it.`, ready: true }
              : info.moved
                ? { text: `Counts toward ${info.moved.name}: ${info.progressText}` }
                : { text: "Recorded in your codex." },
    });
}
// The prompt at the crosshair, every frame.
function drawScanMarker() {
    if (mode !== "walk" || !scanTarget || modalOpen()) return scanUI.prompt(null);
    scanUI.prompt({ title: titleFor(scanTarget), known: scanTarget.known, verb: verbFor(scanTarget) }, scanProgress);
}
function updateCamera(dt) {
    if (mode === "walk") {
        // The eye glides over the ground: it follows the average height under your
        // feet (not the exact point), easing up and down, so small bumps and sharp
        // rocky crests don't jolt the view. It never sinks far below standing height.
        const ground = footHeight(playerNormal);
        const want = ground + 1.75;
        if (eyeRadius === null || Math.abs(eyeRadius - want) > 4) eyeRadius = want;
        eyeRadius = damp(eyeRadius, want, want > eyeRadius ? 9 : 6, dt);
        eyeRadius = Math.max(eyeRadius, surfaceRadius(playerNormal) + 1.35);
        const eye = playerNormal.clone().multiplyScalar(eyeRadius + jumpHeight + Math.sin(bob) * 0.025);
        camera.position.copy(eye);
        camera.up.copy(playerNormal);
        const look = playerForward
            .clone()
            .multiplyScalar(Math.cos(lookPitch))
            .addScaledVector(playerNormal, Math.sin(lookPitch));
        camera.lookAt(eye.clone().add(look));
        // Field glasses: hold Z (or the touch button) to zoom in.
        const zooming = hasFieldGlasses(codex.unlocked) && keys.has("KeyZ") && !modalOpen();
        zoom = damp(zoom, zooming ? 1 : 0, 7, dt);
        if (zoom < 0.002) zoom = 0;
        camera.fov = 70 - 56 * smoothstep(zoom);
        glassesView.style.opacity = zoom.toFixed(3);
    } else {
        if (zoom) glassesView.style.opacity = zoom = 0;
                // The camera drifts back behind the ship once you stop looking around.
        // While the mouse steers, only looking around (Q) moves the camera off the ship.
        const holdView = mouseSteers()
            ? performance.now() - lastFreeLook < 1200
            : keys.has("KeyQ") || input.lookingAround(2500);
        if (!holdView) {
            orbitYaw = THREE.MathUtils.damp(orbitYaw, 0, 2, dt);
            orbitPitch = THREE.MathUtils.damp(orbitPitch, 0.18, 2, dt);
        }
        const inSpace = mode === "space" || mode === "transit" || mode === "deep";
        // Entering or leaving orbit, the camera eases between its low flying view
        // and its space view over a couple of seconds instead of jumping.
        spaceBlend = damp(spaceBlend, inSpace ? 1 : 0, 1.3, dt);
        const sb = smoothstep(spaceBlend);
        reveal = Math.max(0, reveal - dt / 3.5);
        const pull = smoothstep(reveal) * Math.min(1, reveal * 4); // rises fast, fades slowly
        // How fast you are going, 0..1: wider view, camera dropping back, a faint shake.
        const boosting = keys.has("ShiftLeft") || keys.has("ShiftRight");
        const rush = mode === "deep"
            ? throttle * (boosting ? 1 : 0.8)
            : clamp(flowVel.length() / (110 + 1190 * sb), 0, 0.75);
        rushLevel = damp(rushLevel, rush, 2.5, dt);
        const radial = shipPosition.clone().normalize();
        const up = radial.clone().lerp(spaceUp, sb);
        if (up.lengthSq() < 1e-4) up.copy(inSpace ? spaceUp : radial);
        up.normalize();
        // Right after entering orbit the camera swings round to its new place
        // slowly; otherwise it follows the ship directly.
        const ease = smoothstep(orbitEntry);
        const backTarget = shipForward.clone().negate().applyAxisAngle(up, orbitYaw);
        if (!camBack || ease <= 0 || mode === "walk") {
            camBack = backTarget.clone();
            camAhead = shipForward.clone();
        } else {
            const f = 1 - Math.exp(-dt * (0.9 + 6 * (1 - ease)));
            camBack.lerp(backTarget, f).normalize();
            camAhead.lerp(shipForward, f).normalize();
        }
        const back = camBack;
        const framing = Math.max(1, 0.65 / camera.aspect);
        const distance = 26 * (1 + 0.28 * rushLevel + 0.9 * pull);
        const desired = shipPosition
            .clone()
            .addScaledVector(back, distance * framing * Math.cos(orbitPitch))
            .addScaledVector(up, (21 - 10 * sb + 14 * pull + 20 * Math.sin(orbitPitch)) * framing);
        const normal = desired.clone().normalize();
        const floor = surfaceRadius(normal) + 2;
        if (!inSpace && desired.length() < floor)
            desired.copy(normal.multiplyScalar(floor));
        // Carry the camera along with the ship, so at speed it stays close behind
        // (a little lag is left in, which reads as speed).
        if (mode !== "deep") camera.position.addScaledVector(flowVel, dt * 0.85);
        camera.position.lerp(desired, 1 - Math.exp(-dt * (4 - 2.6 * ease)));
        camera.up.lerp(up, 1 - Math.exp(-dt * (4 - 3.2 * ease))).normalize();
        const look = shipPosition
            .clone()
            // In space, look far ahead so what you fly toward sits mid-screen.
            .addScaledVector(camAhead, 12 + 20 * sb)
            // Near the ground the camera looks down a little; this fades out
            // while climbing, so leaving orbit doesn't jolt the view.
            .addScaledVector(up, -7 * (1 - smoothstep((altitude() - 120) / 480)) * (1 - sb) - 10 * pull);
        // A faint shake when really moving (more with boost).
        const shake = Math.max(0, rushLevel - 0.45) / 0.55;
        if (shake > 0) {
            const a = 0.35 * shake * shake * (boosting ? 1.4 : 1) * framing, t = animationTime;
            look.addScaledVector(up, a * (Math.sin(t * 31) + Math.sin(t * 17.3)) * 0.5);
            look.addScaledVector(back.clone().cross(up), a * (Math.sin(t * 27.1) + Math.sin(t * 13.7)) * 0.5);
        }
        camera.lookAt(look);
        camera.fov = THREE.MathUtils.damp(
            camera.fov,
            58 + 13 * rushLevel + (mode === "deep" ? 9 * rushLevel : 0) + 4 * pull,
            3,
            dt,
        );
    }
    camera.updateProjectionMatrix();
}

// --- Targets --------------------------------------------------------------
// Tap or click a world or star (or press Tab) to select it. Its name and
// distance show on the waypoint, and in space the ship keeps its nose on it
// whenever you are not steering. In deep space, stars and the worlds of the
// system ahead can be picked; picking one sets your course.
let target = null; // a world of this system
function targetCandidates() {
    const out = [];
    if (mode === "deep") {
        for (const e of sky.stars.slice(0, 400))
            out.push({ kind: "star", star: e.star, point: toScene(starPoint(e.star).map((v, i) => v - galactic[i])).normalize().multiplyScalar(5000).add(camera.position) });
        if (ahead)
            for (const b of ahead.system.bodies) {
                const p = ahead.starScene.clone().add(vec(...ahead.positions.get(b.id)));
                out.push({ kind: "body", body: b, star: ahead.star, point: p.normalize().multiplyScalar(5000).add(camera.position) });
            }
    } else {
        for (const b of system.bodies)
            if (b.id !== activeBody.id || mode === "space" || mode === "transit")
                out.push({ kind: "body", body: b, point: positionOf(b).sub(worldOrigin) });
        // Other stars, so you can find the way to another system.
        for (const e of sky.stars.slice(0, 300))
            if (e.star.id !== currentStar.id)
                out.push({ kind: "star", star: e.star, point: towardStar(e.star).multiplyScalar(5000).add(camera.position) });
    }
    return out;
}
function onScreen(point) {
    const v = point.clone().project(camera);
    const ahead = point.clone().sub(camera.position).dot(camera.getWorldDirection(vec())) > 0;
    return ahead && Math.abs(v.x) < 1.05 && Math.abs(v.y) < 1.05 ? [(v.x * 0.5 + 0.5) * innerWidth, (-v.y * 0.5 + 0.5) * innerHeight] : null;
}
function pickAt(x, y) {
    if (mode === "walk" || mode === "landing" || mode === "takeoff") return;
    let best = null,
        bestD = coarsePointer ? 60 : 40;
    for (const c of targetCandidates()) {
        const s = onScreen(c.point);
        if (!s) continue;
        // Worlds win over stars at the same spot.
        const d = Math.hypot(s[0] - x, s[1] - y) - (c.kind === "body" ? 10 : 0);
        if (d < bestD) {
            bestD = d;
            best = c;
        }
    }
    if (best) chooseTarget(best);
    else if ((mode === "space" || mode === "deep") && (target || course || selectedBody)) clearTarget();
}
let cycleIndex = -1;
function cycleTarget() {
    if (mode === "walk" || mode === "landing" || mode === "takeoff") return;
    // Nothing chosen yet: start with the nearest world, wherever it is.
    if (mode !== "deep" && !selectedBody && !course) {
        const nearest = targetCandidates()
            .filter((c) => c.kind === "body")
            .sort((a, b) => a.point.distanceTo(shipPosition) - a.body.radius - (b.point.distanceTo(shipPosition) - b.body.radius))[0];
        if (nearest) {
            cycleIndex = -1;
            return chooseTarget(nearest);
        }
    }
    // Only what is on screen: nearest worlds first, then the nearest stars.
    const reach = (c) =>
        c.kind === "star"
            ? 1e12 + Math.hypot(...starPoint(c.star).map((v, i) => v - viewer()[i]))
            : mode === "deep"
              ? 1e6 + ahead.starScene.clone().add(vec(...ahead.positions.get(c.body.id))).length()
              : c.point.distanceTo(shipPosition);
    const list = targetCandidates()
        .filter((c) => onScreen(c.point))
        .map((c) => ({ c, d: reach(c) }))
        .sort((a, b) => a.d - b.d)
        .slice(0, 12);
    if (!list.length) return void toast("Nothing in view to select. Turn toward a world or star.");
    cycleIndex = (cycleIndex + 1) % list.length;
    chooseTarget(list[cycleIndex].c);
}
const fmtDistance = (m) => (m >= 10000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`);
const fmtLightYears = (ly) => (ly < 0.05 ? `${Math.max(1, Math.round(ly * 63241))} AU` : `${ly.toFixed(2)} ly`);
function chooseTarget(c) {
    if (c.kind === "star") {
        course = c.star;
        target = pendingBody = selectedBody = null;
        const ly = Math.hypot(...starPoint(c.star).map((v, i) => v - viewer()[i]));
        toast(`Course: ${starName(c.star)}, ${fmtLightYears(ly)}. The ship points there when you are not steering; T for autopilot, C to clear.`, 5);
    } else if (mode === "deep") {
        course = c.star;
        pendingBody = c.body;
        toast(`Course: ${c.body.name}, ${c.body.type.toLowerCase()} of ${starName(c.star)}. T for autopilot.`, 5);
    } else {
        selectedBody = target = c.body;
        const m = positionOf(c.body).sub(worldOrigin).distanceTo(shipPosition) - c.body.radius;
        toast(
            `Target: ${c.body.name}, ${c.body.type.toLowerCase()}, ${fmtDistance(m)}. ${mode === "space" ? "The ship keeps its nose on it when you are not steering. " : ""}T to cruise there.`,
            5,
        );
    }
    starMap.refresh();
}
// C, the Clear button, tapping empty space, or Clear course on the map.
function clearTarget() {
    if (!target && !course && !selectedBody) return;
    target = course = pendingBody = selectedBody = null;
    autopilot = false;
    starMap.refresh();
    toast("Target cleared. Free flight.");
}

// --- Skies ---------------------------------------------------------------
// Worlds with enough air have a sky. Its colour comes from the air (the biome's
// atmosphere tint) lit by the star: bright by day, warm at sunrise and sunset,
// dark at night. It fades to black as you climb out, stars fade in daylight,
// and haze softens distant land. Thin or no air keeps the black sky of space.
const SPACE = new THREE.Color("#07101d"),
    DUSK = new THREE.Color("#ff7a45");
const skyDay = new THREE.Color(),
    skyNow = new THREE.Color(),
    skyNight = new THREE.Color();
scene.fog = new THREE.FogExp2(SPACE.getHex(), 0);
function airOf(body) {
    // 0 below ~0.03 bar, about 0.6 at Earth's 1 bar, 1 for very thick air.
    const p = body.physics?.pressure ?? 0;
    return clamp((Math.log10(Math.max(p, 1e-4)) + 1.5) / 2.5, 0, 1);
}
function updateAtmosphere() {
    // The sky comes from the world nearest the camera, so a world's air fades in
    // as you descend toward it, not all at once when you reach its orbit.
    let body = activeBody,
        height = camera.position.length() - RADIUS,
        centre = vec(0, 0, 0);
    if (mode === "space" || mode === "transit") {
        const cam = camera.position.clone().add(worldOrigin);
        for (const b of system.bodies) {
            if (b === activeBody) continue;
            const at = positionOf(b), h = cam.distanceTo(at) - b.radius;
            if (h < height) {
                height = h;
                body = b;
                centre = at.sub(worldOrigin);
            }
        }
    }
    const air = airOf(body);
    let k = 0;
    if (air > 0 && mode !== "deep")
        k = air * (1 - smoothstep((height - 40) / (300 + 600 * air)));
    const up = camera.position.clone().sub(centre).normalize(),
        elevation = up.dot(sun.position.clone().normalize()); // the star's height in your sky
    const day = smoothstep((elevation + 0.1) / 0.35) * (1 - 0.9 * eclipseCover),
        dusk = clamp(1 - Math.abs(elevation - 0.03) / 0.22, 0, 1);
    // The air's own colour, slightly tinted by the star and brighter in thick air.
    skyDay.set(body.atmosphere).lerp(sun.color, 0.12).multiplyScalar(0.95 + 0.5 * air);
    skyNight.copy(skyDay).multiplyScalar(0.06);
    // Sunrise and sunset: a gentle warm shift, then dimming into night.
    skyNow.copy(skyDay).lerp(DUSK, dusk * 0.28);
    skyNow.lerp(skyNight, 1 - day);
    scene.background.copy(SPACE).lerp(skyNow, k);
    scene.fog.color.copy(scene.background);
    scene.fog.density = k * (0.00012 + 0.00045 * air);
    sky.setDaylight(k * day);
    nightNow = mode === "walk" ? 1 - day : 0;
}
// Night filter: on foot at night the suit's visor brightens the view (glowing species most of all).
let nightNow = 0,
    nightFilter = 0;
const nightTint = document.createElement("div");
nightTint.style.cssText = "position:fixed;inset:0;pointer-events:none;z-index:1;opacity:0;background:#5dff9a;mix-blend-mode:soft-light";
document.body.append(nightTint);
function updateNightFilter(dt) {
    const want = codex.unlocked.has("nightFilter") ? smoothstep((nightNow - 0.3) / 0.5) : 0;
    nightFilter = damp(nightFilter, want, 1.5, dt);
    if (nightFilter < 0.002) nightFilter = 0;
    if (mode !== "deep") hemi.intensity = 2.0 * (1 - 0.55 * eclipseCover) * (1 + 2.2 * nightFilter); // set (not scaled) every frame, so it never compounds
    renderer.toneMappingExposure = 1.15 * (1 + 0.6 * nightFilter);
    nightTint.style.opacity = (0.35 * nightFilter).toFixed(3);
}

// --- Sky events (phenomena.mjs, sky-events.js) ------------------------------------
// Eclipses, aurorae and meteor showers. On a world, a forecast for where you are is
// worked out every few seconds; the HUD tally shows what comes next, a toast says
// when one begins, and looking at it (the star, or up at the night sky) lets you
// record it with E. An eclipse dims the daylight, and a total one sends day animals
// to sleep and wakes the night ones.
const skyEvents = createSkyEvents(scene);
skyEvents.setWorld(activeBody);
let eclipseCover = 0,
    skyCast = [], // forecast: [{ type, name, start, end, total, by }] seen from here
    skyCastAt = -Infinity,
    skyCastBody = null,
    visibleSky = []; // what can be seen right now
const announcedSky = new Set();
const onWorld = () => ["walk", "landed", "flight", "landing", "takeoff"].includes(mode) && !activeBody.giant;
const skyRecorded = (type) => codex.has({ kind: "phenomenon", seed: String(system.seed), bodyId: activeBody.id, id: type });
function skyDescription(e) {
    const star = system.star.name, by = system.bodies.find((b) => b.id === e.by)?.name;
    const giant = system.bodies.find((b) => b.id === activeBody.parent && b.giant);
    if (e.type === "eclipse")
        return {
            description: `${by} slides across ${star}${e.total ? " and hides it completely: the day goes dark and the stars come out." : ", and the daylight dims."}`,
            facts: [["Caused by", by], ["Lasts", `About ${Math.max(1, Math.round((e.end - e.start) / 60))} min`], ["Seen", "By day, while the star is up"]],
        };
    if (e.type === "aurora")
        return {
            description: `Curtains of light ripple across the night sky where ${giant ? `particles caught in ${giant.name}'s magnetic field` : `particles from ${star}'s flares`} strike the upper air.`,
            facts: [["Caused by", giant ? `${giant.name}'s magnetic field` : `Flares from ${star}`], ["Seen", "At night, during a storm"]],
        };
    return {
        description: `Streaks of light cross the night sky as ${activeBody.name} passes through the dust trail of a comet.`,
        facts: [["Caused by", "Comet dust burning up in the air"], ["Seen", "At night, during a shower"]],
    };
}
// A sky event you are looking at (the star for an eclipse, the sky for the rest).
function skyTarget(holding) {
    if (mode !== "walk") return null;
    const fwd = camera.getWorldDirection(vec()), up = camera.position.clone().normalize();
    for (const e of visibleSky) {
        if (e.type === "eclipse") {
            const toStar = sun.position.clone().sub(camera.position).normalize();
            if (fwd.dot(toStar) < (holding ? 0.8 : 0.9)) continue;
        } else if (fwd.dot(up) < (holding ? 0.12 : 0.3)) continue;
        return {
            kind: "phenomenon", id: e.type, known: skyRecorded(e.type), reach: Infinity,
            point: camera.position.clone().addScaledVector(fwd, 400),
            ref: { name: e.name, type: e.type, total: !!e.total, ...skyDescription(e) },
        };
    }
    return null;
}
function updateSkyEvents(dt) {
    const here = onWorld();
    if (here && (orbitTime - skyCastAt > 8 || skyCastBody !== activeBody)) {
        if (skyCastBody !== activeBody) skyEvents.setWorld(activeBody);
        skyCastAt = orbitTime;
        skyCastBody = activeBody;
        const n = mode === "walk" ? playerNormal : shipPosition.clone().normalize();
        skyCast = forecast(system, activeBody, n.toArray(), orbitTime, 1800);
    }
    visibleSky = here ? skyCast.filter((e) => e.start <= orbitTime && orbitTime < e.end) : [];
    eclipseCover = here ? eclipseAt(system, activeBody, orbitTime).cover : 0;
    if (mode !== "deep") {
        sun.intensity = 3.1 * (1 - 0.92 * eclipseCover);
        hemi.intensity = 2.0 * (1 - 0.55 * eclipseCover);
    }
    for (const e of started ? visibleSky : []) {
        const key = `${system.seed}:${activeBody.id}:${e.type}:${Math.round(e.start / 30)}`;
        if (announcedSky.has(key)) continue;
        announcedSky.add(key);
        if (e.type === "eclipse" && skyRecorded("eclipse")) continue; // common on moons: only news the first time
        const look = skyRecorded(e.type) ? "" : mode !== "walk" ? " Step outside to record it." : e.type === "eclipse" ? " Look at the star and hold E to record it." : " Look up and hold E to record it.";
        const by = system.bodies.find((b) => b.id === e.by)?.name;
        toast(
            e.type === "eclipse" ? `${e.total ? "A total eclipse" : "An eclipse"} is beginning: ${by} is crossing ${system.star.name}.${look}`
                : e.type === "aurora" ? `An aurora is lighting up the night sky.${look}` : `A meteor shower has begun.${look}`,
            6,
        );
    }
    // Drawn only near the ground, and only as dark as the sky really is.
    const up = camera.position.clone().normalize(),
        dark = clamp(-up.dot(sun.position.clone().normalize()) / 0.12, 0, 1),
        low = here ? 1 - smoothstep((camera.position.length() - RADIUS - 150) / 400) : 0;
    const strength = (type) => {
        const e = visibleSky.find((x) => x.type === type);
        return e ? clamp(Math.min(orbitTime - e.start, e.end - orbitTime) / 25, 0, 1) * dark * low : 0;
    };
    skyEvents.update({ camera, up, aurora: strength("aurora"), meteors: strength("meteors"), dt, time: animationTime });
}
// The tally's last line: what the sky does next, seen from here.
function skyLine() {
    const ahead = skyCast.filter((e) => e.end > orbitTime);
    const e = ahead.find((x) => !skyRecorded(x.type)) || ahead[0];
    if (!e) return "";
    const mins = (e.start - orbitTime) / 60;
    const when = e.start <= orbitTime ? (skyRecorded(e.type) || mode !== "walk" ? "now" : e.type === "eclipse" ? "now · look at the star" : "now · look up")
        : mins < 1 ? "in under a minute" : `in ${Math.round(mins)} min`;
    return `<div class="tally-sky${skyRecorded(e.type) ? " done" : ""}"><span>${e.name}</span> ${when}</div>`;
}
// Behaviour logger (upgrade): say when an animal nearby is doing something new.
let alertTimer = 0,
    lastAlert = -Infinity;
function updateBehaviourAlerts(dt) {
    if (mode !== "walk" || !site?.fauna?.individualsOf || !behaviourAlerts(codex.unlocked) || (alertTimer += dt) < 1.5) return;
    alertTimer = 0;
    if (animationTime - lastAlert < 25) return;
    const here = surfacePoint(playerNormal);
    let best = null;
    for (const sp of site.fauna.species)
        for (const { creature, position } of site.fauna.individualsOf(sp)) {
            const b = behaviourNow(creature), d = position.distanceTo(here);
            if (!b || d > 90 || (best && d > best.d) || codex.has(behaviourEntry(system, activeBody, sp, b))) continue;
            best = { sp, b, d };
        }
    if (!best) return;
    lastAlert = animationTime;
    toast(`Behaviour logger: a ${best.sp.name} is ${BEHAVIOURS[best.b].verb} ${Math.round(best.d)} m away.`, 5);
}

// Heat glow at the screen edges when flying close to a star.
let heat = 0,
    shownHeat = 0;
const heatGlow = document.createElement("div");
heatGlow.style.cssText =
    "position:fixed;inset:0;pointer-events:none;z-index:1;opacity:0;background:radial-gradient(ellipse at center,rgba(255,170,90,0) 35%,rgba(255,120,40,.55) 80%,rgba(255,210,150,.85) 100%)";
document.body.append(heatGlow);
function updateHeat(dt) {
    if (mode !== "space") heat = 0;
    shownHeat = damp(shownHeat, heat, 4, dt);
    heatGlow.style.opacity = shownHeat < 0.01 ? "0" : shownHeat.toFixed(3);
}

// --- Danger without combat ---------------------------------------------------
// Some big hunters stalk you on foot. A lunge knocks you back and damages your suit;
// the suit recovers once you are left alone for a while. If it fails, the Kestrel's
// emergency recall brings you back beside the ship. On board you are always safe.
let suit = 1,
    sinceHit = 99,
    lastStalkToast = -Infinity;
const suitReadout = document.createElement("div");
suitReadout.style.cssText =
    "position:fixed;left:50%;top:84px;transform:translateX(-50%);z-index:3;pointer-events:none;font:600 10px 'DM Sans',sans-serif;letter-spacing:2px;color:#ffd0b0;text-shadow:0 1px 6px #000;display:none;text-align:center";
document.body.append(suitReadout);
const hitFlash = document.createElement("div");
hitFlash.style.cssText =
    "position:fixed;inset:0;pointer-events:none;z-index:1;opacity:0;transition:opacity .5s;background:radial-gradient(ellipse at center,rgba(255,40,30,0) 45%,rgba(255,40,30,.6) 100%)";
document.body.append(hitFlash);
function sufferAttacks() {
    for (const e of site.fauna.events) {
        if (e.type === "stalk" && mode === "walk" && animationTime - lastStalkToast > 20) {
            lastStalkToast = animationTime;
            toast(`A ${e.creature.sp.name} is stalking you. Keep moving, or get back aboard the Kestrel.`, 5);
        }
        if (e.type !== "attack" || mode !== "walk") continue;
        suit = Math.max(0, suit - e.damage * suitDamageScale(codex.unlocked));
        sinceHit = 0;
        hitFlash.style.transition = "none";
        hitFlash.style.opacity = "1";
        requestAnimationFrame(() => { hitFlash.style.transition = "opacity .9s"; hitFlash.style.opacity = "0"; });
        // Knocked back, away from the animal.
        const away = tangent(playerNormal.clone().sub(e.from), playerNormal);
        if (away.lengthSq() > 0.01) playerNormal.addScaledVector(away, 3.5 / RADIUS).normalize();
        jumpVelocity = Math.max(jumpVelocity, 2.4);
        if (jumpHeight <= 0) jumpHeight = 0.01;
        if (suit <= 0) {
            suit = 1;
            recallToShip();
            toast("Suit integrity failed. Emergency recall: you are back beside the Kestrel.", 6);
        } else toast(`Struck by a ${e.creature.sp.name}! Suit integrity ${Math.round(suit * 100)}%.`, 4);
    }
}
// Cold and heat on foot: on worlds below −80 °C or above 80 °C the suit's heat reserve runs
// down while you walk (1.5–2.5 minutes; four times longer with Thermal lining). It refills
// aboard the Kestrel or right beside it. Empty means the same emergency recall as a failed suit.
let warmth = 1,
    exposureWarned = null;
function updateExposure(dt) {
    const severity = exposureOf(activeBody.physics?.temperature ?? 288);
    const sheltered = mode !== "walk" || surfacePoint(playerNormal).distanceTo(shipPosition) < 9;
    if (!severity || sheltered) {
        warmth = Math.min(1, warmth + dt * 0.2);
        return null;
    }
    if (exposureWarned !== activeBody.id) {
        exposureWarned = activeBody.id;
        const cold = activeBody.physics.temperature < 288;
        toast(`${cold ? "Extreme cold" : "Extreme heat"}: your suit's heat reserve is running down. Stay near the Kestrel to recharge it${codex.unlocked.has("thermalLining") ? "" : ", or install Thermal lining to stay out longer"}.`, 7);
    }
    warmth = Math.max(0, warmth - dt * (1 + 0.65 * severity) / 150 * exposureScale(codex.unlocked));
    if (warmth <= 0) {
        warmth = 1;
        recallToShip();
        toast("Suit heat reserve empty. Emergency recall: you are back beside the Kestrel.", 6);
    }
    return activeBody.physics.temperature < 288 ? "COLD" : "HEAT";
}
function updateSuit(dt) {
    sinceHit += dt;
    if (sinceHit > 6) suit = Math.min(1, suit + dt * 0.05 * suitRecoveryScale(codex.unlocked));
    const exposure = updateExposure(dt);
    const lines = [];
    if (mode === "walk" && suit < 0.999) lines.push(`SUIT INTEGRITY ${Math.round(suit * 100)}%${sinceHit > 6 ? " · RECOVERING" : ""}`);
    if (mode === "walk" && (exposure || warmth < 0.999)) lines.push(`${exposure === "HEAT" ? "COOLING" : "HEAT"} RESERVE ${Math.round(warmth * 100)}%${exposure ? ` · EXTREME ${exposure === "HEAT" ? "HEAT" : "COLD"}` : " · RECHARGING"}`);
    suitReadout.style.display = lines.length ? "block" : "none";
    if (lines.length) suitReadout.innerHTML = lines.join("<br>");
}
// Life sonar: on foot, an arrow at the top of the view points to the nearest plant or
// animal species on this world that you have not recorded yet (within 600 m).
const sonarView = document.createElement("div");
sonarView.style.cssText =
    "position:fixed;left:50%;top:112px;transform:translateX(-50%);z-index:3;pointer-events:none;display:none;text-align:center;font:600 9px 'DM Sans',sans-serif;letter-spacing:2px;color:#9ff0c0;text-shadow:0 1px 6px #000";
sonarView.innerHTML = '<b style="display:block;font-size:20px;line-height:22px;transition:transform .2s">▲</b><span></span>';
// The suit readouts and the sonar share one column under the header, so they never overlap.
const topStack = document.createElement("div");
topStack.style.cssText = "position:fixed;left:50%;top:84px;transform:translateX(-50%);z-index:3;pointer-events:none;display:flex;flex-direction:column;align-items:center;gap:8px";
document.body.append(topStack);
for (const el of [suitReadout, sonarView]) {
    el.style.position = "static";
    el.style.transform = "none";
    topStack.append(el);
}
let sonarTimer = 0,
    sonarTarget = null; // { point, kind }
function nearestUnrecorded() {
    const here = surfacePoint(playerNormal), known = scannedHere();
    let best = null, bestD = 600 * 600;
    const offer = (point, kind) => {
        const d = point.distanceToSquared(here);
        if (d < bestD) { bestD = d; best = { point, kind }; }
    };
    for (const sp of site.fauna?.species || []) {
        if (known.fauna.includes(sp.id)) continue;
        for (const p of site.fauna.positionsOf(sp)) offer(p, "animal");
    }
    for (const { species, positions } of site.flora?.placed || []) {
        if (known.flora.includes(species.id)) continue;
        for (let i = 0; i < positions.length; i += 3) {
            const dx = positions[i] - here.x, dy = positions[i + 1] - here.y, dz = positions[i + 2] - here.z;
            const d = dx * dx + dy * dy + dz * dz;
            if (d < bestD) { bestD = d; best = { point: vec(positions[i], positions[i + 1], positions[i + 2]), kind: "plant" }; }
        }
    }
    return best;
}
function updateSonar(dt) {
    if (!codex.unlocked.has("lifeSonar") || mode !== "walk" || !site || modalOpen()) {
        sonarView.style.display = "none";
        return;
    }
    if ((sonarTimer -= dt) <= 0) {
        sonarTimer = 0.5;
        sonarTarget = nearestUnrecorded();
    }
    if (!sonarTarget) {
        sonarView.style.display = "none";
        return;
    }
    const here = surfacePoint(playerNormal), to = sonarTarget.point.clone().sub(here);
    const right = playerForward.clone().cross(playerNormal);
    const angle = Math.atan2(to.dot(right), to.dot(playerForward));
    sonarView.style.display = "block";
    sonarView.firstChild.style.transform = `rotate(${angle.toFixed(3)}rad)`;
    sonarView.lastChild.textContent = `UNRECORDED ${sonarTarget.kind.toUpperCase()} · ${fmtDistance(to.length())}`;
}
// Back on foot beside the parked ship, facing away from it.
function recallToShip() {
    const up = shipPosition.clone().normalize(),
        right = shipForward.clone().cross(up).normalize();
    playerNormal = shipPosition.clone().addScaledVector(right, 5.5).addScaledVector(shipForward, 2).normalize();
    playerForward = tangent(right, playerNormal);
    jumpHeight = 0;
    jumpVelocity = 0;
    keys.clear();
}

// Animals hunt each other whether or not you watch; if a catch happens near you, say so.
const sunDirection = new THREE.Vector3();
let lastHuntToast = -Infinity;
function witnessHunts(watcher) {
    if (!watcher || animationTime - lastHuntToast < 25) return;
    for (const e of site.fauna.events)
        if (e.type === "catch" && e.position.distanceTo(watcher.position) < 70) {
            lastHuntToast = animationTime;
            toast(`You watch a ${e.hunter.sp.name} catch a ${e.prey.sp.name}.`, 5);
            return;
        }
}

// The HUD reads live state through these getters (hud.js).
const hudState = {
    get mode() { return mode; },
    get autoApproach() { return autoApproach; },
    get stage() { return stage; },
    get discovered() { return discovered; },
    get selectedBody() { return selectedBody; },
    get activeBody() { return activeBody; },
    get shipPosition() { return shipPosition; },
    get playerNormal() { return playerNormal; },
    get speed() { return speed; },
    get verticalSpeed() { return verticalSpeed; },
    get signalNormal() { return signalNormal; },
    get worldOrigin() { return worldOrigin; },
    get system() { return system; },
    get deep() { return deepInfo(); },
    get target() { return target; },
    get scanLabel() {
        if (mode !== "walk" || !scanTarget) return null;
        const verb = verbFor(scanTarget);
        return scanTarget.known ? "Details" : scanProgress > 0 ? { scan: "Scanning…", observe: "Observing…", record: "Recording…", sample: "Drilling…" }[verb] : `Hold to ${verb}`;
    },
    clearTarget,
    camera,
    shipShadow,
    surfacePoint,
    distanceToSignal,
    altitude,
    openMap,
    act,
    approach,
    openGalaxy,
    positionOf,
};
const refreshHUD = () => {
    updateHUD(hudState);
    const glasses = hasFieldGlasses(codex.unlocked);
    document.body.classList.toggle("glasses", glasses);
    if (glasses && mode === "walk") $("controlHint").innerHTML = $("controlHint").innerHTML.replace("<kbd>E</kbd> scan / interact", "<kbd>E</kbd> scan / interact <kbd>Z</kbd> zoom");
};
let hudTimer = 0;
function frame(now) {
    requestAnimationFrame(frame);
    const dt = Math.min((now - previousTime) / 1000, 0.05);
    previousTime = now;
    if (document.hidden) return;
    advanceOrbits();
        const paused = modalOpen();
    if (paused && input.mouseLocked()) document.exitPointerLock?.();
    if (!paused) {
        animationTime += dt;
        if (started) {
            if (mode === "deep") updateDeep(dt);
            else if (mode === "space") updateSpace(dt);
            else if (mode === "transit") updateCruise(dt);
            else if (mode === "flight") updateFlight(dt);
            else if (mode === "landing" || mode === "takeoff")
                updateManeuver(dt);
            else if (mode === "walk") updateWalk(dt);
        } else orientShip();
        updateFlow(dt);
        updateApproachSite();
        updateCamera(dt);
        if (started) updateWaypoint(hudState);
        if (started) drawScanMarker();
        updateHeat(dt);
        updateSuit(dt);
        updateSonar(dt);
        updateAtmosphere();
        updateSkyEvents(dt);
        updateNightFilter(dt);
        updateBehaviourAlerts(dt);
        if (site) animateSite(dt);
        if (site?.fauna && mode !== "space" && mode !== "transit" && mode !== "deep") {
            const watcher =
                mode === "walk"
                    ? { position: surfacePoint(playerNormal), onFoot: true }
                    : altitude() < 60
                      ? { position: shipPosition, onFoot: false }
                      : null;
            // In a total eclipse the animals act as if night had fallen.
            sunDirection.copy(sun.position).normalize();
            if (eclipseCover > 0.9) sunDirection.negate();
            site.fauna.update(dt, animationTime, watcher, sunDirection);
            witnessHunts(watcher);
            sufferAttacks();
        }
        updateShipEffects(
            kestrel,
            {
                mode,
                speed,
                verticalSpeed,
                altitude: altitude(),
                maneuverTime: maneuver?.time ?? 0,
                animationTime,
                shipPosition,
                surfacePoint,
            },
            dt,
        );
        toastTime -= dt;
        if (toastTime <= 0) $("toast").classList.remove("visible");
        hudTimer += dt;
        if (hudTimer > 0.08) {
            refreshHUD();
            hudTimer = 0;
        }
    }
    engine.update(
        !paused &&
            started &&
            (mode === "flight" || mode === "landing" || mode === "takeoff" || mode === "space" || mode === "transit"),
        // In space the engine note climbs with speed too, scaled to space speeds.
        mode === "space" || mode === "transit" ? 30 + Math.min(Math.abs(speed), 1500) * 0.12 : speed,
        verticalSpeed,
    );
    if (!starMap.isOpen) {
        if (mode !== "deep") {
            systemView.update(camera.position, streamer);
            sky.follow(camera);
        } else streamer.pump(4);
        renderer.render(scene, camera); // the full-screen map hides the scene
    }
}
window.addEventListener("resize", () => {
    starMap.resize();
    sky.resize();
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
});
canvas.addEventListener("webglcontextlost", (e) => {
    e.preventDefault();
    keys.clear();
    $("error").hidden = false;
    $("errorMessage").textContent =
        "The graphics context was interrupted. Reload to start again; recorded discoveries are preserved.";
});
orientShip();
camera.position
    .copy(shipPosition)
    .addScaledVector(shipForward, -22)
    .addScaledVector(shipPosition.clone().normalize(), 10);
camera.up.copy(shipPosition.clone().normalize());
camera.lookAt(shipPosition);
refreshWorldLabels();
setStage(discovered ? 3 : 0);
refreshHUD();
// Field scanner (upgrade): the HUD counts what is left to record on this world.
let tallyTimer = 0;
function updateTally(now = false, dt = 1 / 60) {
    if (!now && (tallyTimer += dt) < 0.5) return;
    tallyTimer = 0;
    const el = $("worldTally");
    if (!el) return;
    const totals = site && !activeBody.giant ? siteTotals() : null;
    const on = totals && ["walk", "landed", "flight", "landing", "takeoff"].includes(mode);
    el.hidden = !on;
    if (!on) return;
    const got = recordedOn(codex.entries, system.seed, activeBody.id);
    const rows = [["Plants", got.flora, totals.flora], ["Animals", got.fauna, totals.fauna], ["Geology", got.formation, totals.formations]].filter(([, , t]) => t > 0);
    const html = rows.map(([w, g, t]) => `<div class="tally-row${g >= t ? " done" : ""}"><span>${w}</span><b>${Math.min(g, t)} / ${t}</b><i style="--f:${Math.min(1, g / t).toFixed(3)}"></i></div>`).join("") + skyLine();
    if (el.innerHTML !== html) el.innerHTML = html;
}
// What the landing site actually holds (a species that found no room is not counted).
function siteTotals() {
    return {
        flora: site.flora?.placed?.filter((p) => p.positions.length).length ?? 0,
        fauna: site.fauna?.species?.length ?? 0,
        formations: site.geology?.placed?.filter((p) => p.scales.some((x) => x > 0)).length ?? 0,
    };
}
function animateSite(dt) {
    upgradeScreen.setMode(mode);
    updateTally(false, dt);
    if (site.flora) site.flora.update(animationTime);
    if (site.structures) site.structures.update(animationTime);
    if (site.groundCover) site.groundCover.update(camera.position, animationTime);
    checkTraces(dt);
}
// Seeing a settlement (on foot nearby, or flying low over it) records who built it.
let tracesTimer = 0;
function checkTraces(dt) {
    const built = site.structures;
    if (!built?.civ || traces[activeBody.id] || (tracesTimer += dt) < 0.5) return;
    tracesTimer = 0;
    const here = mode === "walk" ? surfacePoint(playerNormal) : ["flight", "landed", "landing", "takeoff"].includes(mode) && altitude() < 140 ? shipPosition : null;
    if (!here) return;
    const reach = (mode === "walk" ? 45 : 110) + built.civ.unit * 10;
    if (!built.sites.some((n) => n.clone().multiplyScalar(RADIUS).distanceTo(here) < reach)) return;
    traces[activeBody.id] = built.civ.tier; // a name, so a longer ladder later keeps old saves meaningful
    saveSurvey();
    showScanCard({ kind: "settlement", ref: built.civ }, recordInfo(settlementEntry(system, activeBody, civilizationOf(activeBody), built.civ.tier)));
}
requestAnimationFrame(frame);

// --- Galaxy travel: jumps reload into the destination system. ---
let jumping = false;
let beaconCache = { n: -1, set: null };
const starMap = createStarMap({
    jumpRange: () => rangeFor(codex.unlocked),
    radioHearing: () => radioHearing(codex.unlocked),
    decodes: () => decodesSignals(codex.unlocked),
    orbitalSurvey: () => codex.unlocked.has("orbitalSurvey"),
    // Return beacons: the seeds of systems with a fully documented world (recomputed when the codex grows).
    beacons: () => {
        if (!codex.unlocked.has("returnBeacons")) return null;
        if (beaconCache.n !== codex.entries.length) beaconCache = { n: codex.entries.length, set: new Set(completedWorlds(codex.entries).map((e) => e.seed)) };
        return beaconCache.set;
    },
    // Radio sources heard from here go into the codex quietly (they arrive in the background).
    onRadio: (sources) => sources.forEach((s) => record(signalEntry(s))),
    here: currentStar,
    system,
    deep: () => (mode === "deep" ? { position: galactic, course } : null),
    onCourse: (star) => setCourse(star),
    clearCourse: () => clearTarget(),
    course: () => course,
    state: galaxyState,
    offChart: () => offChart,
    canJump: () => started && mode === "space" && !jumping,
    blockedReason: () =>
        !started
            ? "Begin the expedition first."
            : mode === "transit"
              ? "Disengage cruise (T) before jumping."
              : "The jump drive needs free space: take off and climb above 600 m, then jump.",
    onJump: (star, name) => {
        jumping = true;
        keys.clear();
        starMap.close();
        galaxyState.current = star.id;
        galaxyState.visited.add(star.id);
        galaxyState.jumps++;
        saveGalaxyState(galaxyState);
        try {
            sessionStorage.setItem("elsewhere-arrival", star.id);
        } catch {}
        playJump(name, () => {
            // The destination is already saved, so a plain reload lands there even
            // where query strings are unavailable; the URL is updated where it can be.
            try {
                history.replaceState(null, "", `?star=${star.id}`);
            } catch {}
            if (new URLSearchParams(location.search).get("star") === star.id || !location.search) location.reload();
            else location.search = `?star=${star.id}`;
        });
    },
        survey: () => ({
        records,
        visited,
                activeId: activeBody.id,
        flora: catalogue,
        fauna: bestiary,
        traces,
        geology: strata,
    }),
    selectedBody: () => selectedBody,
    onSelectBody: (body) => {
        selectedBody = body;
        if (body.id !== activeBody.id) target = body;
    },
    cruise: (body) => {
        if (body.id === activeBody.id && mode !== "space" && mode !== "transit")
            return { enabled: false, label: "You are here" };
        if (mode === "transit")
            return {
                enabled: false,
                label: "Cruise in progress",
                note: "Press T to disengage.",
            };
        if (!started)
            return { enabled: false, label: "Begin expedition first" };
        if (!["flight", "space"].includes(mode))
            return {
                enabled: false,
                label: "Take off to travel",
                note: "Return to Kestrel and lift off to cruise to another world.",
            };
        return { enabled: true, label: `Cruise to ${body.name} ↗` };
    },
    onCruise: (body) => {
        selectedBody = body;
        beginCruise();
    },
});
function openGalaxy() {
    if ($("help").open || $("discovery").open) return;
    keys.clear();
    starMap.open("local");
}
// G still opens the map on nearby stars; the one Map button (M) covers both.
try {
    if (
        sessionStorage.getItem("elsewhere-arrival") === currentStar.id &&
        !offChart
    ) {
        sessionStorage.removeItem("elsewhere-arrival");
        start();
        arriveNear(activeBody);
        playArrival();
        toast(
            `Jump complete: ${system.name}, a ${system.star.physics.spectralClass} star with ${system.bodies.length} worlds. ${activeBody.name} is ahead.`,
            6,
        );
    }
} catch {}
// Not a jump arrival after all (or storage is blocked): show the start menu as usual.
if (!started) document.documentElement.classList.remove("arriving");
