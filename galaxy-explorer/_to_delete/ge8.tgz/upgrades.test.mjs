import test from 'node:test';
import assert from 'node:assert/strict';
import { UPGRADES, BRANCHES, progress, advanced, matches, hint, completedWorlds, recordedOn, jumpRange } from './upgrades.mjs';
import * as C from './codex.mjs';
import { generateSystem } from './system.mjs';
import { floraFor } from './flora.mjs';
import { faunaFor } from './fauna.mjs';
import { geologyFor } from './geology.mjs';
import { civilizationOf } from './civilizations.mjs';
import { homeStar, jumpTargets, JUMP_RANGE } from './galaxy.mjs';

// Everything there is to record on a world, as codex entries.
const everything = (system, body) => [
  C.worldEntry(system, body), C.fieldNoteEntry(system, body),
  ...floraFor(body).species.map((s) => C.floraEntry(system, body, s)),
  ...faunaFor(body).species.map((s) => C.faunaEntry(system, body, s)),
  ...geologyFor(body).formations.map((f) => C.formationEntry(system, body, f)),
  ...(civilizationOf(body) ? [C.settlementEntry(system, body, civilizationOf(body))] : []),
];
// A small hand-made entry, for matching tests.
const E = (kind, traits = {}, world = {}, where = { seed: '1', bodyId: 'planet-0' }) =>
  ({ kind, ...where, id: `${kind}-${Math.random()}`, traits, world: { biome: 'Verdant', ...world } });
const memory = () => { const m = new Map(); return { getItem: (k) => m.get(k) ?? null, setItem: (k, v) => m.set(k, String(v)), key: (i) => [...m.keys()][i], get length() { return m.size; } }; };
const ids = Object.keys(UPGRADES);

test('the tree is well formed', () => {
  const branches = new Set(BRANCHES.map((b) => b.id));
  for (const u of Object.values(UPGRADES)) {
    assert.ok(branches.has(u.branch), `${u.id}: unknown branch ${u.branch}`);
    assert.ok(['live', 'partial', 'planned'].includes(u.status), `${u.id}: status`);
    assert.ok(u.name && u.effect && u.needs.length, `${u.id}: name, effect and needs`);
    for (const a of u.after) assert.ok(ids.includes(a), `${u.id}: unknown prerequisite ${a}`);
    for (const n of u.needs) {
      assert.ok(n.label, `${u.id}: every need has a label`);
      assert.ok((n.count ?? 1) <= 12, `${u.id}: counts stay small`);
    }
  }
  // No cycles: every upgrade can be reached by unlocking prerequisites first.
  const done = new Set();
  for (let pass = 0; pass < ids.length; pass++)
    for (const u of Object.values(UPGRADES)) if (u.after.every((a) => done.has(a))) done.add(u.id);
  assert.equal(done.size, ids.length);
  // Starter nodes have no prerequisites.
  for (const u of Object.values(UPGRADES)) if (u.branch === 'starter') assert.deepEqual(u.after, []);
});

test('every need has a readable hint', () => {
  for (const u of Object.values(UPGRADES)) for (const n of u.needs) {
    const h = hint(n);
    assert.ok(h && !/undefined|null/.test(h), `${u.id}: "${n.label}" -> ${h}`);
  }
  assert.match(hint(UPGRADES.pressureHull1.needs[0]), /Oceanic and Verdant/);
  assert.match(hint(UPGRADES.heatPlating.needs[1]), /Volcanic worlds/);
});

test('queries match names, lists, ranges, tiers and nested traits', () => {
  assert.ok(matches(E('fauna', { plan: 'slug' }), { kind: 'fauna', traits: { plan: ['serpent', 'slug'] } }));
  assert.ok(!matches(E('flora', { plan: 'slug' }), { kind: 'fauna' }));
  assert.ok(matches(E('flora', { glow: 0.6 }), { kind: ['flora', 'fauna'], traits: { glow: { min: 0.45 } } }));
  assert.ok(!matches(E('flora', { glow: 0.2 }), { kind: 'flora', traits: { glow: { min: 0.45 } } }));
  assert.ok(matches(E('flora', { habitat: { shore: true, highland: false } }), { kind: 'flora', traits: { habitat: { shore: true } } }));
  assert.ok(matches(E('settlement', { tier: 'planet-shapers' }), { kind: 'settlement', traits: { tier: { atLeast: 'city builders' } } }));
  assert.ok(!matches(E('settlement', { tier: 'village builders' }), { kind: 'settlement', traits: { tier: { atLeast: 'city builders' } } }));
  assert.ok(matches(E('formation', { formation: 'seastacks' }), UPGRADES.pressureHull1.needs[2]), 'anyOf');
  // "any" means things you documented, not worlds you visited or signals you heard.
  assert.ok(matches(E('formation'), { kind: 'any' }));
  assert.ok(!matches(E('world'), { kind: 'any' }));
});

test('progress counts distinct values, spreads and single worlds', () => {
  const w = (bodyId) => ({ seed: '7', bodyId });
  const entries = [
    E('flora', {}, { biome: 'Verdant' }, w('a')), E('flora', {}, { biome: 'Verdant' }, w('a')),
    E('flora', {}, { biome: 'Desert' }, w('b')), E('flora', {}, { biome: 'Frozen' }, w('c')),
    E('formation', { formation: 'strata' }, {}, w('a')), E('formation', { formation: 'strata' }, {}, w('b')),
  ];
  const p = progress(entries);
  assert.deepEqual({ have: p.deepCoreSampler.needs[0].have, done: p.deepCoreSampler.needs[0].done }, { have: 1, done: false }, 'two strata are one kind');
  assert.equal(p.suitPlating.needs[0].have, 3, 'three things on world a');
  assert.ok(p.suitPlating.ready);
  const j = p.jumpDrive2.needs[0];
  assert.equal(j.have, 4);
  assert.deepEqual(j.spread[0], { label: 'biomes', have: 3, need: 3 });
  assert.ok(!j.done, 'four plants is not five');
  entries.push(E('flora', {}, { biome: 'Desert' }, w('b')));
  assert.ok(progress(entries).jumpDrive2.ready);
});

test('prerequisites, ship classes and the upgrade count', () => {
  const p = progress([], new Set(['jumpDrive2', 'suitPlating', 'petrel']));
  assert.ok(p.jumpDrive3.available && !p.jumpDrive3.ready);
  assert.ok(!p.cloudDiver.available, 'needs Pressure hull II too');
  assert.equal(p.petrel.unlocked, true);
  assert.equal(p.albatross.needs[0].have, 2, 'ship classes do not count as upgrades');
  assert.equal(p.diplomaticProtocols.needs[0].notYet, 'Contact');
});

test('hunting pairs and fully documented worlds', () => {
  const where = { seed: '3', bodyId: 'planet-1' };
  const hunter = { ...E('fauna', { diet: 'carnivore', prey: ['an-2'] }, {}, where), id: 'an-0' };
  const prey = { ...E('fauna', { diet: 'herbivore', prey: [] }, {}, where), id: 'an-2' };
  assert.equal(progress([hunter]).behaviourLogger.needs[0].have, 0);
  assert.ok(progress([hunter, prey]).behaviourLogger.ready);
  const world = { ...E('world', { totals: { flora: 1, fauna: 2, formations: 1 } }, {}, where), id: 'planet-1' };
  const flora = E('flora', {}, {}, where), rock = E('formation', { formation: 'strata' }, {}, where);
  assert.equal(completedWorlds([world, hunter, flora, rock]).length, 0);
  assert.equal(completedWorlds([world, hunter, prey, flora, rock]).length, 1);
  assert.deepEqual(recordedOn([world, hunter, prey, flora, rock], 3, 'planet-1'), { flora: 1, fauna: 2, formation: 1 });
});

test('advanced() names what a new entry moved forward', () => {
  const where = { seed: '9', bodyId: 'planet-0' };
  const before = [E('formation', { formation: 'strata' }, {}, where), E('flora', {}, {}, where)];
  const after = [...before, E('formation', { formation: 'columns' }, {}, where)];
  const moved = advanced(progress(before), progress(after));
  const core = moved.find((m) => m.id === 'deepCoreSampler');
  assert.deepEqual({ have: core.have, count: core.count, ready: core.ready }, { have: 2, count: 6, ready: false });
  assert.ok(moved.some((m) => m.id === 'suitPlating' && m.ready));
  assert.ok(moved.some((m) => m.id === 'heatPlating' && !m.ready), 'basalt columns count toward Heat plating');
});

test('effects read unlocked upgrades', () => {
  assert.equal(jumpRange(new Set()), JUMP_RANGE);
  assert.equal(jumpRange(new Set(['jumpDrive2'])), 16);
  assert.equal(jumpRange(new Set(['jumpDrive2', 'jumpDrive3'])), 24);
});

test('the codex keeps one entry per thing, saves and restores', () => {
  const storage = memory(), codex = C.createCodex(storage);
  const system = generateSystem(homeStar().seed), body = system.bodies.find((b) => !b.giant);
  const f = geologyFor(body).formations[0];
  assert.ok(codex.add(C.formationEntry(system, body, f)));
  assert.ok(!codex.add(C.formationEntry(system, body, f)), 'recorded once');
  codex.add(C.worldEntry(system, body, { flora: 0, fauna: 0, formations: 9 }));
  codex.add(C.worldEntry(system, body, { flora: 0, fauna: 0, formations: 2 }));
  codex.unlock('suitPlating');
  codex.track('suitPlating');
  const again = C.createCodex(storage);
  assert.equal(again.entries.length, 2);
  assert.equal(again.entries.find((e) => e.kind === 'world').traits.totals.formations, 2, 'totals are corrected');
  assert.ok(again.unlocked.has('suitPlating'));
  assert.equal(again.tracked, 'suitPlating');
  assert.equal(again.entries[0].traits.formation, f.key, 'formations are stored by name');
});

test('older per-system saves are copied into the codex', () => {
  // A system with animals and plants somewhere near home.
  let system, body;
  for (const t of [homeStar(), ...jumpTargets(homeStar(), 30).targets.map((x) => x.star)]) {
    system = generateSystem(t.seed);
    body = system.bodies.find((b) => faunaFor(b).species.length && floraFor(b).species.length);
    if (body) break;
  }
  assert.ok(body, 'a living world near home');
  const storage = memory();
  storage.setItem(`elsewhere-system-${system.seed}`, JSON.stringify({
    records: [body.id], visited: [body.id],
    flora: { [body.id]: [floraFor(body).species[0].id] }, fauna: { [body.id]: [faunaFor(body).species[0].id] },
    geology: { [body.id]: [geologyFor(body).formations[0].id] }, traces: {},
  }));
  const codex = C.createCodex(storage);
  assert.equal(C.backfill(codex, storage), 5);
  assert.deepEqual(codex.entries.map((e) => e.kind).sort(), ['fauna', 'field-note', 'flora', 'formation', 'world']);
  assert.equal(codex.entries.find((e) => e.kind === 'fauna').traits.plan, faunaFor(body).species[0].plan);
  assert.ok(codex.backfilled);
  assert.equal(C.backfill(codex, storage), 0, 'nothing is copied twice');
});

// Reachability (PROGRESSION.md): the galaxy is fixed, so check it. Starter nodes can be
// finished on the first world you land on (Orbital survey asks for a second world in the
// same system), every upgrade without prerequisites within 3 jumps of home, and the
// rest within 5. Requirements that wait on Contact (signals, relationships) are skipped.
test('upgrades are reachable from the home star', () => {
  const home = homeStar(), system = generateSystem(home.seed);
  const first = system.bodies.find((b) => b.id === system.startId);
  const all = new Set(ids.filter((id) => !UPGRADES[id].ship));
  const met = (entries) => { const p = progress(entries, all); return (id) => p[id].needs.every((n) => n.done || n.notYet || UPGRADES[id].needs.find((x) => x.label === n.label).kind === 'signal'); };
  const onFirst = met(everything(system, first));
  assert.ok(onFirst('suitPlating'), `the first upgrade on ${first.name}`);
  const entries = system.bodies.flatMap((b) => everything(system, b));
  assert.ok(met(entries)('orbitalSurvey'), 'Orbital survey in the home system');
  let frontier = [home], seen = new Set([home.id]), check;
  const firstHop = {};
  for (let hop = 0; hop <= 5; hop++) {
    if (hop) {
      const next = [];
      for (const st of frontier) for (const t of jumpTargets(st).targets) if (!seen.has(t.star.id)) { seen.add(t.star.id); next.push(t.star); }
      frontier = next;
      for (const st of frontier) { const s = generateSystem(st.seed); entries.push(...s.bodies.flatMap((b) => everything(s, b))); }
    }
    check = met(entries);
    for (const id of ids) if (!(id in firstHop) && check(id)) firstHop[id] = hop;
  }
  for (const u of Object.values(UPGRADES)) {
    if (u.needs.some((n) => n.special === 'relationship')) continue;
    const limit = u.after.length ? 5 : 3;
    assert.ok(firstHop[u.id] <= limit, `${u.name} within ${limit} jumps (first met at ${firstHop[u.id] ?? 'never'})`);
  }
});
