// Inside a home: built only when you step through a door (structures-mesh.js records the
// dwellings and their doors), and thrown away when you leave, so towns cost nothing extra
// until you go in. The room is the size of the house it is in, and houses are built to
// the size of their builders (structures.mjs unit), so a giant's hall is vast and a small
// species' burrow too low for you to enter at all (canEnter).
//
// What is inside follows how they live, not how we do: hands-builders keep a hearth, a
// work table, shelves and a sleeping mat; nest-builders perches at different heights and
// a woven nest-bowl; burrowers low earthen alcoves and a moss bed; hive-builders walls of
// glowing wax cells and storage vats; web-builders silk hammocks and threads strung across
// the room; grazers troughs of fodder and soft mounds to lie on; rollers ramps and smooth
// resting bowls; tentacled builders pools and hanging racks; tripods tall lean-boards (no
// one sits). The more advanced, the more their homes glow: lit panels, then a floating
// light. Ruins are empty, broken and grown over.
//
// One or two of the household are at home, busy at something; how they take you coming
// in is their people's stance toward you (station-deck.js stanceOf): welcoming ones come
// over and greet you, curious ones come close to look, wary ones back away to the far
// wall, guarded ones stand tall and watch. You can talk to them (contact-ui.js) as on a
// station deck: talkWith(i) / gesture(i), as station-deck.js has them.
//
//   canEnter(dwelling, civ) -> { ok, why }
//   const room = buildInterior(THREE, { dwelling, civ, palette, stance, ruins, seed })
//   room: { group, radius, height, start: { x, z, yaw }, door: { x, z }, species,
//           resolve(x0, z0, x1, z1, rad), update(dt, t, player{ x, z } | null), crew(),
//           talkWith(i), gesture(i, kind), dispose() }
// Local frame: floor at y = 0, the door on the +z wall; the group takes dwelling.base.
import { rng } from './rng.mjs';
import { buildCrew } from './fauna-mesh.js';
import { createExpression, express, lookAngles, startGesture, gestureOf, moodOf } from './express.mjs';

const EYE = 1.75;
const SQUARE = ['timber', 'terraced', 'stilts', 'tracks'];
const roomOf = (d) => ({ R: d.foot * .95, H: Math.min(d.h * .82, d.foot * 2.4) });

// Can you go in? (Too low, too narrow, or not on the ground.)
export function canEnter(d, civ) {
  if (!d) return { ok: false, why: '' };
  if (civ?.underwater) return { ok: false, why: 'under the sea' };
  const { R, H } = roomOf(d);
  if (H < 2.2 || R < 1.5) return { ok: false, why: 'small' };
  return { ok: true, why: '' };
}

export function buildInterior(THREE, { dwelling: d, civ, palette: C = {}, stance = 'welcome', ruins = false, seed = 'room', light = null }) {
  const r = rng(seed, 'interior'), { R, H } = roomOf(d), u = Math.max(.55, civ.unit || 1);
  const family = civ.family, level = civ.level || 1, culture = civ.culture, square = SQUARE.includes(culture);
  const group = new THREE.Group();
  group.matrixAutoUpdate = false; group.matrix.copy(d.base); group.matrixWorldNeedsUpdate = true;
  const col = (hex, k = 0) => new THREE.Color(hex || '#888').lerp(new THREE.Color(ruins ? '#4f6a3a' : '#000'), ruins ? .35 : k);
  const mats = new Map();
  const mat = (hex, { glow = 0, k = 0, side = THREE.FrontSide } = {}) => {
    const key = `${hex}|${glow}|${k}|${side}`;
    if (!mats.has(key)) { const c = col(hex, k); mats.set(key, new THREE.MeshStandardMaterial({ color: c, roughness: .85, emissive: c.clone().multiplyScalar(glow || .05), side, flatShading: true })); }
    return mats.get(key);
  };
  const solids = []; // circles you walk round: { x, z, r, h }
  const add = (geo, hex, x, y, z, opts = {}, solid = null) => {
    const m = new THREE.Mesh(geo, mat(hex, opts)); m.position.set(x, y, z); if (opts.ry) m.rotation.y = opts.ry; if (opts.rx) m.rotation.x = opts.rx; if (opts.rz) m.rotation.z = opts.rz;
    group.add(m); if (solid) solids.push({ x, z, r: solid.r, h: solid.h ?? 9 }); return m;
  };
  const wallHex = C.wall || '#8a7a66', floorHex = family === 'burrowers' || family === 'grazers' ? (C.soil || C.path) : C.wall2 || C.stone;

  // --- The shell: floor, wall, ceiling, the doorway's daylight, windows -------------------
  const segs = square ? 4 : 18;
  const wall = new THREE.CylinderGeometry(R, R, H, segs, 1, true);
  if (square) wall.rotateY(Math.PI / 4);
  add(wall, wallHex, 0, H / 2, 0, { side: THREE.BackSide, glow: .06, k: .3 });
  add(new THREE.CircleGeometry(R * (square ? 1.02 : 1.01), segs).rotateX(-Math.PI / 2).rotateY(square ? Math.PI / 4 : 0), floorHex, 0, .01, 0, { glow: .1 });
  const roofShape = family === 'hive' || family === 'burrowers' || culture === 'domes' || culture === 'shells' ? 'dome' : 'flat';
  if (roofShape === 'dome') add(new THREE.SphereGeometry(R, segs, 8, 0, Math.PI * 2, 0, Math.PI / 2), C.wall2 || wallHex, 0, H * .7, 0, { side: THREE.BackSide, glow: .12 }).scale.set(1, (H * .5) / R, 1);
  else add(new THREE.CircleGeometry(R * 1.02, segs).rotateX(Math.PI / 2).rotateY(square ? Math.PI / 4 : 0), C.roof2 || wallHex, 0, H, 0, { glow: .1 });
  if (square || family === 'hands') for (let i = 0; i < 3; i++) add(new THREE.BoxGeometry(R * 1.9, .14 * u, .18 * u), C.wood || '#5a4030', 0, H - .1, (i - 1) * R * .6, { k: .2 }); // beams
  // The doorway: daylight (or the dark) where you came in.
  const doorW = Math.min(1.1 * Math.max(1, u * .7), R * .6), doorH = Math.min(H * .85, 2.2 * Math.max(1, u * .6));
  const dz = square ? R * .707 : R;
  add(new THREE.PlaneGeometry(doorW, doorH), '#fff6dc', 0, doorH / 2, dz - .03, { glow: 1.6, ry: Math.PI });
  add(new THREE.BoxGeometry(doorW + .25 * u, .18 * u, .2), C.trim || '#ccc', 0, doorH + .09 * u, dz - .08);
  if (level >= 2 && !ruins) for (const a of [1.2, -1.2, Math.PI]) { // windows
    const wr = (square ? R * .707 : R) - .03, wx = Math.sin(a) * wr, wz = Math.cos(a) * wr;
    add(new THREE.PlaneGeometry(.7 * u, .55 * u), C.window || '#ffd98a', wx, H * .55, wz, { glow: 1.1, ry: a + Math.PI });
  }

  // --- Furnishings, by how they live -------------------------------------------------------
  const at = (a, f) => [Math.sin(a) * R * f, Math.cos(a) * R * f]; // a = 0 is the door
  const back = Math.PI;
  const hearth = (x, z) => {
    add(new THREE.CylinderGeometry(.55 * u, .65 * u, .25 * u, 10), C.stone || '#777', x, .12 * u, z, {}, { r: .7 * u, h: .3 });
    if (!ruins) { add(new THREE.ConeGeometry(.28 * u, .55 * u, 6), C.flame || '#ffc46b', x, .5 * u, z, { glow: 2.4 }); add(new THREE.SphereGeometry(.22 * u, 6, 4), C.ember || '#ff7a2a', x, .3 * u, z, { glow: 2 }); }
  };
  const spots = []; // where the household works or rests: { x, z, face, kind }
  const spot = (x, z, kind, faceTo = [0, 0]) => spots.push({ x, z, kind, face: Math.atan2(faceTo[1] - z, faceTo[0] - x), taken: -1 });
  switch (family) {
    case 'hands': case 'tentacles': case 'tripods': default: {
      if (level <= 3) { const [hx, hz] = at(back, .45); hearth(hx, hz); spot(hx + .9 * u, hz + .5 * u, 'tend', [hx, hz]); }
      // A work table with things on it; shelves of pots along the wall.
      const [tx, tz] = at(1.9, .45);
      if (family !== 'tripods') {
        add(new THREE.BoxGeometry(1.4 * u, .1 * u, .8 * u), C.wood || '#6b4a2f', tx, .82 * u, tz, { ry: 1.9 }, { r: .8 * u, h: .9 * u });
        for (const lx of [-.6, .6]) for (const lz of [-.3, .3]) add(new THREE.BoxGeometry(.08 * u, .8 * u, .08 * u), C.wood || '#6b4a2f', tx + lx * u * Math.cos(1.9) + lz * u * Math.sin(1.9), .4 * u, tz - lx * u * Math.sin(1.9) + lz * u * Math.cos(1.9), {});
        for (let i = 0; i < 3; i++) add(new THREE.CylinderGeometry(.08 * u, .1 * u, .2 * u, 6), i % 2 ? C.pot || '#a8643f' : C.accent || '#c0503a', tx + (i - 1) * .3 * u, .97 * u, tz, {});
      } else for (let i = 0; i < 3; i++) { const [x, z] = at(1.6 + i * .4, .78); add(new THREE.BoxGeometry(.25 * u, 2.4 * u, 1 * u), C.wood || '#6b4a2f', x, 1.2 * u, z, { ry: 1.6 + i * .4, rz: .12 }, { r: .5 * u }); } // lean-boards: no one sits
      spot(tx - Math.sin(1.9) * u * .9, tz - Math.cos(1.9) * u * .9, 'work', [tx, tz]);
      for (let i = 0; i < 4; i++) { const a = -1.5 - i * .38, [x, z] = at(a, .93); add(new THREE.BoxGeometry(.9 * u, .06 * u, .35 * u), C.wood || '#6b4a2f', x, 1.3 * u + (i % 2) * .5 * u, z, { ry: a }); add(new THREE.CylinderGeometry(.1 * u, .12 * u, .25 * u, 6), C.pot || '#a8643f', x, 1.46 * u + (i % 2) * .5 * u, z); }
      if (family === 'tentacles') { const [px, pz] = at(-2.3, .45); add(new THREE.CylinderGeometry(.9 * u, .9 * u, .12, 14), '#3d8fb0', px, .07, pz, { glow: .5 }, { r: .9 * u, h: .1 }); spot(px + u, pz, 'tend', [px, pz]); }
      else { const [mx, mz] = at(-2.2, .55); add(new THREE.BoxGeometry(1.8 * u, .14 * u, 1 * u), C.bag || '#d8c07a', mx, .07 * u, mz, { ry: -2.2 }); spot(mx, mz, 'rest', [0, 0]); }
      break;
    }
    case 'nests': {
      for (let i = 0; i < 5; i++) { const a = i * 1.25 + .6, [x, z] = at(a, .6 + (i % 2) * .2); add(new THREE.CylinderGeometry(.06 * u, .06 * u, R * .7), C.wood || '#6b4a2f', x, (1 + i * .45) * u, z, { rz: Math.PI / 2, ry: a }); }
      for (let i = 0; i < 3; i++) { const [x, z] = at(i * 2.1 + .6, .6); add(new THREE.CylinderGeometry(.07 * u, .07 * u, (1 + i * .9) * u, 5), C.wood || '#6b4a2f', x, (1 + i * .9) * u / 2, z, {}); }
      const [nx, nz] = at(back, .45);
      add(new THREE.TorusGeometry(.8 * u, .28 * u, 6, 14), C.roof || '#8a7a4a', nx, .3 * u, nz, { rx: Math.PI / 2 }, { r: 1.1 * u, h: .5 });
      spot(nx, nz, 'rest', [0, 0]); spot(...at(1.4, .5), 'work', [0, 0]);
      break;
    }
    case 'burrowers': {
      for (let i = 0; i < 4; i++) { const a = back + (i - 1.5) * .9, [x, z] = at(a, .98); add(new THREE.SphereGeometry(.9 * u, 8, 6, 0, Math.PI * 2, 0, Math.PI / 2), C.soil || '#5a4632', x, 0, z, { side: THREE.BackSide, glow: .08 }); }
      const [bx, bz] = at(-1.9, .5); add(new THREE.SphereGeometry(.9 * u, 8, 5).scale(1, .3, 1), C.turf || '#55703a', bx, .1, bz, {}, { r: .9 * u, h: .3 });
      for (let i = 0; i < 6; i++) { const [x, z] = at(1.3 + i * .25, .9); add(new THREE.SphereGeometry(.18 * u, 6, 4), C.pot || '#a8643f', x, .2 * u, z); }
      spot(bx, bz, 'rest', [0, 0]); spot(...at(1.6, .55), 'work', at(1.6, .95));
      break;
    }
    case 'hive': {
      for (let row = 0; row < 4; row++) for (let i = 0; i < 12; i++) { const a = back + (i - 5.5) * .2 + (row % 2) * .1, [x, z] = at(a, .96); add(new THREE.CylinderGeometry(.22 * u, .22 * u, .1, 6), C.wax || C.accent || '#d9a441', x, (.5 + row * .4) * u, z, { rx: Math.PI / 2, ry: a, glow: level >= 3 && (i + row) % 3 === 0 ? 1.2 : .25 }); }
      for (let i = 0; i < 3; i++) { const [x, z] = at(1.5 + i * .5, .6); add(new THREE.CylinderGeometry(.4 * u, .5 * u, .9 * u, 8), C.wax || '#d9a441', x, .45 * u, z, {}, { r: .55 * u }); }
      spot(...at(back, .65), 'work', at(back, .95)); spot(...at(2, .35), 'tend', at(2, .6));
      break;
    }
    case 'web': {
      for (let i = 0; i < 9; i++) { const a = i * .7, b = a + 2.4 + r() * .6, [x0, z0] = at(a, 1), [x1, z1] = at(b, 1), len = Math.hypot(x1 - x0, z1 - z0);
        add(new THREE.CylinderGeometry(.015, .015, len, 3), C.silk || '#f2f0ea', (x0 + x1) / 2, H * (.45 + r() * .4), (z0 + z1) / 2, { rz: Math.PI / 2, ry: -Math.atan2(z1 - z0, x1 - x0), glow: .4 }); }
      const [hx, hz] = at(back, .45); add(new THREE.SphereGeometry(.9 * u, 10, 6).scale(1.3, .35, .8), C.silk || '#f2f0ea', hx, 1.2 * u, hz, { glow: .3 });
      add(new THREE.SphereGeometry(.35 * u, 8, 6).scale(1, 1.6, 1), C.silk || '#f2f0ea', ...at(-1.6, .7).flatMap((v, i) => (i ? [1.6 * u, v] : [v])), { glow: .3 });
      spot(hx, hz + .9 * u, 'rest', [hx, hz]); spot(...at(1.7, .5), 'work', at(1.7, .9));
      break;
    }
    case 'grazers': {
      const [tx, tz] = at(1.6, .75); add(new THREE.BoxGeometry(2 * u, .45 * u, .6 * u), C.wood || '#6b4a2f', tx, .23 * u, tz, { ry: 1.6 }, { r: .9 * u, h: .5 });
      add(new THREE.BoxGeometry(1.8 * u, .1 * u, .45 * u), C.turf || '#55703a', tx, .48 * u, tz, { ry: 1.6 });
      for (const a of [back, -1.8]) { const [x, z] = at(a, .55); add(new THREE.SphereGeometry(1 * u, 10, 6).scale(1.2, .25, 1), C.bag || '#d8c07a', x, .08, z, {}); spot(x, z, 'rest', [0, 0]); }
      spot(tx - .9 * u, tz, 'graze', [tx, tz]);
      break;
    }
    case 'rollers': {
      for (const a of [back, -1.9, 1.9]) { const [x, z] = at(a, .55); add(new THREE.TorusGeometry(.8 * u, .18 * u, 6, 16), C.stone || '#888', x, .12, z, { rx: Math.PI / 2 }); spot(x, z, 'rest', [0, 0]); }
      const [rx, rz] = at(2.4, .85); add(new THREE.BoxGeometry(1.4 * u, .1, 2 * u), C.wood || '#6b4a2f', rx, .35 * u, rz, { ry: 2.4, rx: .3 });
      break;
    }
  }
  // Advanced homes glow: lit panels, then a floating light.
  if (!ruins && level >= 3) { const [x, z] = at(-1.4, .97); add(new THREE.PlaneGeometry(1.2 * u, .8 * u), C.window || '#9fe3e6', x, 1.5 * u, z, { glow: 1.6, ry: -1.4 + Math.PI }); }
  if (!ruins && level >= 4) add(new THREE.IcosahedronGeometry(.25 * u, 1), C.window || '#ffd98a', 0, H * .72, 0, { glow: 2.5 });
  if (ruins) for (let i = 0; i < 14; i++) { const [x, z] = at(r() * 6.28, .4 + r() * .6); add(new THREE.SphereGeometry((.2 + r() * .4) * u, 6, 4).scale(1, .4, 1), i % 3 ? '#4f7a3a' : C.stone || '#777', x, .05, z); }
  if (!spots.length) spot(...at(back, .5), 'rest', [0, 0]);

  // --- The household ----------------------------------------------------------------------
  const species = ruins ? null : civ.species;
  const crew = [];
  let mesh = null;
  if (species) {
    const n = Math.min(spots.length, 1 + (r() < .55 ? 1 : 0) + (R > 5 ? 1 : 0));
    mesh = buildCrew(THREE, species, n, seed);
    group.add(mesh.group);
    const rad = Math.max(.35, species.size * .55);
    // The household is at the far end, away from the door you come in by.
    spots.sort((a, b) => Math.hypot(b.x, b.z - R) - Math.hypot(a.x, a.z - R));
    for (let i = 0; i < n; i++) {
      const s = spots[i];
      s.taken = i;
      crew.push({ i, x: s.x, z: s.z, heading: s.face, speed: 0, cycle: r() * 6, phase: r() * 6, rad, size: species.size, spot: s, ex: createExpression(r), sink: 0, greeted: false, talk: false, timer: 8 + r() * 20 });
    }
  }
  const floats = (species?.altitude?.[1] ?? 0) > 0, walk = Math.min(1.2, Math.max(.5, (species?.speed?.walk ?? 1) * .6));
  const free = (x, z, rad) => Math.hypot(x, z) < (square ? R * .7 : R) - rad - .1 && solids.every((o) => Math.hypot(x - o.x, z - o.z) > o.r + rad * .8);
  function resolve(x0, z0, x1, z1, rad = .35) {
    const ok = (x, z) => free(x, z, rad) && crew.every((c) => Math.hypot(x - c.x, z - c.z) > c.rad + rad || Math.hypot(x0 - c.x, z0 - c.z) < Math.hypot(x - c.x, z - c.z));
    if (ok(x1, z1)) return [x1, z1]; if (ok(x1, z0)) return [x1, z0]; if (ok(x0, z1)) return [x0, z1]; return [x0, z0];
  }
  const m4 = new THREE.Matrix4(), q = new THREE.Quaternion(), q2 = new THREE.Quaternion(), e = new THREE.Euler(), p = new THREE.Vector3(), sc = new THREE.Vector3(), Y = new THREE.Vector3(0, 1, 0), rt = new THREE.Vector3(), fw = new THREE.Vector3();
  const angleTo = (a, b) => Math.atan2(Math.sin(b - a), Math.cos(b - a));
  const mood = moodOf(stance);
  function update(dt, t, player) {
    if (light) light.position.set(0, H * .78, 0).applyMatrix4(d.base);
    if (!mesh) return;
    for (const c of crew) {
      const pd = player ? Math.hypot(player.x - c.x, player.z - c.z) : Infinity;
      let target = null, face = c.spot?.face ?? c.heading, pose = c.spot?.kind === 'rest' ? 'rest' : 'work';
      if (c.talk && player) { target = null; face = Math.atan2(player.z - c.z, player.x - c.x); pose = 'stand'; }
      else if (player) {
        // How they take you coming in.
        const toward = (dist0) => { const dist = Math.max(dist0, c.rad + 1.1); const dx = c.x - player.x, dz = c.z - player.z, l = Math.max(.01, Math.hypot(dx, dz)); target = [player.x + dx / l * dist, player.z + dz / l * dist]; face = Math.atan2(player.z - c.z, player.x - c.x); pose = 'stand'; };
        if (stance === 'welcome') { toward(1.4 + c.rad + c.i * .8); if (pd < 2.5 + c.rad + c.i && !c.greeted) { c.greeted = true; startGesture(c.ex, gestureOf(species)); } }
        else if (stance === 'curious' && c.i === 0) toward(1.6 + c.rad);
        else if (stance === 'wary') { const a = Math.atan2(-player.z, -player.x); target = [Math.cos(a) * R * .55, Math.sin(a) * R * .55]; face = Math.atan2(player.z - c.z, player.x - c.x); pose = 'stand'; }
        else if (stance === 'guarded') { face = Math.atan2(player.z - c.z, player.x - c.x); pose = 'stand'; }
        else if (pd < 5) { face = Math.atan2(player.z - c.z, player.x - c.x); pose = 'stand'; }
      } else if ((c.timer -= dt) < 0) { // now and then, something else to do
        c.timer = 10 + r() * 25;
        const s = spots.find((x) => x.taken === -1);
        if (s) { c.spot.taken = -1; s.taken = c.i; c.spot = s; }
      }
      if (!target && !c.talk && c.spot && Math.hypot(c.spot.x - c.x, c.spot.z - c.z) > .4 && !player) target = [c.spot.x, c.spot.z];
      // Never on top of you: step back if you come too close.
      if (player && pd < c.rad + .7 && !target) { const a = Math.atan2(c.z - player.z, c.x - player.x); target = [c.x + Math.cos(a), c.z + Math.sin(a)]; }
      if (target && Math.hypot(target[0] - c.x, target[1] - c.z) > .3) {
        const h = Math.atan2(target[1] - c.z, target[0] - c.x); c.heading += angleTo(c.heading, h) * Math.min(1, dt * 5);
        c.speed += (walk - c.speed) * Math.min(1, dt * 3);
        const nx = c.x + Math.cos(c.heading) * c.speed * dt, nz = c.z + Math.sin(c.heading) * c.speed * dt;
        if (free(nx, nz, c.rad) && (!player || Math.hypot(nx - player.x, nz - player.z) > c.rad + .45)) { c.x = nx; c.z = nz; } else c.speed *= .4;
      } else { c.speed += (0 - c.speed) * Math.min(1, dt * 4); c.heading += angleTo(c.heading, face) * Math.min(1, dt * 2.5); }
      let amp;
      if (c.speed > .05) { c.cycle += c.speed * dt / mesh.stride * Math.PI; amp = floats ? 1 : Math.min(1, c.speed / walk); }
      else if (pose === 'work') { c.cycle += dt * 3.2; amp = -1; }
      else { amp = floats ? 1 : 0; if (floats) c.cycle += dt * 1.2; }
      c.sink += ((pose === 'rest' && c.speed < .05 ? c.size * .2 : 0) - c.sink) * Math.min(1, dt * 2);
      const headY = mesh.extent.top * .8, ch = Math.cos(c.heading), sh = Math.sin(c.heading);
      rt.set(sh, 0, -ch); fw.set(ch, 0, sh);
      const look = player && (pd < 7 || c.talk) ? lookAngles(player.x - c.x, EYE - headY, player.z - c.z, rt, Y, fw) : null;
      const ep = express(c.ex, dt, { look, mood: player && pd < 6 ? mood : null, t, phase: c.phase, sp: species, still: c.speed < .15 });
      if (ep.arms !== null && species.arms) { amp = ep.arms; c.cycle += dt * 2; }
      q.setFromAxisAngle(Y, Math.PI / 2 - c.heading);
      if (ep.pitch || ep.roll || ep.yaw) q.multiply(q2.setFromEuler(e.set(ep.pitch, ep.yaw, ep.roll, 'YXZ')));
      p.set(c.x, (floats ? .6 + Math.sin(t * .8 + c.phase) * .15 : -c.sink) + ep.lift, c.z);
      mesh.set(c.i, m4.compose(p, q, sc.set(1, ep.scale, 1)), c.cycle, amp, ep.headYaw, ep.headPitch, ep.glow);
    }
    mesh.commit();
  }
  return {
    group, radius: R, height: H, species, stance, square,
    door: { x: 0, z: dz }, start: { x: 0, z: dz - .8, yaw: -Math.PI / 2 },
    resolve, update,
    crew: () => crew.map((c) => ({ i: c.i, x: c.x, z: c.z, r: c.rad, top: mesh.extent.top })),
    talkWith(i) { for (const c of crew) c.talk = c.i === i; },
    gesture(i, kind) { const c = crew[i]; if (c) startGesture(c.ex, kind || gestureOf(species)); },
    dispose() {
      group.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
      for (const m of mats.values()) m.dispose();
      if (mesh) mesh.group.traverse((o) => { o.geometry?.dispose(); o.material?.dispose?.(); });
      group.removeFromParent();
    },
  };
}
