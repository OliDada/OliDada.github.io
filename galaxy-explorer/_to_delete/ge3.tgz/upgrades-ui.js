// The upgrade screen (U) and the tracked-upgrade readout on the HUD. Reads the tree
// and progress from upgrades.mjs and the codex from codex.mjs; game.js applies effects.
//
//   const ui = createUpgradeScreen({ codex, onUnlock(id), onOpen(), modalOpen() });
//   ui.open() · ui.close() · ui.toggle() · ui.refresh() · ui.isOpen
//
// One list per branch (tabs), so it reads the same on a phone as on a laptop.
import { BRANCHES, UPGRADES, progress, hint } from './upgrades.mjs';

const $ = (id) => document.getElementById(id);
// h('p', { class: 'x' }, 'text', child) -> element. Text is always set as text.
function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) if (c != null && c !== false) el.append(c instanceof Node ? c : String(c));
  return el;
}
const STATUS = {
  live: null,
  partial: (u) => `Partly built: ${u.built}.`,
  planned: () => 'Effect not built yet: it is on the roadmap.',
};
const spreadText = (n) => n.spread.map((s) => `${s.have} of ${s.need} ${s.label}`).join(' · ');

export function createUpgradeScreen({ codex, onUnlock, onOpen }) {
  // --- DOM: header button, dialog, HUD tracker ---------------------------------------
  const button = h('button', { id: 'upgradesBtn', class: 'map-open', title: 'Upgrades (U)', 'aria-label': 'Open upgrades' },
    '⬡ ', h('span', {}, 'UPGRADES'), h('i', { class: 'up-badge', hidden: true }));
  $('helpBtn').before(button);
  const tabs = h('div', { class: 'up-tabs', role: 'tablist' });
  const body = h('div', { class: 'up-body' });
  const summary = h('p', { class: 'up-summary' });
  const dialog = h('dialog', { id: 'upgrades', 'aria-label': 'Upgrades' },
    h('button', { class: 'close', 'aria-label': 'Close upgrades', onclick: () => dialog.close() }, '×'),
    h('div', { class: 'eyebrow' }, 'KESTREL / UPGRADES'),
    h('h2', {}, 'What you document builds the ship.'),
    summary, tabs, body);
  document.body.append(dialog);
  const tracker = h('div', { id: 'tracker', hidden: true });
  document.querySelector('.mission')?.append(tracker);

  let branch = 'starter', state = {};
  button.onclick = () => toggle();

  function card(p) {
    const u = p.upgrade, locked = !p.available && !p.unlocked;
    const missing = u.after.filter((id) => !codex.unlocked.has(id)).map((id) => UPGRADES[id].name);
    const tag = p.unlocked ? 'UNLOCKED' : p.ready ? 'READY' : locked ? `NEEDS ${missing.join(' + ').toUpperCase()}` : `${p.needs.filter((n) => n.done).length} / ${p.needs.length}`;
    const status = STATUS[u.status]?.(u);
    const tracked = codex.tracked === u.id;
    return h('article', { class: `up-node${p.unlocked ? ' unlocked' : ''}${p.ready ? ' ready' : ''}${locked ? ' locked' : ''}`, 'data-id': u.id },
      h('div', { class: 'up-head' }, h('h3', {}, u.name), h('span', { class: 'up-tag' }, tag)),
      h('p', { class: 'up-effect' }, u.effect),
      status && h('p', { class: 'up-status' }, status),
      !p.unlocked && h('ul', { class: 'up-needs' }, p.needs.map((n, i) => h('li', { class: n.done ? 'done' : '' },
        h('span', { class: 'up-check', 'aria-hidden': 'true' }, n.done ? '✓' : ''),
        h('span', { class: 'up-label' }, n.label,
          n.spread.length ? h('small', {}, spreadText(n)) : null,
          !n.done ? h('small', { class: 'up-hint' }, n.notYet ? `Not in the game yet: arrives with ${n.notYet}.` : hint(u.needs[i])) : null),
        h('b', {}, `${n.have} / ${n.count}`)))),
      !p.unlocked && h('div', { class: 'up-actions' },
        p.ready && h('button', { class: 'primary', onclick: () => unlock(u.id) }, `Unlock ${u.name}`),
        !p.ready && h('button', { class: 'secondary', 'aria-pressed': tracked ? 'true' : 'false', onclick: () => { codex.track(u.id); refresh(); } },
          tracked ? 'Tracking ✓' : 'Track on HUD')));
  }

  function render() {
    const readyIn = new Set(Object.values(state).filter((p) => p.ready).map((p) => p.upgrade.branch));
    tabs.replaceChildren(...BRANCHES.map((b) => h('button', {
      role: 'tab', 'aria-selected': b.id === branch ? 'true' : 'false', class: readyIn.has(b.id) ? 'has-ready' : '',
      onclick: () => { branch = b.id; render(); },
    }, b.name)));
    const b = BRANCHES.find((x) => x.id === branch);
    const nodes = Object.values(state).filter((p) => p.upgrade.branch === branch)
      .sort((x, y) => (y.ready - x.ready) || (x.unlocked - y.unlocked) || (y.available - x.available));
    body.replaceChildren(h('p', { class: 'up-blurb' }, b.blurb), ...nodes.map(card));
    const n = codex.entries.filter((e) => e.kind !== 'world' && e.kind !== 'signal').length;
    summary.textContent = `${n} thing${n === 1 ? '' : 's'} documented · ${codex.unlocked.size} of ${Object.keys(UPGRADES).length} upgrades unlocked. Every requirement asks about traits, never a particular species.`;
  }

  function renderTracker() {
    const p = state[codex.tracked];
    tracker.hidden = !p || p.unlocked;
    if (tracker.hidden) return;
    const open = p.needs.filter((n) => !n.done);
    tracker.replaceChildren(
      h('strong', {}, p.ready ? `◆ ${p.upgrade.name}: ready (U)` : `◆ ${p.upgrade.name}`),
      ...(p.ready ? [] : open.map((n) => h('span', {}, `${n.have}/${n.count} ${n.label}${n.spread.length && n.have >= n.count ? ` (${spreadText(n)})` : ''}`))));
  }

  function refresh() {
    state = progress(codex.entries, codex.unlocked);
    const ready = Object.values(state).filter((p) => p.ready).length;
    const badge = button.querySelector('.up-badge');
    badge.hidden = !ready;
    badge.textContent = ready || '';
    button.classList.toggle('has-ready', ready > 0);
    renderTracker();
    if (dialog.open) render();
  }

  function unlock(id) {
    if (!state[id]?.ready) return;
    codex.unlock(id);
    refresh();
    onUnlock?.(id);
  }

  function open() {
    onOpen?.();
    state = progress(codex.entries, codex.unlocked);
    const ready = Object.values(state).find((p) => p.ready);
    branch = ready?.upgrade.branch || state[codex.tracked]?.upgrade.branch || branch;
    render();
    dialog.showModal();
    body.scrollTop = 0;
  }
  const close = () => dialog.close();
  const toggle = () => (dialog.open ? close() : open());

  refresh();
  return { open, close, toggle, refresh, get isOpen() { return dialog.open; } };
}
