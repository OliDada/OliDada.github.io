// Civilizations as things in their own right. A civilization is a species that has
// climbed the ladder, with a home world and a reach. Everything that shows or uses
// one (settlements, radio signals, the star map, and later contact and trade)
// reads it from here, so new kinds can be added without reworking the rest.
//
//   id      stable: `${worldSeed}:${worldId}:${speciesId}`
//   tier    a name from TIERS, never an index: saves store names, so the ladder can
//           grow (a new step between two others, or above spacefarers) without
//           changing what old saves mean
//   reach   how far it extends: 'local' (tool users to city builders), 'world'
//           (planet-shapers), 'orbit' (spacefarers). Future kinds extend this list:
//           'system' (a whole solar system), 'interstellar', and civilizations that
//           live only in space would have reach but no home settlement.
import { faunaFor, CIVILIZATION } from './fauna.mjs';
import { civilizationFor } from './structures.mjs';

export const TIERS = CIVILIZATION.slice(1); // 'tool users' … 'spacefarers'
export const REACH = ['local', 'world', 'orbit']; // future: 'system', 'interstellar'
const reachOf = (tier) => tier === 'spacefarers' ? 'orbit' : tier === 'planet-shapers' ? 'world' : 'local';

// tierAtLeast('city builders', 'village builders') -> true. Unknown names count as none.
export const tierAtLeast = (tier, min) => TIERS.includes(tier) && TIERS.indexOf(tier) >= TIERS.indexOf(min);
// Older saves stored the level number from a shorter ladder; read them as names.
export const tierName = (saved) => typeof saved === 'string' ? saved : ({ 1: 'tool users', 2: 'village builders', 3: 'spacefarers' })[saved] || null;

const cache = new Map();
export function civilizationOf(body) {
  const key = `${body.seed}:${body.id}`;
  if (cache.has(key)) return cache.get(key);
  let civ = null;
  if (body.physics?.life === 'complex') {
    const c = civilizationFor(body, faunaFor(body).species);
    if (c) { const tier = CIVILIZATION[c.level]; civ = { ...c, id: `${body.seed}:${body.id}:${c.species.id}`, home: body.id, tier, reach: reachOf(tier) }; }
  }
  if (cache.size > 2000) cache.clear();
  cache.set(key, civ);
  return civ;
}
export const civilizationsIn = (system) => system.bodies.map(civilizationOf).filter(Boolean);
