# Progression: knowledge and contact

Status: **plan**. Nothing in this file is built yet unless it is ticked. Tick items off as they land.

## Identity

**Elsewhere is about being a naturalist in an alien galaxy.** You go places, look closely, and come to understand what lives there. **Knowledge** and **relationships** are the only currencies:

- What you **document** (plants, animals, formations, settlements, signals) becomes the knowledge your ship is built from. Each upgrade opens a new kind of place.
- What you **learn about minds** lets you reach intelligent species, earn their trust and trade knowledge with them.

**What it is not:** no combat, no mining, no inventory, no crafting, no base building. They would turn the ecosystem into targets and resources, pull the game toward a survival grind, and cost a lot on phones.

**Danger is not combat.** Big hunters stalk you on foot, the suit can fail, star heat burns and night falls. Tension comes from the world, and the answer is always to move, retreat to the ship or come back better equipped. There is never a weapon.

## Design rules

1. **Everything is open from the start.** Every rocky world you can land on today stays landable. Upgrades only open places nobody can reach yet: underwater, under ice, inside giants, farther stars. Gating takes away freedom and reads as a punishment.
2. **An upgrade opens a door.** "+10% scan range" is filler; most nodes should let you go somewhere or do something you could not before.
3. **The first unlock comes within ten minutes.** Starter nodes can be finished on the first world you land on.
4. **Every landing pays.** Even a lifeless moon has formations to record, so no world is empty.
5. **Variety, not volume.** Ask for "3 different body plans", not "30 animals". Counts stay small (1–5).
6. **Requirements are questions about traits, never named species.** See below.
7. **Names, never numbers**, in saves and requirements (see Data model).

## The core loop

```mermaid
flowchart LR
    A[Explore a world] --> B[Document plants, animals,<br/>formations, settlements, signals]
    B --> C[Codex grows]
    C --> D[Unlock an upgrade]
    C --> F[Understand a species]
    F --> G[Contact, trust, trade]
    G --> H[Charts, signals, ship tech]
    D --> E[Reach a new kind of world<br/>or travel farther]
    H --> E
    E --> A
```

## The key rule: requirements match traits, not named species

Every species is generated, so a requirement can never say "scan the Glowing Reef Eel". Requirements are **questions about traits the generator already produces**, such as:

- "Observe 3 animals from worlds with liquid seas"
- "Catalogue a glowing plant"
- "Observe a carnivore and the herbivore it hunts"
- "Record 2 kinds of volcanic formation"
- "Record a settlement of village builders or higher"

This gives two benefits:

1. **Hints come for free.** A requirement for "a drifter" can say *Found on: thick-air or low-gravity worlds with complex life*, because that is what `PLANS.floater.fit` favours. The hint text is generated from the requirement, not written by hand.
2. **New generator traits automatically become new requirements.** Anything added to `flora.mjs`, `fauna.mjs`, `geology.mjs` or `civilizations.mjs` can be used in the tree.

### Traits available today

| Source | Field | Values |
|---|---|---|
| World (`biomes.mjs` `classify`) | biome | Volcanic, Toxic, Desert, Verdant, Oceanic, Frozen, Amethyst, Barren |
| World (`body.physics`) | life | none, microbial, simple, complex |
| World | biochemistry | water, ammonia, methane, sulfur, silicon |
| World | waterState, subsurfaceOcean, tidallyLocked | liquid / ice / …, true/false |
| World | gravity, pressure, temperature, volcanism | numbers |
| Giant (`GIANT_CLOUDS`) | cloud type, rings | ammonia, methane, water, clear, alkali, silicate; ringed or not |
| Star (`physics.mjs`) | spectral class | O … M (half are red dwarfs) |
| Plant (`flora.mjs` `FORMS`) | form | tree, conifer, palm, shrub, grass, succulent, fungus, stalk, mat, mound; exotic: crystal, glasstree, chimney, plume, bulb, sheet, filament, crust |
| Plant | glow, habitat | 0–1; temperature / moisture / shore / highland preference |
| Formation (`geology.mjs`) | kind | basalt columns, obsidian shards, fumaroles, hoodoos, rock arches, penitentes, pingos, cryovolcanoes, crystal spires, mineral terraces, sulfur chimneys, karst pinnacles, sea stacks, impact boulders, banded outcrops; rare: geodes, iron meteorites |
| Animal (`fauna.mjs` `PLANS`) | body plan | quadruped, hexapod, biped, serpent, flyer, floater, arachnid, slug, radial, roller |
| Animal | form | runner, tank, raptor, mantis, spider, eel, bat, bell, manta, tripod, wheel, … |
| Animal | diet | herbivore, omnivore, carnivore, filter |
| Animal (`ecology.mjs`) | activity, stalksYou | diurnal, nocturnal, crepuscular, any; dangerous to explorers or not |
| Animal | mind, manipulators | instinctive, simple, cunning, clever; tool users … spacefarers; hands, tentacles, mandibles, … |
| Civilization (`civilizations.mjs`) | tier, reach, family, culture | tool users … spacefarers; local, world, orbit; hands, hive, drifters, …; timber, hive, tethered, silk, … |
| Settlement (`traces`) | tier | the tier you recorded (a name) |
| Radio signal (`signals.mjs`) | tier | planet-shapers, spacefarers |

### Things to scan

| Category | Today | Later |
|---|---|---|
| **Flora** | ✅ catalogued by walking close (`catalogue`) | partial scans, rare variants |
| **Fauna** | ✅ observed from a distance (`bestiary`) | behaviour observations (hunting, sleeping, drinking) |
| **Formations** | ✅ recorded by walking up to one (`geology`); 2–4 kinds on every world with a surface | rare variants, samples from deep formations |
| **Settlements** | ✅ recorded within ~45 m (`traces`) | scanning individual building cultures |
| **Signals / field notes** | ✅ investigated on foot (`records`) | the Senders' trail (see Mystery) |
| **Radio sources** | ✅ heard on the star map up to 150 ly (`signals.mjs`) | decoding them (Contact) |
| **Worlds from orbit** | partly (long-range biosignature scan on the map) | an orbital survey that records a world's biome, chemistry and life |
| **Giant atmospheres** | ❌ | cloud samples with an atmospheric probe |
| **Space structures** | ❌ | stations, satellites, megastructures, derelicts (see Future-proofing) |

## Starter nodes: the first ten minutes

All three can be finished on the first world you land on, whatever it is: every world has formations, and most starting worlds have life.

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Field scanner** | Recorded things show a marker; the HUD counts what is left on this world | Record 2 kinds of formation | Needs building (small) |
| **Suit plating** | Suit takes 30% less damage and recovers twice as fast | Record 3 things of any kind on one world | Easy: `suit` in `game.js` |
| **Orbital survey** | See a world's biome, chemistry and life before landing; map filter for a tracked requirement | Record 5 things across 2 worlds | Partly: the map's long-range scan shows life at jump-range stars |

## The upgrade tree

Five branches. Each node lists what it does, what it needs, and whether the ability exists in the game yet. **"Needs building"** means the upgrade's effect is itself a to-do item (see the roadmap below). Counts are a first guess and should be tuned with `inspect.mjs --stats`.

The ship is the **Kestrel**. Requirements are cumulative across every system you have visited.

### Environment: new places to set down

Nothing that is landable today becomes locked.

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Heat plating** | Land right beside lava; star exclusion zone shrinks | 2 plants from Volcanic or Desert worlds · 1 volcanic formation (columns, obsidian, fumaroles) | Partly: star heat exists, lava landing is blocked today |
| **Pressure hull I** | Dive into liquid seas (shallows) | 3 animals from worlds with liquid water · 1 coil or creeper (serpent / slug) · 1 sea stack or shoreline plant | Needs building |
| **Pressure hull II** | Deep dives; reach subsurface oceans under ice | Pressure hull I · 1 drifter (floater) · 1 pingo or cryovolcano | Needs building |
| **Cryo seals** | Dive into methane and ammonia seas | Pressure hull I · 1 species from a methane world · 1 from an ammonia world | Needs building |
| **Cloud diver** | Descend below 250 m into gas giants | Pressure hull II · scan 3 giants with different cloud types · 2 drifters | Needs building |

### Propulsion: how far you can go

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Jump drive II** | Jump range 12 → 16 ly | 5 plant species from 3 different biomes | Easy: `JUMP_RANGE` in `galaxy.mjs` becomes a function of upgrades |
| **Jump drive III** | Jump range → 24 ly | Jump drive II · 10 animals across 4 body plans | Easy |
| **Return beacons** | Fast-travel to any system you have **fully documented** | Fully document every plant, animal and formation on 1 world | Needs building |
| **Signal drive** | Jump straight to any radio source you can hear (up to 150 ly) | Jump drive III · record a city-builder settlement | Needs building (signals already exist) |

Return beacons reward finishing a system instead of skimming it, and keep backtracking from becoming a chore.

### Scanner: how you find things

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Life sonar** | HUD arrow to the nearest uncatalogued species | 5 animals including 1 nocturnal | Needs building |
| **Night filter** | See clearly at night; glowing species are highlighted | 2 glowing species (plant `glow` > 0.45 or animal glow markings) | Needs building |
| **Behaviour logger** | Unlocks behaviour observations: watch a hunt, a herd drinking, an animal sleeping | 1 carnivore and 1 herbivore it hunts (`ecology.mjs` food web) | Needs building (the behaviours exist) |
| **Deep core sampler** | Formations give a second, deeper entry (age, origin) | 6 kinds of formation | Needs building |

### Tools: new ways to explore a world

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Rover** | Fast surface travel without taking off; a refuge on wheels from stalkers | 4 animals with legs from 2 biomes | Needs building |
| **Survey drone** | Scan from a distance: cliffs, skittish herds, high nests, stalkers you would rather not approach | 2 fliers (flyer plan) | Needs building |
| **Atmospheric probe** | Scan giant cloud layers from orbit | 1 drifter · visit 1 giant | Needs building |
| **Decoy beacon** | Distracts a stalker for a while (no weapon, ever) | Observe 2 species that stalk explorers | Needs building |

### Contact: knowing minds

See the next section. These nodes unlock understanding, not abilities.

| Node | Effect | Requires | Effect exists? |
|---|---|---|---|
| **Xenolinguistics** | Settlements give longer field notes; you can attempt contact with tool users and village builders | Record tool users and village builders | Needs building |
| **Signal decoder** | Radio sources on the map say who they are and what they want | Xenolinguistics · hear 3 radio sources | Needs building |
| **Diplomatic protocols** | Attempt contact with city builders and above | Signal decoder · reach Trust with 1 civilization | Needs building |

## Contact: intelligent species

Intelligent species are not scenery. Each civilization (`civilizations.mjs`) can be understood, met and befriended, and **what you trade is knowledge**.

### Disposition comes from traits

A civilization's starting attitude to you comes from its species' traits, so it needs no hand-written factions:

| Traits | Disposition |
|---|---|
| high sociality, low caution | **welcoming**: comes to meet you |
| high caution | **wary**: watches from a distance, needs patience (staying near, not intruding) |
| high aggression, low sociality | **guarded**: warns you off its settlements; never attacks, but contact is slow |
| spacefarers | **curious**: they already know you are there |

### The relationship ladder

1. **Observed**: you have recorded the species and a settlement.
2. **Understood**: you have documented enough of their world (species, buildings, formations they use) for Xenolinguistics to make sense of their signs.
3. **Contact**: a greeting exchange: symbols and gestures, not a dialogue tree. The species approaches instead of fleeing.
4. **Trust**: built by returning, by sharing knowledge they value, and by not intruding.
5. **Friendship**: they treat you as one of their own. They point you to their other homes and to other civilizations they have heard, and spacefarers offer what only they can.

### Trade is knowledge for knowledge

Your codex is what you have to offer: species and places they have never seen. What they offer depends on their tier:

| Tier | They can give |
|---|---|
| tool users | where the local animals, water and formations are (HUD hints on their world) |
| village builders | maps of their world; which worlds in the system hold life |
| city builders | star charts for their region: reveal systems and biosignatures beyond jump range |
| planet-shapers | ship knowledge: an upgrade's requirements partly satisfied |
| spacefarers | drive technology and, at Friendship, the way to the **Albatross** |

### Choices with consequences (later)

Not everything has to be friendly. **Taking** something (for example a spacefarer's ship) is possible later, but it is a choice with weight: that civilization turns guarded for good, its signals go dark to you, and civilizations within its radio reach hear about it. There is no fighting, only consequences.

## Mystery: the Senders

The field-note signals on worlds (`body.signal`, `records`) become a thread that gives the early game a direction:

- The signals were left by an old spacefaring civilization, **the Senders**, that is long gone or gone quiet.
- Each field note gives a fragment of their story and a **bearing**: a direction and rough distance on the star map toward the next signal.
- The trail leads from the home star, through regions with the richest life, toward a real spacefaring civilization (picked deterministically from the fixed galaxy), where the last fragment can only be read with Contact.
- It is optional. It gives you a reason to travel in a direction, never a requirement for progress.

## Danger without combat

| Hazard | Today | Later |
|---|---|---|
| **Stalkers** | ✅ big aggressive carnivores (never intelligent ones) stalk you on foot, charge and lunge; about 1 world in 8 with animals has one; nocturnal stalkers make nights dangerous | they track your scent; packs |
| **Suit integrity** | ✅ a lunge takes 16–45% and knocks you back; recovers after 6 s left alone; at 0 the emergency recall puts you back beside the Kestrel; the ship is always safe | Suit plating (starter node) |
| **Star heat** | ✅ hull heats near the star's exclusion zone | Heat plating |
| **Weather** | ❌ | dust storms, methane rain, blizzards that hide the ship marker |
| **Ground** | ❌ | thin ice, geysers and fumaroles that erupt |
| **Cold and heat on foot** | ❌ | a time limit on extreme worlds without suit upgrades |

Failure is never a loss of progress: at worst you are recalled to the ship.

## Future-proofing

New kinds of civilization or place should be additions, not rewrites. This plan assumes:

- **Civilizations are entities** (`civilizations.mjs`): `{ id, tier, reach, family, culture, home, species }`. Today `reach` is `local`, `world` or `orbit`. Later kinds extend it:
  - **system-spanning**: settled several worlds and moons of one system. The entity gets a list of homes; settlements are built on each, and radio is heard from farther away.
  - **space-living**: no surface settlement at all. Habitats in orbit or between worlds become a new codex kind (`station`); contact happens in space.
  - **interstellar**: several systems. One entity, several homes across stars; its radio sources share an id.
- **The ladder grows by name.** A new step (between two others, or above spacefarers) is added to `CIVILIZATION`. Saves and requirements use names, so nothing old changes meaning. `tierAtLeast` keeps working.
- **New codex kinds** (station, megastructure, derelict, behaviour) need a scanner and an entry shape. Requirements can ask for them immediately.
- **Ship classes are data.** A fourth class after Albatross is a new row, not a new system.

## Ship classes: the big milestones

Upgrades are modules on a hull. A **new ship class** is a chapter break: more module slots, a new model in `kestrel.js`, and a bigger documentation milestone.

| Class | Requires | Opens |
|---|---|---|
| **Kestrel** (start) | — | today's game |
| **Petrel** (sea and storm ship) | 6 upgrades · fully documented 3 worlds in 3 biomes | Pressure hull II, Cloud diver, Signal drive |
| **Albatross** (deep-range ship) | 12 upgrades · **Friendship with a spacefaring civilization** · species from 3 biochemistries | the last tier: long jumps toward the core |

## Showing a node to the player

```
PRESSURE HULL I                                  ENVIRONMENT
Dive into liquid seas, down to the shallows.

  ☐ 3 animals from worlds with liquid water      2 / 3
      Found on: Oceanic and Verdant worlds
  ☑ 1 coil or creeper                            1 / 1
  ☐ 1 shoreline plant                            0 / 1
      Found on: coasts of worlds with seas
```

- On phones, use one list per branch (tabs), the same bottom-sheet pattern as the star map panel. Avoid a big pannable graph.
- **Track** a node to pin it on the HUD and highlight matching worlds on the map once Orbital survey is unlocked.
- When a scan counts toward something, the existing toast should say so: "New animal observed … counts toward Pressure hull I (2 / 3)".

## Data model (proposal)

A new module, `upgrades.mjs`, plain data with no Three.js, so it can be tested with `node --test` like the generators.

```js
export const UPGRADES = {
  pressureHull1: {
    branch: 'environment',
    name: 'Pressure hull I',
    effect: 'Dive into liquid seas, down to the shallows.',
    after: [],                         // prerequisite upgrades
    needs: [
      { kind: 'fauna', count: 3, world: { waterState: 'liquid' } },
      { kind: 'fauna', count: 1, species: { plan: ['serpent', 'slug'] } },
      { kind: 'flora', count: 1, species: { habitat: { shore: true } } },
    ],
  },
  // …
};

// progress(codex) -> { [upgradeId]: { met: [2, 1, 0], done: false } }
// hint(need)      -> "Found on: Oceanic and Verdant worlds"  (generated from the query)
```

The **codex** is a new save that holds one entry per scanned thing, with the traits copied in at scan time: `{ kind, seed, bodyId, id, traits: { plan, diet, … }, world: { biome, gravity, … } }`. Copying the traits means requirements can be checked without regenerating old systems.

**Names, never numbers.** Everything saved or matched is a name: `tier: 'city builders'`, `plan: 'floater'`, `formation: 'geo-columns'`. Indices change meaning when a list grows. (This already happened once: settlement records stored the level number from a 3-step ladder, which meant something else after the ladder grew to 5. Saves now store tier names, and `tierName()` in `civilizations.mjs` reads the old numbers.) Requirements compare tiers with `tierAtLeast(tier, 'planet-shapers')`, never `level >= 4`.

Codex `kind` is open-ended: `flora`, `fauna`, `formation`, `settlement`, `signal`, `field-note`, `world`, and later `station`, `megastructure`, `derelict`, `behaviour`, `contact`. A new kind needs a scanner and an entry shape, not a new system.

## Reachability

A player must never get stuck because nothing nearby matches the next requirement. The galaxy is fixed (`GALAXY_SEED`), so check it instead of patching it:

- A test walks outward from the starting star and asserts that every tier-1 requirement is met within a few jumps, and every requirement somewhere within the range the earlier tiers unlock.
- `inspect.mjs --stats` reports how common each requirement's match is, so counts can be tuned (for example, if drifters are 1 world in 40, don't ask for 3 early).
- If a requirement is too rare, change the requirement, not the galaxy.

- The Senders' trail and the starter nodes are covered by the same test: the trail's first steps and every starter node must be reachable from the home star.

## Roadmap / to-do

### Phase 0: already in the game
- [x] Catalogue plants by walking close
- [x] Observe animals from a distance
- [x] Record rock and ice formations on every world with a surface (`geology.mjs`)
- [x] Record settlements; saved as tier names
- [x] Civilizations as entities with tier and reach (`civilizations.mjs`)
- [x] Investigate surface signals (field notes)
- [x] Long-range biosignature scan on the star map
- [x] Radio signals from planet-shapers and spacefarers, up to 150 ly
- [x] Danger without combat: stalkers, suit integrity, emergency recall

### Phase 1: the system itself
- [ ] Global **codex** save across systems, with traits copied in at scan time (today saves are per system: `elsewhere-system-<seed>`)
- [ ] Backfill the codex from existing per-system saves (reading old settlement levels with `tierName`)
- [ ] `upgrades.mjs`: the tree as data, `progress()`, and generated "Found on" hints
- [ ] `upgrades.test.mjs`: matching, prerequisites, hints
- [ ] Reachability test (starter nodes on the first world; tier 1 within a few jumps) and requirement frequencies in `inspect.mjs --stats`
- [ ] Upgrade screen (desktop + phone layout); open with a key and a HUD button
- [ ] Toasts say which upgrade a new scan counts toward
- [ ] Track a node and pin it on the HUD
- [ ] Save unlocked upgrades

### Phase 2: starter nodes and number or gate upgrades
- [ ] Field scanner, Suit plating, Orbital survey
- [ ] Jump drive II / III (`JUMP_RANGE` reads unlocked upgrades)
- [ ] Heat plating: smaller star exclusion zone; allow landing beside lava

### Phase 3: new places and tools
- [ ] **Underwater**: ship below the sea surface, underwater fog and light, sea floor collision, depth limit per hull level (Pressure hull I / II)
- [ ] Aquatic life to find down there (new plant forms and swimming animals in `flora.mjs` / `fauna.mjs`)
- [ ] Subsurface oceans under ice (Pressure hull II)
- [ ] Methane and ammonia seas (Cryo seals)
- [ ] Gas giant descent below 250 m (Cloud diver)
- [ ] Return beacons (fast travel to fully documented systems)
- [ ] Signal drive (jump to a radio source)
- [ ] Life sonar, Night filter, Decoy beacon
- [ ] Rover, Survey drone, Atmospheric probe

### Phase 4: contact
- [ ] Disposition from traits; relationship ladder saved per civilization id
- [ ] Contact exchange (symbols and gestures) with tool users and village builders
- [ ] Trade screen: offer codex entries, receive charts, hints and ship knowledge
- [ ] Signal decoder: radio sources say who they are
- [ ] Spacefarer friendship and the Albatross
- [ ] Consequences: taking things, signals going dark, word spreading

### Phase 5: the Senders
- [ ] Deterministic trail from the home star toward a spacefaring civilization
- [ ] Field notes with fragments and bearings; map markers for bearings
- [ ] The last fragment, read through Contact

### Phase 6: deeper scanning and danger
- [ ] Behaviour observations (hunt, graze, drink, sleep), using what `ecology.mjs` already does
- [ ] Partial scans: several individuals to finish an entry
- [ ] Rare variants (albino, giant) worth bonus progress
- [ ] Weather and unstable ground
- [ ] Name species you were first to document

### Phase 7: ship classes
- [ ] Module slots per hull
- [ ] Petrel and Albatross models and handling in `kestrel.js`
- [ ] Class milestones in the upgrade screen

## Decided

- **Start open.** Nothing landable today is locked. Upgrades open new places only.
- **No combat, mining, inventory, crafting or base building.** Danger comes from the world; the answer is to move, retreat or come back better equipped.
- **Counts stay small (1–5).** Variety is the challenge, not volume.
- **Names, never numbers** in saves and requirements.

## Open questions

- **Contact presentation:** a symbol exchange you assemble from what you have documented, or simpler gestures? It must work with touch.
- **Can a relationship sour on its own** (for example if you neglect a civilization), or only through your choices?
- **Where does the codex live?** Probably `localStorage` next to `elsewhere-galaxy-v1`; it should survive generating a new test seed.
- **Ship names:** Kestrel → Petrel → Albatross are placeholders.
