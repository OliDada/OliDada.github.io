// The upgrade tree (PROGRESSION.md): what you document becomes the knowledge your
// ship is built from. Plain data plus the code that checks it against the codex
// (codex.mjs), so it can be tested with node --test and read by the game and the UI.
//
// A requirement ("need") is a question about traits, never a named species:
//   { label, count = 1,
//     kind:     'flora' | 'fauna' | 'formation' | 'settlement' | 'field-note' | 'world' | 'signal' | [...] | 'any',
//     world:    { biome: [...], waterState: 'liquid', giant: true, gravity: { min: 1.3 }, … },
//     traits:   { plan: [...], glow: { min: .45 }, habitat: { shore: true }, tier: { atLeast: 'city builders' }, … },
//     anyOf:    [query, query]      matches if any query matches (instead of kind/world/traits)
//     distinct: 'traits.formation'  count different values instead of entries
//     spread:   { 'world.biome': 3 } and the matches must cover this many different values
//     sameWorld: true               all on one world
//     special:  'hunt' | 'complete' | 'upgrades' | 'relationship' }
// A value in a query is a name, a list of names (any of them), { min, max } or { atLeast: tier }.
// Hints ("Found on: …") are generated from the query, never written per upgrade.
import { DOCUMENTED } from './codex.mjs';
import { tierAtLeast } from './civilizations.mjs';
import { JUMP_RANGE } from './galaxy.mjs';

export const BRANCHES = [
  { id: 'starter', name: 'First steps', blurb: 'Can be finished on the first world you land on.' },
  { id: 'environment', name: 'Environment', blurb: 'New places to set down. Nothing you can land on today is ever locked.' },
  { id: 'propulsion', name: 'Propulsion', blurb: 'How far you can go.' },
  { id: 'scanner', name: 'Scanner', blurb: 'How you find things.' },
  { id: 'tools', name: 'Tools', blurb: 'New ways to explore a world.' },
  { id: 'contact', name: 'Contact', blurb: 'Knowing minds. These unlock understanding, not abilities.' },
  { id: 'ship', name: 'Ship class', blurb: 'The big milestones: a new hull with room for more.' },
];

// status: what unlocking does in the game today.
//   'live'    the effect works
//   'partial' part of the effect works (`built` says which part)
//   'planned' the effect is still a to-do item (PROGRESSION.md roadmap)
const FORMATION = (formation) => ({ kind: 'formation', traits: { formation } });
const DRIFTER = { kind: 'fauna', traits: { plan: 'floater' } };
export const UPGRADES = {
  // --- First steps ---------------------------------------------------------------
  fieldScanner: {
    branch: 'starter', name: 'Field scanner', status: 'partial',
    effect: 'The HUD counts what is left to record on the world you are on.',
    built: 'the HUD count works; markers on recorded things come later',
    needs: [{ label: '2 kinds of formation', kind: 'formation', distinct: 'traits.formation', count: 2 }],
  },
  suitPlating: {
    branch: 'starter', name: 'Suit plating', status: 'live',
    effect: 'Your suit takes 30% less damage and recovers twice as fast.',
    needs: [{ label: '3 things recorded on one world', kind: 'any', sameWorld: true, count: 3 }],
  },
  orbitalSurvey: {
    branch: 'starter', name: 'Orbital survey', status: 'partial',
    effect: "See a world's biome, chemistry and life before landing, and filter the map by what you are tracking.",
    built: 'the long-range scan already shows life at stars in jump range',
    needs: [{ label: '5 things recorded, on 2 worlds', kind: 'any', count: 5, spread: { world: 2 } }],
  },
  // --- Environment -----------------------------------------------------------------
  heatPlating: {
    branch: 'environment', name: 'Heat plating', status: 'partial',
    effect: 'The hull heats up more slowly near stars, and you can land right beside lava.',
    built: 'slower hull heating works; landing beside lava comes later',
    needs: [
      { label: '2 plants from Volcanic or Desert worlds', kind: 'flora', world: { biome: ['Volcanic', 'Desert'] }, count: 2 },
      { label: 'A volcanic formation (basalt columns, obsidian or fumaroles)', ...FORMATION(['columns', 'obsidian', 'fumaroles']) },
    ],
  },
  pressureHull1: {
    branch: 'environment', name: 'Pressure hull I', status: 'planned',
    effect: 'Dive into liquid seas, down to the shallows.',
    needs: [
      { label: '3 animals from worlds with liquid water', kind: 'fauna', world: { waterState: 'liquid' }, count: 3 },
      { label: 'A coil or a creeper', kind: 'fauna', traits: { plan: ['serpent', 'slug'] } },
      { label: 'Sea stacks or a shoreline plant', anyOf: [FORMATION('seastacks'), { kind: 'flora', traits: { habitat: { shore: true } } }] },
    ],
  },
  pressureHull2: {
    branch: 'environment', name: 'Pressure hull II', status: 'planned', after: ['pressureHull1', 'petrel'],
    effect: 'Deep dives, and the oceans hidden under the ice of frozen moons.',
    needs: [
      { label: 'A drifter', ...DRIFTER },
      { label: 'Pingos or a cryovolcano', ...FORMATION(['pingo', 'cryovolcano']) },
    ],
  },
  cryoSeals: {
    branch: 'environment', name: 'Cryo seals', status: 'planned', after: ['pressureHull1'],
    effect: 'Dive into seas of liquid methane and ammonia.',
    needs: [
      { label: 'A species from a methane world', kind: ['flora', 'fauna'], world: { biochemistry: 'methane' } },
      { label: 'A species from an ammonia world', kind: ['flora', 'fauna'], world: { biochemistry: 'ammonia' } },
    ],
  },
  cloudDiver: {
    branch: 'environment', name: 'Cloud diver', status: 'planned', after: ['pressureHull2', 'petrel'],
    effect: 'Descend below 250 m into the clouds of gas and ice giants.',
    needs: [
      { label: 'Visit 3 giants with different clouds', kind: 'world', world: { giant: true }, distinct: 'world.clouds', count: 3 },
      { label: '2 drifters', ...DRIFTER, count: 2 },
    ],
  },
  // --- Propulsion ------------------------------------------------------------------
  jumpDrive2: {
    branch: 'propulsion', name: 'Jump drive II', status: 'live',
    effect: 'Jump range 12 → 16 light years.',
    needs: [{ label: '5 plant species from 3 biomes', kind: 'flora', count: 5, spread: { 'world.biome': 3 } }],
  },
  jumpDrive3: {
    branch: 'propulsion', name: 'Jump drive III', status: 'live', after: ['jumpDrive2'],
    effect: 'Jump range 16 → 24 light years.',
    needs: [{ label: '10 animals across 4 body plans', kind: 'fauna', count: 10, spread: { 'traits.plan': 4 } }],
  },
  returnBeacons: {
    branch: 'propulsion', name: 'Return beacons', status: 'planned',
    effect: 'Fast-travel to any system you have fully documented.',
    needs: [{ label: 'Fully document a world: every plant, animal and formation', special: 'complete' }],
  },
  signalDrive: {
    branch: 'propulsion', name: 'Signal drive', status: 'planned', after: ['jumpDrive3', 'petrel'],
    effect: 'Jump straight to any radio source you can hear, up to 150 light years.',
    needs: [{ label: 'A settlement of city builders or higher', kind: 'settlement', traits: { tier: { atLeast: 'city builders' } } }],
  },
  // --- Scanner ---------------------------------------------------------------------
  lifeSonar: {
    branch: 'scanner', name: 'Life sonar', status: 'planned',
    effect: 'A HUD arrow points to the nearest species you have not recorded.',
    needs: [
      { label: '5 animals', kind: 'fauna', count: 5 },
      { label: 'A nocturnal animal', kind: 'fauna', traits: { activity: 'nocturnal' } },
    ],
  },
  nightFilter: {
    branch: 'scanner', name: 'Night filter', status: 'planned',
    effect: 'See clearly at night; glowing species stand out.',
    needs: [{ label: '2 glowing species', kind: ['flora', 'fauna'], traits: { glow: { min: 0.45 } }, count: 2 }],
  },
  behaviourLogger: {
    branch: 'scanner', name: 'Behaviour logger', status: 'planned',
    effect: 'Record behaviour: a hunt, a herd drinking, an animal asleep.',
    needs: [{ label: 'A carnivore and an animal it hunts, on one world', special: 'hunt' }],
  },
  deepCoreSampler: {
    branch: 'scanner', name: 'Deep core sampler', status: 'planned',
    effect: 'Formations give a second, deeper entry: their age and origin.',
    needs: [{ label: '6 kinds of formation', kind: 'formation', distinct: 'traits.formation', count: 6 }],
  },
  // --- Tools -----------------------------------------------------------------------
  rover: {
    branch: 'tools', name: 'Rover', status: 'planned',
    effect: 'Fast surface travel without taking off; a refuge on wheels from stalkers.',
    needs: [{ label: '4 animals with legs, from 2 biomes', kind: 'fauna', traits: { legs: { min: 1 } }, count: 4, spread: { 'world.biome': 2 } }],
  },
  surveyDrone: {
    branch: 'tools', name: 'Survey drone', status: 'planned',
    effect: 'Scan from a distance: cliffs, skittish herds, high nests, stalkers you would rather not approach.',
    needs: [{ label: '2 fliers', kind: 'fauna', traits: { plan: 'flyer' }, count: 2 }],
  },
  atmosphericProbe: {
    branch: 'tools', name: 'Atmospheric probe', status: 'planned',
    effect: 'Scan the cloud layers of giants from orbit.',
    needs: [
      { label: 'A drifter', ...DRIFTER },
      { label: 'Visit a giant', kind: 'world', world: { giant: true } },
    ],
  },
  decoyBeacon: {
    branch: 'tools', name: 'Decoy beacon', status: 'planned',
    effect: 'Distracts a stalker for a while. Never a weapon.',
    needs: [{ label: '2 species that stalk explorers', kind: 'fauna', traits: { stalksYou: true }, count: 2 }],
  },
  // --- Contact ---------------------------------------------------------------------
  xenolinguistics: {
    branch: 'contact', name: 'Xenolinguistics', status: 'planned',
    effect: 'Settlements give longer field notes; attempt contact with tool users and village builders.',
    needs: [
      { label: 'Settlements on 2 worlds', kind: 'settlement', distinct: 'world', count: 2 },
      { label: 'A settlement of village builders or higher', kind: 'settlement', traits: { tier: { atLeast: 'village builders' } } },
    ],
  },
  signalDecoder: {
    branch: 'contact', name: 'Signal decoder', status: 'planned', after: ['xenolinguistics'],
    effect: 'Radio sources on the map say who they are and what they want.',
    needs: [{ label: 'Hear 3 radio sources', kind: 'signal', count: 3 }],
  },
  diplomaticProtocols: {
    branch: 'contact', name: 'Diplomatic protocols', status: 'planned', after: ['signalDecoder'],
    effect: 'Attempt contact with city builders and above.',
    needs: [{ label: 'Trust with a civilization', special: 'relationship', level: 'trust' }],
  },
  // --- Ship classes ----------------------------------------------------------------
  petrel: {
    branch: 'ship', name: 'Petrel', status: 'planned', ship: true,
    effect: 'A sea and storm ship. Opens Pressure hull II, Cloud diver and Signal drive.',
    needs: [
      { label: '6 upgrades', special: 'upgrades', count: 6 },
      { label: 'Fully document 3 worlds in 3 biomes', special: 'complete', count: 3, spread: { 'world.biome': 3 } },
    ],
  },
  albatross: {
    branch: 'ship', name: 'Albatross', status: 'planned', ship: true, after: ['petrel'],
    effect: 'The deep-range ship: long jumps toward the core.',
    needs: [
      { label: '12 upgrades', special: 'upgrades', count: 12 },
      { label: 'Friendship with a spacefaring civilization', special: 'relationship', level: 'friendship' },
      { label: 'Species from 3 biochemistries', kind: ['flora', 'fauna'], distinct: 'world.biochemistry', count: 3 },
    ],
  },
};
for (const [id, u] of Object.entries(UPGRADES)) { u.id = id; u.after ||= []; }

// --- Effects the game reads ----------------------------------------------------------
export const jumpRange = (unlocked) => unlocked.has('jumpDrive3') ? 24 : unlocked.has('jumpDrive2') ? 16 : JUMP_RANGE;
export const suitDamageScale = (unlocked) => unlocked.has('suitPlating') ? 0.7 : 1;
export const suitRecoveryScale = (unlocked) => unlocked.has('suitPlating') ? 2 : 1;
export const heatScale = (unlocked) => unlocked.has('heatPlating') ? 0.6 : 1;

// --- Matching ------------------------------------------------------------------------
const get = (e, path) => path === 'world' ? (e.world ? `${e.seed}:${e.bodyId}` : undefined)
  : path.split('.').reduce((v, k) => (v == null ? undefined : v[k]), e);
function matchValue(v, c) {
  if (Array.isArray(c)) return c.includes(v);
  if (c && typeof c === 'object') {
    if ('atLeast' in c) return tierAtLeast(v, c.atLeast);
    if ('min' in c || 'max' in c) return typeof v === 'number' && (c.min == null || v >= c.min) && (c.max == null || v <= c.max);
    return v != null && Object.entries(c).every(([k, x]) => matchValue(v[k], x));
  }
  return v === c;
}
export function matches(e, q) {
  if (q.anyOf) return q.anyOf.some((x) => matches(e, x));
  const kind = q.kind ?? 'any';
  if (kind === 'any' ? !DOCUMENTED.includes(e.kind) : Array.isArray(kind) ? !kind.includes(e.kind) : kind !== e.kind) return false;
  if (q.world && !(e.world && Object.entries(q.world).every(([k, c]) => matchValue(e.world[k], c)))) return false;
  if (q.traits && !Object.entries(q.traits).every(([k, c]) => matchValue(e.traits?.[k], c))) return false;
  return true;
}
const distinct = (list, path) => new Set(list.map((e) => get(e, path)).filter((v) => v != null)).size;

const SPREAD_WORDS = { world: 'worlds', 'world.biome': 'biomes', 'traits.plan': 'body plans', 'world.biochemistry': 'chemistries', 'world.clouds': 'cloud types' };
function measure(need, list) {
  const count = need.count ?? 1;
  const have = need.distinct ? distinct(list, need.distinct) : list.length;
  const spread = Object.entries(need.spread || {}).map(([path, n]) => ({ label: SPREAD_WORDS[path] || path, have: Math.min(distinct(list, path), n), need: n }));
  return { have: Math.min(have, count), count, spread, done: have >= count && spread.every((s) => s.have >= s.need) };
}
const score = (m) => (m.have / m.count + m.spread.reduce((a, s) => a + s.have / s.need, 0)) / (1 + m.spread.length);
const worldKey = (e) => `${e.seed}:${e.bodyId}`;
function byWorld(list) {
  const groups = new Map();
  for (const e of list) { const k = worldKey(e); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(e); }
  return [...groups.values()];
}

// What has been recorded on one world: { flora, fauna, formation } counts.
export function recordedOn(entries, seed, bodyId) {
  const c = { flora: 0, fauna: 0, formation: 0 };
  for (const e of entries) if (e.seed === String(seed) && e.bodyId === bodyId && e.kind in c) c[e.kind]++;
  return c;
}
// Worlds where every plant, animal and formation that is there has been recorded.
export function completedWorlds(entries) {
  const counts = new Map();
  for (const e of entries) if (['flora', 'fauna', 'formation'].includes(e.kind)) {
    const k = worldKey(e), c = counts.get(k) || { flora: 0, fauna: 0, formation: 0 };
    c[e.kind]++; counts.set(k, c);
  }
  return entries.filter((e) => {
    if (e.kind !== 'world' || !e.traits?.totals) return false;
    const t = e.traits.totals, c = counts.get(worldKey(e)) || { flora: 0, fauna: 0, formation: 0 };
    return t.flora + t.fauna + t.formations > 0 && c.flora >= t.flora && c.fauna >= t.fauna && c.formation >= t.formations;
  });
}

function needProgress(need, entries, unlocked) {
  switch (need.special) {
    case 'upgrades': {
      const n = [...unlocked].filter((id) => UPGRADES[id] && !UPGRADES[id].ship).length;
      return measure(need, Array(n).fill(null));
    }
    case 'complete': return measure(need, completedWorlds(entries));
    case 'hunt': {
      const fauna = entries.filter((e) => e.kind === 'fauna');
      const seen = new Set(fauna.map((e) => `${worldKey(e)}:${e.id}`));
      return measure(need, fauna.filter((e) => e.traits.diet === 'carnivore' && e.traits.prey?.some((id) => seen.has(`${worldKey(e)}:${id}`))));
    }
    case 'relationship': return { ...measure(need, []), notYet: 'Contact' }; // relationships arrive with Contact (roadmap phase 4)
  }
  const list = entries.filter((e) => matches(e, need));
  if (!need.sameWorld) return measure(need, list);
  return byWorld(list).map((g) => measure(need, g)).reduce((best, m) => (score(m) > score(best) ? m : best), measure(need, []));
}

// progress(codex.entries, codex.unlocked) -> { [id]: { id, upgrade, unlocked, available, ready, needs: [...] } }
//   available: every prerequisite is unlocked · ready: available and every need is met
//   needs[i]: { label, have, count, spread: [{ label, have, need }], done, notYet? }
export function progress(entries, unlocked = new Set()) {
  const out = {};
  for (const u of Object.values(UPGRADES)) {
    const needs = u.needs.map((n) => ({ label: n.label, ...needProgress(n, entries, unlocked) }));
    const available = u.after.every((id) => unlocked.has(id));
    out[u.id] = { id: u.id, upgrade: u, unlocked: unlocked.has(u.id), available, ready: !unlocked.has(u.id) && available && needs.every((n) => n.done), needs };
  }
  return out;
}

// What a new entry moved forward: compare progress before and after adding it.
// -> [{ id, name, label, have, count, spread, ready }] for upgrades not yet unlocked.
export function advanced(before, after) {
  const out = [];
  for (const [id, a] of Object.entries(after)) {
    const b = before[id];
    if (a.unlocked || !b) continue;
    a.needs.forEach((n, i) => {
      const o = b.needs[i];
      if (n.have > o.have || n.spread.some((s, j) => s.have > o.spread[j].have))
        out.push({ id, name: a.upgrade.name, label: n.label, have: n.have, count: n.count, spread: n.spread, ready: a.ready && !b.ready });
    });
  }
  return out;
}

// --- Hints: where to look, generated from the requirement ------------------------------
const PLAN_HINTS = {
  quadruped: 'worlds with complex life', biped: 'complex-life worlds, more often with low gravity',
  hexapod: 'drier worlds with life', arachnid: 'drier worlds with life', serpent: 'drier worlds with life', slug: 'wet worlds with life',
  flyer: 'complex-life worlds with thick enough air', floater: 'complex-life worlds with thick air or low gravity',
  radial: 'worlds with complex life', roller: 'dry complex-life worlds with gravity under 1.6 g',
};
const FORM_HINTS = {
  tree: 'warm, wet worlds with complex life', conifer: 'cool worlds with complex life', palm: 'hot, wet coasts', shrub: 'most living worlds',
  grass: 'temperate living worlds', succulent: 'hot, dry worlds', fungus: 'dim, wet worlds (red dwarfs)', stalk: 'low-gravity living worlds',
  mat: 'microbial worlds', mound: 'microbial worlds',
};
const FORMATION_HINTS = {
  columns: 'Volcanic worlds', obsidian: 'Volcanic worlds', fumaroles: 'volcanic worlds with air', hoodoos: 'Desert worlds', arch: 'Desert worlds',
  penitentes: 'icy worlds with thin air', pingo: 'Frozen worlds, and icy moons with hidden oceans', cryovolcano: 'icy, volcanically active moons',
  crystals: 'Amethyst worlds and silicon worlds', terraces: 'Toxic worlds and wet volcanic shores', chimneys: 'Toxic worlds and sulfur-life worlds',
  karst: 'temperate worlds with seas', seastacks: 'coasts of worlds with seas', boulders: 'airless worlds', strata: 'almost any world',
  geode: 'anywhere, but rare', meteorite: 'anywhere, but rare (more often airless worlds)',
};
const CHEM_HINTS = {
  methane: 'very cold worlds under an orange haze (violet ring on the map)', ammonia: 'cold worlds with thick air (violet ring on the map)',
  sulfur: 'hot volcanic worlds (violet ring on the map)', silicon: 'very hot worlds (violet ring on the map)', carbon: 'worlds with water-based life',
};
const KIND_HINTS = {
  flora: 'worlds with life (green rings on the map)', fauna: 'worlds with simple or complex life (bold green rings on the map)',
  formation: 'every world with a surface', settlement: 'worlds with intelligent life: look for SIGNALS on the map',
  'field-note': 'the signal at each landing site', world: 'anywhere you fly to',
};
const asList = (v) => (Array.isArray(v) ? v : [v]);
const or = (xs) => (xs.length < 2 ? xs.join('') : `${xs.slice(0, -1).join(', ')} or ${xs.at(-1)}`);
function hintFor(q) {
  const out = [], w = q.world || {}, t = q.traits || {};
  if (w.giant) out.push('gas and ice giants');
  if (w.biochemistry) out.push(...asList(w.biochemistry).map((c) => CHEM_HINTS[c]));
  if (w.biome) out.push(`${or(asList(w.biome))} worlds`);
  if (w.waterState === 'liquid') out.push('Oceanic and Verdant worlds');
  if (w.gravity?.min) out.push(`worlds above ${w.gravity.min} g`);
  if (t.plan) out.push(...asList(t.plan).map((p) => PLAN_HINTS[p]));
  if (t.form) out.push(...asList(t.form).map((f) => FORM_HINTS[f]));
  if (t.formation) out.push(...asList(t.formation).map((f) => FORMATION_HINTS[f]));
  if (t.habitat?.shore) out.push('coasts of worlds with seas');
  if (t.glow) out.push('dim worlds around red dwarfs, where many species glow');
  if (t.activity === 'nocturnal') out.push('worlds with day and night, after dark');
  if (t.stalksYou) out.push('complex-life worlds with big hunters (about 1 in 8); keep your distance');
  if (t.tier) out.push('worlds with intelligent life: SIGNALS on the map, gold radio marks');
  if (!out.length) out.push(...asList(q.kind ?? 'any').map((k) => KIND_HINTS[k]));
  return out.filter(Boolean);
}
export function hint(need) {
  if (need.special === 'hunt') return "Complex-life worlds: an animal's description says what it hunts.";
  if (need.special === 'complete') return 'Small worlds with few species are quickest. With the Field scanner the HUD counts what is left.';
  if (need.special === 'upgrades') return 'Any upgrade counts.';
  if (need.special === 'relationship') return 'Arrives with Contact (not in the game yet).';
  if (need.kind === 'any' && !need.world && !need.traits) return 'Anything you record counts: plants, animals, formations, settlements.';
  if (need.kind === 'signal') return 'Open the star map: planet-shapers and spacefarers broadcast far beyond jump range.';
  const found = [...new Set(need.anyOf ? need.anyOf.flatMap(hintFor) : hintFor(need))];
  return found.length ? `Found on: ${or(found)}` : null;
}
