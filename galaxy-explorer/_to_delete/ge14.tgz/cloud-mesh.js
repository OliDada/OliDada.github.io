// Drawing clouds (clouds.mjs): one shell around each world with air, at the cloud
// layer's height, and the clouds' shadows on its ground. The same shell is the
// cloud cover seen from orbit and the overcast sky seen from the ground, so they
// always agree. Cheap enough for phones: one sphere per world, noise in the
// fragment shader with fewer octaves on phones, and a shadow lookup added to the
// terrain's existing shader (no extra pass). THREE is passed in.
//
//   const layer = createCloudLayer(THREE, body, sun, { lite })   null if the world has no clouds
//   layer.mesh                       add to the world's group
//   layer.update(cameraLocal, t)     camera relative to the world's centre; t = orbitClock()
//   layer.densityAt(dir)             0..1 cloud at a unit direction (THREE.Vector3) right now
//   addCloudShadows(material, layer, { lite })   darkens sunlight under the clouds
import { cloudsFor, cloudAngles, cloudDensity, CLOUD_GLSL, OCTAVES, OCTAVES_LITE } from './clouds.mjs';

export function createCloudLayer(THREE, body, sun, { lite = false, light = '#ffffff' } = {}) {
  const c = cloudsFor(body);
  if (!c) return null;
  const R = body.radius, top = R + c.height;
  let angles = cloudAngles(c, 0);
  // Shared with the terrain's shadow lookup, so shadows move with the clouds.
  const uniforms = {
    uCloudRot: { value: new THREE.Vector4(1, 0, 1, 0) },
    uCloudScale: { value: c.scale },
    uCloudOffset: { value: new THREE.Vector3(...c.offset) },
    uCloudThreshold: { value: c.threshold },
    uCloudSoft: { value: c.soft },
    uCloudSun: sun, // the star's position in the scene, kept up to date by system-view.js
    uCloudCentre: { value: new THREE.Vector3() },
    uCloudHeight: { value: c.height },
    uCloudShadow: { value: 0.55 * c.opacity },
  };
  const material = new THREE.ShaderMaterial({
    uniforms: {
      ...uniforms,
      uColor: { value: new THREE.Color(c.color) },
      uLight: { value: new THREE.Color(light) },
      uOpacity: { value: c.opacity },
      uInside: { value: 0 },
      uFar: { value: 1.15 * Math.sqrt(top * top - R * R) }, // the horizon, seen from the ground
    },
    defines: { CLOUD_OCT: lite ? OCTAVES_LITE : OCTAVES },
    vertexShader: /* glsl */ `
      #include <common>
      #include <logdepthbuf_pars_vertex>
      varying vec3 vDir, vWorld, vUp;
      void main() {
        vDir = position;
        vec4 w = modelMatrix * vec4(position, 1.0);
        vWorld = w.xyz;
        vUp = w.xyz - (modelMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
        gl_Position = projectionMatrix * viewMatrix * w;
        #include <logdepthbuf_vertex>
      }`,
    fragmentShader: /* glsl */ `
      #include <common>
      #include <logdepthbuf_pars_fragment>
      uniform vec3 uCloudSun, uColor, uLight;
      uniform float uOpacity, uInside, uFar;
      varying vec3 vDir, vWorld, vUp;
      ${CLOUD_GLSL}
      void main() {
        #include <logdepthbuf_fragment>
        float v = cloudValue(normalize(vDir));
        float d = smoothstep(uCloudThreshold, uCloudThreshold + uCloudSoft, v);
        if (d < 0.004) discard;
        float thick = clamp((v - uCloudThreshold - uCloudSoft) / (2.5 * uCloudSoft), 0.0, 1.0); // deeper inside a cloud
        float ndl = dot(normalize(vUp), normalize(uCloudSun - vWorld));
        float lit = smoothstep(-0.14, 0.3, ndl); // the terminator is soft: clouds catch the light after sunset
        float dusk = clamp(1.0 - abs(ndl - 0.03) / 0.24, 0.0, 1.0);
        vec3 col = mix(uColor, uColor * vec3(1.0, 0.6, 0.4), dusk * 0.55) * uLight;
        // Thick cloud is grey underneath and bright on top.
        float shade = uInside > 0.5 ? mix(0.95, 0.4, thick) : mix(0.68, 1.0, sqrt(thick)) * (0.8 + 0.2 * d);
        col *= shade * (0.03 + 1.05 * lit);
        float a = d * uOpacity;
        float dist = distance(vWorld, cameraPosition);
        // Seen from above, clouds thin toward the world's edge, where you look through them at a slant.
        if (uInside < 0.5) a *= 0.6 + 0.4 * smoothstep(0.0, 0.4, dot(normalize(vUp), normalize(cameraPosition - vWorld)));
        if (uInside > 0.5) a *= 1.0 - smoothstep(0.45 * uFar, uFar, dist); // into the haze at the horizon
        a *= smoothstep(4.0, 30.0, dist); // passing through, the fog takes over (game.js)
        gl_FragColor = vec4(col, a);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
      }`,
    transparent: true,
    depthWrite: false,
    fog: false,
  });
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(top, lite ? 72 : 112, lite ? 48 : 72), material);
  mesh.name = 'clouds';
  mesh.renderOrder = 2; // after the sea
  const dir = new THREE.Vector3();
  return {
    c, mesh, uniforms, lite,
    get color() { return material.uniforms.uColor.value; },
    update(cameraLocal, t) {
      angles = cloudAngles(c, t);
      uniforms.uCloudRot.value.set(Math.cos(angles[0]), Math.sin(angles[0]), Math.cos(angles[1]), Math.sin(angles[1]));
      mesh.getWorldPosition(uniforms.uCloudCentre.value);
      const inside = cameraLocal.length() < top;
      material.uniforms.uInside.value = inside ? 1 : 0;
      material.side = inside ? THREE.BackSide : THREE.FrontSide;
    },
    densityAt(v) {
      dir.copy(v).normalize();
      return cloudDensity(c, [dir.x, dir.y, dir.z], angles);
    },
    dispose() { mesh.geometry.dispose(); material.dispose(); },
  };
}

// Cloud shadows on the ground: where the line toward the star crosses the cloud
// layer, sunlight is dimmed by how much cloud is there. Added after the material's
// other shader changes (planet-lod.js), inside its existing program.
export function addCloudShadows(material, layer, { lite = false } = {}) {
  const before = material.onBeforeCompile, baseKey = material.customProgramCacheKey();
  const octaves = lite ? 2 : 3; // shadows are soft: fine detail would not show
  material.onBeforeCompile = (shader, renderer) => {
    before.call(material, shader, renderer);
    Object.assign(shader.uniforms, layer.uniforms);
    shader.vertexShader = 'varying vec3 vCloudWorld;\n' + shader.vertexShader.replace('#include <project_vertex>', `#include <project_vertex>
      vCloudWorld = (modelMatrix * vec4(transformed, 1.0)).xyz;`);
    shader.fragmentShader = `#define CLOUD_OCT ${octaves}
      varying vec3 vCloudWorld; uniform vec3 uCloudSun, uCloudCentre; uniform float uCloudHeight, uCloudShadow;
      ${CLOUD_GLSL}
` + shader.fragmentShader.replace('#include <lights_fragment_end>', `#include <lights_fragment_end>
      {
        vec3 rel = vCloudWorld - uCloudCentre, toSun = normalize(uCloudSun - vCloudWorld);
        float ndl = dot(normalize(rel), toSun);
        if (ndl > 0.0) {
          vec3 through = normalize(rel + toSun * (uCloudHeight / max(ndl, 0.2)));
          float k = 1.0 - uCloudShadow * cloudDensity(through);
          reflectedLight.directDiffuse *= k;
          reflectedLight.directSpecular *= k;
        }
      }`);
  };
  material.customProgramCacheKey = () => `${baseKey}-clouds${octaves}`;
}
